(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_pages_crear-usuario_crear-usuario_page_ts"],{

/***/ 4842:
/*!***********************************************************!*\
  !*** ./src/app/pages/crear-usuario/crear-usuario.page.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CrearUsuarioPage": () => (/* binding */ CrearUsuarioPage)
/* harmony export */ });
/* harmony import */ var C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _crear_usuario_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./crear-usuario.page.html?ngResource */ 34885);
/* harmony import */ var _crear_usuario_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./crear-usuario.page.scss?ngResource */ 94351);
/* harmony import */ var _crear_usuario_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_crear_usuario_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/alertas.service */ 34997);
/* harmony import */ var src_app_services_matriz_acceso_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/matriz-acceso.service */ 75444);
/* harmony import */ var src_app_services_usuarios_matriz_acceso_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/usuarios-matriz-acceso.service */ 4710);
/* harmony import */ var src_app_services_usuarios_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/usuarios.service */ 81209);










let CrearUsuarioPage = class CrearUsuarioPage {
  constructor(usuariosService, alertasService, modalCtrl, matrizAccesoService, usuariosMatrizAccesoService) {
    this.usuariosService = usuariosService;
    this.alertasService = alertasService;
    this.modalCtrl = modalCtrl;
    this.matrizAccesoService = matrizAccesoService;
    this.usuariosMatrizAccesoService = usuariosMatrizAccesoService;
    this.usuario = {
      id: null,
      usuario: null,
      nombre: null,
      apellido: null,
      clave: null,
      correo: null,
      estatus: true,
      fecha: new Date(),
      seleccionado: null
    };
    this.roles = [];
    this.matriz = [];
  }
  ngOnInit() {
    var _this = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.matriz = yield _this.matrizAccesoService.syncGetMatrizAccesotoToPromise();
      console.log(_this.matriz);
    })();
  }
  post() {
    var _this2 = this;
    if (this.roles.length == 0) {
      this.alertasService.message('Dione', 'Seleciona un rol para continuar!.');
      return;
    }
    console.log(this.usuario);
    this.alertasService.presentaLoading('guardando cambios..');
    this.usuariosService.syncPostUsuarioToPromise(this.usuario).then(resp => {
      console.log('post user', resp);
      console.log('post roles', this.roles);
      this.roles.forEach( /*#__PURE__*/function () {
        var _ref = (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (role, index) {
          let rod = {
            id: null,
            iD_ONE_MATRIZ_ACCESO: role,
            iD_USUARIO: resp.id
          };
          console.log(rod);
          yield _this2.usuariosMatrizAccesoService.syncPostUsuarioMatrizAccesoToPromise(rod);
          if (index == _this2.roles.length - 1) {
            _this2.usuariosService.syncGetUsuariosToPromise().then(usuarios => {
              _this2.usuariosService.usuarios = usuarios;
              _this2.alertasService.loadingDissmiss();
              _this2.modalCtrl.dismiss();
              _this2.alertasService.message('Dione', 'usuario Creado');
            }, error => {
              _this2.alertasService.loadingDissmiss();
            });
          }
        });
        return function (_x, _x2) {
          return _ref.apply(this, arguments);
        };
      }());
    }, error => {
      console.log(error);
      this.alertasService.loadingDissmiss();
      this.alertasService.message('Dione', 'Lo sentimos algo salio mal');
    });
  }
  cerrarModal() {
    this.modalCtrl.dismiss();
  }
};
CrearUsuarioPage.ctorParameters = () => [{
  type: src_app_services_usuarios_service__WEBPACK_IMPORTED_MODULE_6__.UsuariosService
}, {
  type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_3__.AlertasService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController
}, {
  type: src_app_services_matriz_acceso_service__WEBPACK_IMPORTED_MODULE_4__.MatrizAccesoService
}, {
  type: src_app_services_usuarios_matriz_acceso_service__WEBPACK_IMPORTED_MODULE_5__.UsuariosMatrizAccesoService
}];
CrearUsuarioPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-crear-usuario',
  template: _crear_usuario_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_crear_usuario_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], CrearUsuarioPage);


/***/ }),

/***/ 75444:
/*!***************************************************!*\
  !*** ./src/app/services/matriz-acceso.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MatrizAccesoService": () => (/* binding */ MatrizAccesoService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 92340);




let MatrizAccesoService = class MatrizAccesoService {
  constructor(http) {
    this.http = http;
    this.matrizAcceso = [];
  }
  getAPI(api) {
    let test = '';
    if (!_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.prdMode) test = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.TestURL;
    const URL = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.preURL + test + _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postURL + api;
    return URL;
  }
  getMatrizAccesos() {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getMatrizAcceso);
    console.log('URL', URL);
    return this.http.get(URL);
  }
  getMatrizAccesosID(id) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getMatrizAccesoUsuario);
    URL = URL + id;
    console.log('URL', URL);
    return this.http.get(URL);
  }
  getUsuariosMatrizAccesosID(id) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getUsuariosMstrizAcceso);
    URL = URL + id;
    console.log('URL', URL);
    return this.http.get(URL);
  }
  getMatrizAccesosBYID(id) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getMatrizAccesoBYID);
    URL = URL + id;
    console.log('URL', URL);
    return this.http.get(URL);
  }
  postMatrizAcceso(matrizAcceso) {
    const URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postMatrizAcceo);
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control': '*'
      }
    };
    return this.http.post(URL, matrizAcceso, options);
  }
  postUsuarioMatrizAcceso(usuarioMatrizAcceso) {
    const URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postUsuarioMatrizAcceo);
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control': '*'
      }
    };
    return this.http.post(URL, usuarioMatrizAcceso, options);
  }
  putMatrizAcceso(matrizAcceso) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.putMatrizAcceso);
    URL = URL + matrizAcceso.id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    };
    console.log(URL);
    console.log(matrizAcceso);
    return this.http.put(URL, matrizAcceso, options);
  }
  deleteMatrizAcceso(id) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.deleteMatrizAcceso);
    URL = URL + id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    };
    return this.http.delete(URL, options);
  }
  syncGetMatrizAccesotoToPromise() {
    return this.getMatrizAccesos().toPromise();
  }
  syncGetMatrizAccesoByIDtoToPromise(id) {
    return this.getMatrizAccesosID(id).toPromise();
  }
  syncGetMatrizAccesoIDtoToPromise(id) {
    return this.getMatrizAccesosBYID(id).toPromise();
  }
  syncGetUsuariosMatrizAccesoIDtoToPromise(id) {
    return this.getUsuariosMatrizAccesosID(id).toPromise();
  }
  syncPostMatrizAccesoToPromise(matrizAcceso) {
    return this.postMatrizAcceso(matrizAcceso).toPromise();
  }
  syncPostUsuarioMatrizAccesoToPromise(usuarioMatrizAcceso) {
    return this.postUsuarioMatrizAcceso(usuarioMatrizAcceso).toPromise();
  }
  syncPutMatrizAccesoToPromise(matrizAcceso) {
    return this.putMatrizAcceso(matrizAcceso).toPromise();
  }
  syncDeleteMatrizAccesoToPromise(id) {
    return this.deleteMatrizAcceso(id).toPromise();
  }
};
MatrizAccesoService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
}];
MatrizAccesoService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], MatrizAccesoService);


/***/ }),

/***/ 4710:
/*!************************************************************!*\
  !*** ./src/app/services/usuarios-matriz-acceso.service.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UsuariosMatrizAccesoService": () => (/* binding */ UsuariosMatrizAccesoService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let UsuariosMatrizAccesoService = class UsuariosMatrizAccesoService {
  constructor(http) {
    this.http = http;
  }
  getAPI(api) {
    let test = '';
    if (!src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.prdMode) test = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.TestURL;
    const URL = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.preURL + test + src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postURL + api;
    return URL;
  }
  getUsuariosMatrizAccesosID(id) {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getUsuarioMatrizAccesoURL);
    URL = URL + id;
    console.log('URL', URL);
    return this.http.get(URL);
  }
  postUsuarioMatrizAcceso(matrizAcceso) {
    const URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postUsuarioMatrizAcceo);
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control': '*'
      }
    };
    return this.http.post(URL, matrizAcceso, options);
  }
  putUsuarioMatrizAcceso(matrizAcceso) {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.putMatrizAcceso);
    URL = URL + matrizAcceso.id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    };
    console.log(URL);
    console.log(matrizAcceso);
    return this.http.put(URL, matrizAcceso, options);
  }
  deleteUsuarioMatrizAcceso(id) {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.deleteUsuarioMatrizAcceso);
    URL = URL + id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    };
    return this.http.delete(URL, options);
  }
  syncGetUsuariosMatrizAccesoByIDtoToPromise(id) {
    return this.getUsuariosMatrizAccesosID(id).toPromise();
  }
  syncPostUsuarioMatrizAccesoToPromise(matrizAcceso) {
    return this.postUsuarioMatrizAcceso(matrizAcceso).toPromise();
  }
  syncPutUsuarioMatrizAccesoToPromise(matrizAcceso) {
    return this.putUsuarioMatrizAcceso(matrizAcceso).toPromise();
  }
  syncDeleteUsuarioMatrizAccesoToPromise(id) {
    return this.deleteUsuarioMatrizAcceso(id).toPromise();
  }
};
UsuariosMatrizAccesoService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
}];
UsuariosMatrizAccesoService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], UsuariosMatrizAccesoService);


/***/ }),

/***/ 94351:
/*!************************************************************************!*\
  !*** ./src/app/pages/crear-usuario/crear-usuario.page.scss?ngResource ***!
  \************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 49579);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60931);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "ion-icon {\n  color: #000;\n}\n\nion-input, ion-select {\n  border-radius: 10px;\n  border: solid 1px rgb(218, 218, 218);\n  height: 2.5rem;\n}\n\nion-label {\n  font-weight: 500;\n}\n\n.description {\n  height: 4rem;\n}\n\n.has-focus {\n  border: 2px solid #5b9bd1 !important;\n}\n\nion-footer ion-toolbar ion-button {\n  --padding-top:1rem;\n  --padding-bottom:1rem;\n  --padding-start:0.75rem;\n  --padding-end:0.75rem;\n  height: 2.5rem;\n  width: 60%;\n  display: block;\n  margin: 0 auto;\n  margin-bottom: 1rem;\n}", "",{"version":3,"sources":["webpack://./src/app/pages/crear-usuario/crear-usuario.page.scss","webpack://./../../Simple%20Design%20Experience/Control%20Viaticos/src/app/pages/crear-usuario/crear-usuario.page.scss"],"names":[],"mappings":"AAAA;EACI,WAAA;ACCJ;;ADCA;EACI,mBAAA;EACA,oCAAA;EACA,cAAA;ACEJ;;ADAA;EACI,gBAAA;ACGJ;;ADDA;EACI,YAAA;ACIJ;;ADFA;EACI,oCAAA;ACKJ;;ADHA;EACI,kBAAA;EACA,qBAAA;EACA,uBAAA;EACA,qBAAA;EACA,cAAA;EACA,UAAA;EACA,cAAA;EACA,cAAA;EACA,mBAAA;ACMJ","sourcesContent":["ion-icon{\r\n    color: #000;\r\n}\r\nion-input, ion-select {\r\n    border-radius: 10px;\r\n    border: solid 1px rgba(218,218,218,1);\r\n    height: 2.5rem;\r\n}\r\nion-label{\r\n    font-weight: 500;\r\n}\r\n.description{\r\n    height: 4rem;\r\n}\r\n.has-focus{\r\n    border: 2px solid #5b9bd1 !important;\r\n}\r\nion-footer ion-toolbar ion-button{\r\n    --padding-top:1rem;\r\n    --padding-bottom:1rem;\r\n    --padding-start:0.75rem;\r\n    --padding-end:0.75rem;\r\n    height: 2.5rem;\r\n    width: 60%;\r\n    display: block;\r\n    margin: 0 auto;\r\n    margin-bottom: 1rem;\r\n}","ion-icon {\n  color: #000;\n}\n\nion-input, ion-select {\n  border-radius: 10px;\n  border: solid 1px rgb(218, 218, 218);\n  height: 2.5rem;\n}\n\nion-label {\n  font-weight: 500;\n}\n\n.description {\n  height: 4rem;\n}\n\n.has-focus {\n  border: 2px solid #5b9bd1 !important;\n}\n\nion-footer ion-toolbar ion-button {\n  --padding-top:1rem;\n  --padding-bottom:1rem;\n  --padding-start:0.75rem;\n  --padding-end:0.75rem;\n  height: 2.5rem;\n  width: 60%;\n  display: block;\n  margin: 0 auto;\n  margin-bottom: 1rem;\n}"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 34885:
/*!************************************************************************!*\
  !*** ./src/app/pages/crear-usuario/crear-usuario.page.html?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <ion-button (click)=\"cerrarModal()\"   fill=\"clear\"  slot=\"start\">\n     <ion-icon slot=\"icon-only\" name=\"arrow-back\"></ion-icon>\n    </ion-button>\n    <ion-title>Crear Usuario</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n<ion-grid >\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-row>\n        <ion-col size=\"12\" style=\"display: flex;justify-content: space-between;align-items: center;\">\n          <ion-label>Asignación Roles</ion-label>\n         \n        </ion-col>\n        <ion-col size=\"12\">\n\n          <ion-select  multiple=\"true\"     name=\"matriz\"  [(ngModel)]=\"roles\"   placeholder=\"Seleccionar\">\n            <ion-select-option  *ngFor=\"let role of matriz\"  [value]=\"role.iD_MATRIZ_ACCESO\n            \">{{role.nombre}}</ion-select-option>\n          </ion-select>\n      \n        </ion-col>\n      </ion-row>\n          </ion-col>\n    <ion-col size=\"6\">\n      <ion-row>\n        <ion-col size=\"12\">\n          <ion-label class=\"ion-margin-bottom\">Nombre</ion-label>\n        </ion-col>\n        <ion-col size=\"12\">\n          <ion-input  name=\"nombre\"  type=\"text\" placeholder=\"nombre\" [(ngModel)]=\"usuario.nombre\"></ion-input>\n        </ion-col>\n      </ion-row>\n          </ion-col>\n          <ion-col size=\"6\">\n            <ion-row>\n              <ion-col size=\"12\">\n                <ion-label class=\"ion-margin-bottom\">Apellido</ion-label>\n              </ion-col>\n              <ion-col size=\"12\">\n                <ion-input  name=\"apellido\"  type=\"text\" placeholder=\"apellido\" [(ngModel)]=\"usuario.apellido\"></ion-input>\n              </ion-col>\n            </ion-row>\n                </ion-col>\n                \n          <ion-col size=\"12\">\n            <ion-row>\n              <ion-col size=\"12\">\n                <ion-label class=\"ion-margin-bottom\">Correo</ion-label>\n              </ion-col>\n              <ion-col size=\"12\">\n                <ion-input  name=\"correo\" [(ngModel)]=\"usuario.correo\"  type=\"text\" placeholder=\"correo\"></ion-input>\n              </ion-col>\n \n            </ion-row>\n                </ion-col>\n\n                <ion-col size=\"6\">\n                  <ion-row>\n                    <ion-col size=\"12\">\n                      <ion-label class=\"ion-margin-bottom\">Usuario</ion-label>\n                    </ion-col>\n                    <ion-col size=\"12\">\n                      <ion-input name=\"usuario\" [(ngModel)]=\"usuario.usuario\"  type=\"text\" placeholder=\"usuario\"></ion-input>\n                    </ion-col>\n                  </ion-row>\n                      </ion-col>\n                <ion-col size=\"6\">\n                  <ion-row>\n                    <ion-col size=\"12\">\n                      <ion-label class=\"ion-margin-bottom\">Contraseña</ion-label>\n                    </ion-col>\n                    <ion-col size=\"12\">\n                      <ion-input  name=\"clave\" [(ngModel)]=\"usuario.clave\"  type=\"password\" placeholder=\"clave\"></ion-input>\n                    </ion-col>\n       \n                  </ion-row>\n                      </ion-col>\n\n              \n  </ion-row>\n</ion-grid>\n\n</ion-content>\n\n \n<ion-footer class=\"ion-no-border\">\n  <ion-toolbar class=\"ion-padding\">\n    <ion-button (click)=\"post()\"      color=\"dark\" shape=\"round\">\n    Crear Usuario\n    </ion-button>\n  </ion-toolbar>\n</ion-footer>";

/***/ })

}]);
//# sourceMappingURL=default-src_app_pages_crear-usuario_crear-usuario_page_ts.js.map