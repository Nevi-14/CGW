(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_registro-anticipos_registro-anticipos_module_ts"],{

/***/ 65860:
/*!*********************************************************************!*\
  !*** ./src/app/pages/calendario-popover/calendario-popover.page.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CalendarioPopoverPage": () => (/* binding */ CalendarioPopoverPage)
/* harmony export */ });
/* harmony import */ var C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _calendario_popover_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./calendario-popover.page.html?ngResource */ 84344);
/* harmony import */ var _calendario_popover_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./calendario-popover.page.scss?ngResource */ 77057);
/* harmony import */ var _calendario_popover_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_calendario_popover_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 93819);






let CalendarioPopoverPage = class CalendarioPopoverPage {
  constructor(popOverCtrl, cd) {
    this.popOverCtrl = popOverCtrl;
    this.cd = cd;
    this.max = new Date().getFullYear() + 3;
  }
  ngOnInit() {}
  formatDate(value) {
    var _this = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const popover = yield _this.popOverCtrl.getTop();
      if (popover) {
        return _this.popOverCtrl.dismiss({
          fecha: value
        });
      }
    })();
  }
};
CalendarioPopoverPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.PopoverController
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.ChangeDetectorRef
}];
CalendarioPopoverPage.propDecorators = {
  fecha: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input
  }]
};
CalendarioPopoverPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
  selector: 'app-calendario-popover',
  template: _calendario_popover_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_calendario_popover_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], CalendarioPopoverPage);


/***/ }),

/***/ 63420:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/registro-anticipos/registro-anticipos-routing.module.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistroAnticiposPageRoutingModule": () => (/* binding */ RegistroAnticiposPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _registro_anticipos_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./registro-anticipos.page */ 99921);




const routes = [{
  path: '',
  component: _registro_anticipos_page__WEBPACK_IMPORTED_MODULE_0__.RegistroAnticiposPage
}];
let RegistroAnticiposPageRoutingModule = class RegistroAnticiposPageRoutingModule {};
RegistroAnticiposPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
  imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
  exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
})], RegistroAnticiposPageRoutingModule);


/***/ }),

/***/ 57842:
/*!***********************************************************************!*\
  !*** ./src/app/pages/registro-anticipos/registro-anticipos.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistroAnticiposPageModule": () => (/* binding */ RegistroAnticiposPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/pipes/pipes.module */ 35503);
/* harmony import */ var _registro_anticipos_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./registro-anticipos.page */ 99921);
/* harmony import */ var _registro_anticipos_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./registro-anticipos-routing.module */ 63420);
/* harmony import */ var src_app_components_component_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/components/component.module */ 78443);









let RegistroAnticiposPageModule = class RegistroAnticiposPageModule {};
RegistroAnticiposPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule, _registro_anticipos_routing_module__WEBPACK_IMPORTED_MODULE_2__.RegistroAnticiposPageRoutingModule, src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_0__.PipesModule, src_app_components_component_module__WEBPACK_IMPORTED_MODULE_3__.ComponentModule],
  declarations: [_registro_anticipos_page__WEBPACK_IMPORTED_MODULE_1__.RegistroAnticiposPage]
})], RegistroAnticiposPageModule);


/***/ }),

/***/ 99921:
/*!*********************************************************************!*\
  !*** ./src/app/pages/registro-anticipos/registro-anticipos.page.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistroAnticiposPage": () => (/* binding */ RegistroAnticiposPage)
/* harmony export */ });
/* harmony import */ var C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _registro_anticipos_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./registro-anticipos.page.html?ngResource */ 92941);
/* harmony import */ var _registro_anticipos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./registro-anticipos.page.scss?ngResource */ 23673);
/* harmony import */ var _registro_anticipos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_registro_anticipos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _services_alertas_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/alertas.service */ 34997);
/* harmony import */ var _services_gastos_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/gastos.service */ 40354);
/* harmony import */ var _services_usuarios_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/usuarios.service */ 81209);
/* harmony import */ var _calendario_popover_calendario_popover_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../calendario-popover/calendario-popover.page */ 65860);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! date-fns */ 86712);
/* harmony import */ var src_app_services_adelanto_viaticos_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/adelanto-viaticos.service */ 45406);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_services_vistas_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/vistas.service */ 13651);
/* harmony import */ var _lista_usuarios_lista_usuarios_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../lista-usuarios/lista-usuarios.page */ 44018);
/* harmony import */ var src_app_services_lineas_anticipos_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/services/lineas-anticipos.service */ 37568);
/* harmony import */ var src_app_services_proceso_contable_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/services/proceso-contable.service */ 41754);

















let RegistroAnticiposPage = class RegistroAnticiposPage {
  constructor(modalCtrl, alertasService, gastosService, usuariosService, popOverCtrl, adelantoViaticosService, router, vistasService, lineasAnticipoService, procesoContableService) {
    this.modalCtrl = modalCtrl;
    this.alertasService = alertasService;
    this.gastosService = gastosService;
    this.usuariosService = usuariosService;
    this.popOverCtrl = popOverCtrl;
    this.adelantoViaticosService = adelantoViaticosService;
    this.router = router;
    this.vistasService = vistasService;
    this.lineasAnticipoService = lineasAnticipoService;
    this.procesoContableService = procesoContableService;
    this.usuarios = [];
    this.adelantoViatico = {
      id: null,
      cREADO_POR: null,
      mODIFICADO_POR: null,
      eSTATUS: 'P',
      coD_COMPANIA: null,
      fecha: new Date(),
      fechA_INICIAL: new Date(),
      fechA_FINAL: new Date(),
      detalle: null,
      fechA_TRANSACCION: new Date(),
      numerO_TRANSACCION: null,
      moneda: '₡',
      monto: 0,
      utilizado: 0,
      restante: 0,
      observaciones: null,
      lineas: 0,
      ultimA_FECHA_MODIFICACION: new Date()
    };
    this.formatoFecha = new Date((0,date_fns__WEBPACK_IMPORTED_MODULE_12__["default"])(new Date(), 'yyy/MM/dd')).toISOString();
    this.montoMaximo = 0;
    this.montoTotal = 0;
    this.montoRestante = 0;
    this.isOpen = false;
    this.textoBuscar = '';
    this.clientes = [];
    this.usuariosAnticipo = [];
  }
  ngOnInit() {
    this.vistasService.syncGetClientesToPromise().then(clientes => {
      clientes.forEach((cliente, index) => {
        if (cliente.cia == 'CVET' || cliente.cia == 'COOK' || cliente.cia == 'CORE') {
          let i = this.clientes.findIndex(c => c.cia == cliente.cia);
          if (i < 0) {
            this.clientes.push(cliente);
          }
        }
        if (index == clientes.length - 1) {
          console.log('clientes', this.clientes);
          this.cargarDatos();
        }
      });
    });
  }
  compania($event) {
    console.log($event);
    this.adelantoViatico.coD_COMPANIA = $event.detail.value;
  }
  obtenerFechaCorte() {
    let currentDate = this.adelantoViatico.fechA_INICIAL;
    let date = currentDate.getDay();
    let daysToSunday = 7 - date;
    return new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() + daysToSunday);
  }
  listaColaboradores() {
    var _this = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const modal = yield _this.modalCtrl.create({
        component: _lista_usuarios_lista_usuarios_page__WEBPACK_IMPORTED_MODULE_9__.ListaUsuariosPage,
        cssClass: 'alert-modal'
      });
      modal.present();
      const {
        data
      } = yield modal.onWillDismiss();
      if (data != undefined) {
        console.log(data);
        data.forEach(usuario => {
          let i = _this.usuarios.findIndex(e => e.usuario == usuario.usuario);
          if (i < 0) {
            usuario.monto = 0;
            _this.usuarios.push(usuario);
          }
        });
      }
    })();
  }
  cargarDatos() {
    this.adelantoViatico.fechA_INICIAL = new Date(this.formatoFecha);
    this.adelantoViatico.fechA_FINAL = this.obtenerFechaCorte();
    this.adelantoViatico.fechA_TRANSACCION = new Date(this.formatoFecha);
  }
  cerrarModal() {
    this.modalCtrl.dismiss();
  }
  borrarDatos() {
    this.formatoFecha = new Date((0,date_fns__WEBPACK_IMPORTED_MODULE_12__["default"])(new Date(), 'yyy/MM/dd')).toISOString();
    this.montoMaximo = 0;
    this.adelantoViatico = {
      id: null,
      cREADO_POR: null,
      mODIFICADO_POR: null,
      eSTATUS: 'P',
      coD_COMPANIA: null,
      fecha: new Date(),
      fechA_INICIAL: new Date(),
      fechA_FINAL: new Date(),
      detalle: null,
      fechA_TRANSACCION: new Date(),
      numerO_TRANSACCION: null,
      moneda: '₡',
      monto: 0,
      utilizado: 0,
      restante: 0,
      observaciones: null,
      lineas: 0,
      ultimA_FECHA_MODIFICACION: new Date()
    };
    this.usuarios = [];
    this.cargarDatos();
  }
  fecha(identificador) {
    var _this2 = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let nuevaFecha = null;
      switch (identificador) {
        case 'fechaInicial':
          nuevaFecha = _this2.adelantoViatico.fechA_INICIAL.toISOString();
          break;
        case 'fechaTransaccion':
          nuevaFecha = _this2.adelantoViatico.fechA_TRANSACCION.toISOString();
          break;
      }
      const popover = yield _this2.popOverCtrl.create({
        component: _calendario_popover_calendario_popover_page__WEBPACK_IMPORTED_MODULE_6__.CalendarioPopoverPage,
        cssClass: 'my-custom-class',
        translucent: true,
        componentProps: {
          fecha: nuevaFecha
        }
      });
      yield popover.present();
      const {
        data
      } = yield popover.onDidDismiss();
      if (data != undefined) {
        _this2.formatoFecha = data.fecha;
        switch (identificador) {
          case 'fechaInicial':
            if (new Date(_this2.formatoFecha).getDay() == 0) {
              _this2.alertasService.message('Dione', 'Lo sentimos no se pueden utilizar fechas de corte.');
              return;
            }
            _this2.adelantoViatico.fechA_INICIAL = new Date(_this2.formatoFecha);
            _this2.adelantoViatico.fechA_FINAL = _this2.obtenerFechaCorte();
            break;
          case 'fechaTransaccion':
            _this2.adelantoViatico.fechA_TRANSACCION = new Date(_this2.formatoFecha);
            break;
        }
      }
    })();
  }
  borrarUsuario(i) {
    this.usuarios.splice(i, 1);
    this.actualziarTotales();
  }
  incrementarMonto(usuario, $event) {
    usuario.monto = $event.detail.value;
    this.actualziarTotales();
  }
  actualziarTotales() {
    this.adelantoViatico.monto = 0;
    this.usuarios.forEach(usuario => {
      this.adelantoViatico.monto += Number(usuario.monto);
    });
  }
  randomID() {
    //define a variable consisting alphabets in small and capital letter  
    var characters = "ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
    var lenString = 10;
    var randomstring = '';
    //loop to select a new character in each iteration  
    for (var i = 0; i < lenString; i++) {
      var rnum = Math.floor(Math.random() * characters.length);
      randomstring += characters.substring(rnum, rnum + 1);
      if (i == lenString - 1) {
        return randomstring;
      }
    }
  }
  generarPost() {
    var _this3 = this;
    this.adelantoViatico.cREADO_POR = this.usuariosService.usuario.id;
    this.adelantoViatico.mODIFICADO_POR = this.usuariosService.usuario.id;
    this.adelantoViatico.lineas = this.usuarios.length;
    this.adelantoViatico.restante = this.adelantoViatico.monto;
    this.alertasService.presentaLoading('Guardando Datos...');
    this.adelantoViaticosService.syncPostAdelantoViaticosToPromise(this.adelantoViatico).then( /*#__PURE__*/function () {
      var _ref = (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (resp) {
        let numAsiento = _this3.randomID();
        let movDir = {
          id: _this3.adelantoViatico.numerO_TRANSACCION,
          tipO_GASTO: 'N/D',
          tipo: 'N/D',
          suB_TIPO: 'N/D',
          fecha: _this3.adelantoViatico.fechA_TRANSACCION,
          monto: _this3.adelantoViatico.monto,
          tipO_ASIENTO: 'CB',
          paquete: 'CB',
          concepto: `Pago de
        viáticos +
        ${(0,date_fns__WEBPACK_IMPORTED_MODULE_12__["default"])(_this3.adelantoViatico.fechA_INICIAL, 'MM/dd/yyyy')} +
        ${(0,date_fns__WEBPACK_IMPORTED_MODULE_12__["default"])(_this3.adelantoViatico.fechA_FINAL, 'MM/dd/yyyy')}`,
          nuM_ASIENTO: numAsiento
        };
        yield _this3.procesoContableService.syncPostMovDirToPromise(movDir);
        let asientoDiario = {
          id: null,
          coD_COMPANIA: _this3.adelantoViatico.coD_COMPANIA,
          asiento: numAsiento,
          paquete: 'CB',
          tipO_ASIENTO: 'CB',
          fecha: new Date(),
          contabilidad: 'C',
          origen: 'CB',
          clasE_ASIENTO: 'C',
          totaL_DEBITO_LOC: _this3.adelantoViatico.monto,
          totaL_DEBITO_DOL: 0,
          totaL_CREDITO_LOC: 0,
          totaL_CREDITO_DOL: 0,
          ultimO_USUARIO: _this3.usuariosService.usuario.usuario,
          fechA_ULT_MODIF: new Date(),
          marcado: 'N',
          notas: `Pago de viáticos ${(0,date_fns__WEBPACK_IMPORTED_MODULE_12__["default"])(_this3.adelantoViatico.fechA_INICIAL, 'MM/dd/yyyy')} + ${(0,date_fns__WEBPACK_IMPORTED_MODULE_12__["default"])(_this3.adelantoViatico.fechA_FINAL, 'MM/dd/yyyy')}`,
          totaL_CONTROL_LOC: 0,
          totaL_CONTROL_DOL: 0,
          usuariO_CREACION: _this3.usuariosService.usuario.usuario,
          fechA_CREACION: new Date(),
          rowPointer: null,
          dependencia: null,
          noteExistingFlag: 0,
          recordDate: new Date(),
          createdBy: _this3.usuariosService.usuario.usuario,
          updatedBy: _this3.usuariosService.usuario.usuario,
          createdDate: new Date(),
          documentO_GLOBAL: null
        };
        yield _this3.procesoContableService.syncPostAsientoDiarioToPromise(asientoDiario);
        let diario = [{
          id: null,
          coD_COMPANIA: _this3.adelantoViatico.coD_COMPANIA,
          asiento: numAsiento,
          consecutivo: 0,
          nit: null,
          centrO_COSTO: '00-00-00',
          cuentA_CONTABLE: '1-01-02-002-007',
          fuente: 'fuente',
          referencia: `Pago de viáticos ${(0,date_fns__WEBPACK_IMPORTED_MODULE_12__["default"])(_this3.adelantoViatico.fechA_INICIAL, 'MM/dd/yyyy')} + ${(0,date_fns__WEBPACK_IMPORTED_MODULE_12__["default"])(_this3.adelantoViatico.fechA_FINAL, 'MM/dd/yyyy')}`,
          debitO_LOCAL: 0,
          debitO_DOLAR: 0,
          creditO_LOCAL: _this3.adelantoViatico.monto,
          creditO_DOLAR: 0,
          debitO_UNIDADES: 0,
          creditO_UNIDADES: 0,
          tipO_CAMBIO: 0,
          rowPointer: null,
          basE_LOCAL: 0,
          basE_DOLAR: 0,
          proyecto: null,
          fase: null,
          noteExistingFlag: 0,
          recordDate: new Date(),
          createdBy: _this3.usuariosService.usuario.usuario,
          updatedBy: _this3.usuariosService.usuario.usuario,
          createdDate: new Date(),
          documentO_GLOBAL: null
        }, {
          id: null,
          coD_COMPANIA: _this3.adelantoViatico.coD_COMPANIA,
          asiento: numAsiento,
          consecutivo: 0,
          nit: null,
          centrO_COSTO: '00-00-00',
          cuentA_CONTABLE: '1-01-05-004-011',
          fuente: 'fuente',
          referencia: `Pago de viáticos + ${(0,date_fns__WEBPACK_IMPORTED_MODULE_12__["default"])(_this3.adelantoViatico.fechA_INICIAL, 'MM/dd/yyyy')}  + ${(0,date_fns__WEBPACK_IMPORTED_MODULE_12__["default"])(_this3.adelantoViatico.fechA_FINAL, 'MM/dd/yyyy')}`,
          debitO_LOCAL: 0,
          debitO_DOLAR: 0,
          creditO_LOCAL: _this3.adelantoViatico.monto,
          creditO_DOLAR: 0,
          debitO_UNIDADES: 0,
          creditO_UNIDADES: 0,
          tipO_CAMBIO: 0,
          rowPointer: null,
          basE_LOCAL: 0,
          basE_DOLAR: 0,
          proyecto: null,
          fase: null,
          noteExistingFlag: 0,
          recordDate: new Date(),
          createdBy: _this3.usuariosService.usuario.usuario,
          updatedBy: _this3.usuariosService.usuario.usuario,
          createdDate: new Date(),
          documentO_GLOBAL: null
        }, {
          id: null,
          coD_COMPANIA: _this3.adelantoViatico.coD_COMPANIA,
          asiento: numAsiento,
          consecutivo: 0,
          nit: null,
          centrO_COSTO: '00-00-00',
          cuentA_CONTABLE: '7-99-01-009-000',
          fuente: 'fuente',
          referencia: `Pago de viáticos ${(0,date_fns__WEBPACK_IMPORTED_MODULE_12__["default"])(_this3.adelantoViatico.fechA_INICIAL, 'MM/dd/yyyy')} + ${(0,date_fns__WEBPACK_IMPORTED_MODULE_12__["default"])(_this3.adelantoViatico.fechA_FINAL, 'MM/dd/yyyy')} +  ${_this3.adelantoViatico.numerO_TRANSACCION}`,
          debitO_LOCAL: 0,
          debitO_DOLAR: 0,
          creditO_LOCAL: _this3.adelantoViatico.monto,
          creditO_DOLAR: 0,
          debitO_UNIDADES: 0,
          creditO_UNIDADES: 0,
          tipO_CAMBIO: 0,
          rowPointer: null,
          basE_LOCAL: 0,
          basE_DOLAR: 0,
          proyecto: null,
          fase: null,
          noteExistingFlag: 0,
          recordDate: new Date(),
          createdBy: _this3.usuariosService.usuario.usuario,
          updatedBy: _this3.usuariosService.usuario.usuario,
          createdDate: new Date(),
          documentO_GLOBAL: null
        }];
        yield _this3.procesoContableService.syncPostDiarioToPromise(diario);
        console.log(resp);
        _this3.usuarios.forEach( /*#__PURE__*/function () {
          var _ref2 = (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (usuario, index) {
            const linea = {
              id: null,
              iD_ANTICIPO: resp.id,
              metodO_DEVOLUCION: null,
              correO_ENVIADO: 0,
              estatus: 'P',
              usuario: usuario.usuario,
              monto: usuario.monto,
              utilizado: 0,
              restante: usuario.monto
            };
            yield _this3.lineasAnticipoService.syncPostLineaAnticipoToPromise(linea);
            if (index == _this3.usuarios.length - 1) {
              _this3.alertasService.loadingDissmiss();
              _this3.alertasService.message('APP', 'El Anticipo se creo con exito!.');
              _this3.borrarDatos();
            }
          });
          return function (_x2, _x3) {
            return _ref2.apply(this, arguments);
          };
        }());
      });
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }(), error => {
      this.alertasService.loadingDissmiss();
      this.alertasService.message('APP', 'Lo sentimos algo salio mal...');
    });
  }
};
RegistroAnticiposPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_13__.ModalController
}, {
  type: _services_alertas_service__WEBPACK_IMPORTED_MODULE_3__.AlertasService
}, {
  type: _services_gastos_service__WEBPACK_IMPORTED_MODULE_4__.GastosService
}, {
  type: _services_usuarios_service__WEBPACK_IMPORTED_MODULE_5__.UsuariosService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_13__.PopoverController
}, {
  type: src_app_services_adelanto_viaticos_service__WEBPACK_IMPORTED_MODULE_7__.AdelantoViaticosService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_14__.Router
}, {
  type: src_app_services_vistas_service__WEBPACK_IMPORTED_MODULE_8__.VistassService
}, {
  type: src_app_services_lineas_anticipos_service__WEBPACK_IMPORTED_MODULE_10__.LineasAnticiposService
}, {
  type: src_app_services_proceso_contable_service__WEBPACK_IMPORTED_MODULE_11__.ProcesoContableService
}];
RegistroAnticiposPage = (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_16__.Component)({
  selector: 'app-registro-anticipos',
  template: _registro_anticipos_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_registro_anticipos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], RegistroAnticiposPage);


/***/ }),

/***/ 24586:
/*!***************************************!*\
  !*** ./src/app/pipes/colones.pipe.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColonesPipe": () => (/* binding */ ColonesPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);


let ColonesPipe = class ColonesPipe {
  transform(amount, decimalCount = 2, decimal = ".", thousands = ",", moneda = "¢") {
    decimalCount = Math.abs(decimalCount);
    decimalCount = isNaN(decimalCount) ? 2 : decimalCount;
    const negativeSign = amount < 0 ? "-" : "";
    let i = parseInt(amount = Math.abs(Number(amount) || 0).toFixed(decimalCount)).toString();
    let j = i.length > 3 ? i.length % 3 : 0;
    return negativeSign + moneda + (j ? i.substr(0, j) + thousands : '') + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands) + (decimalCount ? decimal + Math.abs(amount - Number(i)).toFixed(decimalCount).slice(2) : "");
  }
};
ColonesPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
  name: 'colones'
})], ColonesPipe);


/***/ }),

/***/ 79146:
/*!**************************************!*\
  !*** ./src/app/pipes/filtro.pipe.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FiltroPipe": () => (/* binding */ FiltroPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);


let FiltroPipe = class FiltroPipe {
  transform(arreglo, texto = '', columna = '') {
    if (texto === '') {
      return arreglo;
    }
    if (!arreglo) {
      return arreglo;
    }
    // todas las busquedas de javascript son case sentisive
    texto = texto.toLocaleLowerCase();
    //  return null;
    return arreglo.filter(
    //  item=> item.title.toLocaleLowerCase().includes(texto)
    item => item[columna].toLocaleLowerCase().includes(texto));
  }
};
FiltroPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
  name: 'filtro'
})], FiltroPipe);


/***/ }),

/***/ 35503:
/*!***************************************!*\
  !*** ./src/app/pipes/pipes.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PipesModule": () => (/* binding */ PipesModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _filtro_pipe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./filtro.pipe */ 79146);
/* harmony import */ var _colones_pipe__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./colones.pipe */ 24586);





let PipesModule = class PipesModule {};
PipesModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
  declarations: [_filtro_pipe__WEBPACK_IMPORTED_MODULE_0__.FiltroPipe, _colones_pipe__WEBPACK_IMPORTED_MODULE_1__.ColonesPipe],
  exports: [_filtro_pipe__WEBPACK_IMPORTED_MODULE_0__.FiltroPipe, _angular_common__WEBPACK_IMPORTED_MODULE_4__.DatePipe, _colones_pipe__WEBPACK_IMPORTED_MODULE_1__.ColonesPipe],
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule]
})], PipesModule);


/***/ }),

/***/ 37568:
/*!******************************************************!*\
  !*** ./src/app/services/lineas-anticipos.service.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LineasAnticiposService": () => (/* binding */ LineasAnticiposService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let LineasAnticiposService = class LineasAnticiposService {
  constructor(http) {
    this.http = http;
  }
  getAPI(api) {
    let test = "";
    if (!src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.prdMode) test = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.TestURL;
    const URL = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.preURL + test + src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postURL + api;
    return URL;
  }
  getGastosLineas(id) {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getGastosAnticipoLineas);
    URL = URL + id;
    console.log('URL', URL);
    return this.http.get(URL);
  }
  getLineasAnticipos(id) {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getLineasAnticipos);
    URL = URL + id;
    console.log('URL', URL);
    return this.http.get(URL);
  }
  getLineasAnticiposLineas(id) {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getGastosAnticipoLineas);
    URL = URL + id;
    console.log('URL', URL);
    return this.http.get(URL);
  }
  postLineaAnticipo(lineaAnticipo) {
    const URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postLineaAnticipos);
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Origin': '*'
      }
    };
    console.log('URL', URL);
    console.log('lineaAnticipo', lineaAnticipo);
    return this.http.post(URL, lineaAnticipo, options);
  }
  putLineaAnticipo(lineaAnticipo) {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.putLineaAnticipos);
    URL = URL + lineaAnticipo.id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Origin': '*'
      }
    };
    console.log('URL', URL);
    console.log('lineaAnticipo', lineaAnticipo);
    return this.http.put(URL, lineaAnticipo, options);
  }
  syncGetLineasAnriciposToPromise(id) {
    return this.getLineasAnticipos(id).toPromise();
  }
  syncGetLineasAnticiposLineasToPromise(id) {
    return this.getLineasAnticiposLineas(id).toPromise();
  }
  syncGetGastosLineasToPromise(id) {
    return this.getGastosLineas(id).toPromise();
  }
  syncPutLineaAnticipoToPromise(lineaAnticipo) {
    return this.putLineaAnticipo(lineaAnticipo).toPromise();
  }
  syncPostLineaAnticipoToPromise(lineaAnticipo) {
    return this.postLineaAnticipo(lineaAnticipo).toPromise();
  }
};
LineasAnticiposService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
}];
LineasAnticiposService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], LineasAnticiposService);


/***/ }),

/***/ 41754:
/*!******************************************************!*\
  !*** ./src/app/services/proceso-contable.service.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProcesoContableService": () => (/* binding */ ProcesoContableService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let ProcesoContableService = class ProcesoContableService {
  constructor(http) {
    this.http = http;
  }
  getAPI(api) {
    let test = '';
    if (!src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.prdMode) test = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.TestURL;
    const URL = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.preURL + test + src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postURL + api;
    return URL;
  }
  getMovDir() {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getMovDir);
    return this.http.get(URL);
  }
  getAsientoDiario() {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getAsientoDiario);
    return this.http.get(URL);
  }
  getDiario() {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getDiario);
    return this.http.get(URL);
  }
  postMovDir(post) {
    const URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postMovDir);
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Origin': '*'
      }
    };
    console.log('URL', URL);
    console.log('post', post);
    return this.http.post(URL, post, options);
  }
  postAsientoDiario(post) {
    const URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postAsientoDiario);
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Origin': '*'
      }
    };
    console.log('URL', URL);
    console.log('post', post);
    return this.http.post(URL, post, options);
  }
  postDiario(post) {
    const URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postDiario);
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Origin': '*'
      }
    };
    console.log('URL', URL);
    console.log('post', post);
    return this.http.post(URL, post, options);
  }
  syncGetMovDirToPromise() {
    return this.getMovDir().toPromise();
  }
  syncGetAsientoDiario() {
    return this.getAsientoDiario().toPromise();
  }
  syncGetDiario() {
    return this.getDiario().toPromise();
  }
  syncPostMovDirToPromise(post) {
    return this.postMovDir(post).toPromise();
  }
  syncPostAsientoDiarioToPromise(post) {
    return this.postAsientoDiario(post).toPromise();
  }
  syncPostDiarioToPromise(post) {
    return this.postDiario(post).toPromise();
  }
};
ProcesoContableService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
}];
ProcesoContableService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], ProcesoContableService);


/***/ }),

/***/ 13651:
/*!********************************************!*\
  !*** ./src/app/services/vistas.service.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VistassService": () => (/* binding */ VistassService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 92340);




let VistassService = class VistassService {
  constructor(http) {
    this.http = http;
  }
  getAPI(api) {
    let test = '';
    if (!_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.prdMode) test = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.TestURL;
    const URL = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.preURL + test + _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postURL + api;
    return URL;
  }
  getClientes() {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getUsuarioID);
    return this.http.get('https://sde1.sderp.site/api-coris-control-viaticos/api/get/ultimo-consecutivo/exactus');
  }
  getUltimoConsecutivo() {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getUsuarios);
    return this.http.get(URL);
  }
  syncGetClientesToPromise() {
    return this.getClientes().toPromise();
  }
  syncGetUltimoConsecutivoToPromise() {
    return this.getUltimoConsecutivo().toPromise();
  }
};
VistassService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
}];
VistassService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], VistassService);


/***/ }),

/***/ 77057:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/calendario-popover/calendario-popover.page.scss?ngResource ***!
  \**********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 49579);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60931);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 23673:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/registro-anticipos/registro-anticipos.page.scss?ngResource ***!
  \**********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 49579);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60931);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "ion-input, ion-select {\n  border-radius: 10px;\n  border: solid 1px rgb(218, 218, 218);\n  height: 2.5rem;\n}\n\nion-label {\n  font-weight: 500;\n}\n\n.description {\n  height: 4rem;\n}\n\n.has-focus {\n  border: 2px solid #5b9bd1 !important;\n}", "",{"version":3,"sources":["webpack://./src/app/pages/registro-anticipos/registro-anticipos.page.scss","webpack://./../../Simple%20Design%20Experience/Control%20Viaticos/src/app/pages/registro-anticipos/registro-anticipos.page.scss"],"names":[],"mappings":"AACA;EACI,mBAAA;EACA,oCAAA;EACA,cAAA;ACAJ;;ADGA;EACI,gBAAA;ACAJ;;ADEA;EACI,YAAA;ACCJ;;ADCA;EACI,oCAAA;ACEJ","sourcesContent":[" \r\nion-input, ion-select {\r\n    border-radius: 10px;\r\n    border: solid 1px rgba(218,218,218,1);\r\n    height: 2.5rem;\r\n}\r\n \r\nion-label{\r\n    font-weight: 500;\r\n}\r\n.description{\r\n    height: 4rem;\r\n}\r\n.has-focus{\r\n    border: 2px solid #5b9bd1 !important;\r\n}\r\n ","ion-input, ion-select {\n  border-radius: 10px;\n  border: solid 1px rgb(218, 218, 218);\n  height: 2.5rem;\n}\n\nion-label {\n  font-weight: 500;\n}\n\n.description {\n  height: 4rem;\n}\n\n.has-focus {\n  border: 2px solid #5b9bd1 !important;\n}"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 84344:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/calendario-popover/calendario-popover.page.html?ngResource ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\r\n\r\n<ion-content>\r\n  <ion-datetime\r\n [value]=\"fecha\"\r\n        #popoverDatetime2\r\n        presentation=\"date\"\r\n        [max]=\"max\"\r\n        (ionChange)=\"formatDate(popoverDatetime2.value)\"\r\n      ></ion-datetime>\r\n</ion-content>\r\n";

/***/ }),

/***/ 92941:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/registro-anticipos/registro-anticipos.page.html?ngResource ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header class=\"ion-no-border ion-padding\">\n<ion-row>\n  <ion-col size=\"12\">\n    <ion-toolbar>\n      <ion-title class=\"ion-text-capitalize\" class=\"page-title\"><strong>Registrar Anticipos</strong></ion-title>\n      <ion-button  *ngIf=\"usuarios.length > 0\" slot=\"end\"   (click)=\"generarPost()\" \n      fill=\"solid\" color=\"dark\">\n    Generar Anticipo\n    <ion-icon slot=\"end\"  name=\"arrow-forward\"></ion-icon>\n  </ion-button>\n  \n    </ion-toolbar>\n\n  </ion-col>\n \n</ion-row>\n</ion-header>\n<ion-content>\n  <ion-grid style=\"height: 100%;\">\n    <ion-row style=\"height: 100%;\" class=\"ion-padding\">\n\n\n      <ion-col size=\"12\">\n \n        <ion-grid>\n          <ion-row>\n\n\n\n            <ion-col size=\"12\">\n              <ion-row>\n                <ion-col size=\"3\">\n\n                  <ion-row>\n                    <ion-col size=\"12\">\n                      <ion-label><strong>Fecha Transacción</strong> </ion-label>\n                    </ion-col>\n                    <ion-col size=\"12\">\n                      <ion-input (click)=\"fecha('fechaTransaccion')\" readonly\n                        [value]=\"adelantoViatico.fechA_TRANSACCION  | date\" type=\"text\" placeholder=\"fecha\"></ion-input>\n                    </ion-col>\n                  </ion-row>\n\n                </ion-col>\n                <ion-col size=\"3\">\n\n                  <ion-row>\n                    <ion-col size=\"12\">\n                      <ion-label><strong>Fecha Inicial</strong></ion-label>\n                    </ion-col>\n                    <ion-col size=\"12\">\n                      <ion-input (click)=\"fecha('fechaInicial')\" readonly [value]=\"adelantoViatico.fechA_INICIAL  | date\"\n                        type=\"text\" placeholder=\"Fecha\"></ion-input>\n                    </ion-col>\n                  </ion-row>\n\n\n                </ion-col>\n                <ion-col size=\"3\">\n                  <ion-row>\n                    <ion-col size=\"12\">\n\n                      <ion-label><strong>Fecha Final</strong></ion-label>\n                    </ion-col>\n                    <ion-col size=\"12\">\n                      <ion-input readonly [value]=\"adelantoViatico.fechA_FINAL  | date\" type=\"text\"\n                        placeholder=\"Fecha\"></ion-input>\n                    </ion-col>\n                  </ion-row>\n\n\n\n                </ion-col>\n                <ion-col size=\"3\">\n                  <ion-row>\n                    <ion-col size=\"12\">\n                      <ion-label style=\"display: flex;justify-content: flex-start;align-items: center;\"><strong>Moneda </strong> <ion-badge style=\"margin-left: 0.5rem;\" color=\"primary\"\n                          mode=\"ios\">{{adelantoViatico.moneda}}</ion-badge></ion-label>\n                    </ion-col>\n                    <ion-col size=\"12\">\n    \n                      <ion-select [(ngModel)]=\"adelantoViatico.moneda\" placeholder=\"Seleccionar\">\n                        <ion-select-option value=\"₡\">Colones</ion-select-option>\n                        <ion-select-option value=\"$\">Dolares</ion-select-option>\n                      </ion-select>\n                    </ion-col>\n                  </ion-row>\n                </ion-col>\n                <ion-col size=\"3\">\n    \n                  <ion-row>\n                    <ion-col size=\"12\">\n                      <ion-label><strong>Justificación</strong></ion-label>\n                    </ion-col>\n                    <ion-col size=\"12\">\n                      <ion-input   name=\"detalle\" [(ngModel)]=\"adelantoViatico.detalle\"\n                        type=\"text\" placeholder=\"justificación\"></ion-input>\n                    </ion-col>\n                  </ion-row>\n    \n    \n    \n    \n                </ion-col>\n                <ion-col size=\"3\">\n                  <ion-row>\n                    <ion-col size=\"12\">\n                      <ion-label><strong>Compañia</strong></ion-label>\n                    </ion-col>\n                    <ion-col size=\"12\">\n                      <ion-select (ionChange)=\"compania($event)\" [(ngModel)]=\"adelantoViatico.coD_COMPANIA\"\n                        placeholder=\"Seleccionar\">\n                        <ion-select-option [value]=\"compania.cia\"\n                          *ngFor=\"let compania of clientes\">{{compania.cia}}</ion-select-option>\n\n                      </ion-select>\n                    </ion-col>\n                  </ion-row>\n                </ion-col>\n                <ion-col size=\"3\">\n                  <ion-row>\n                    <ion-col size=\"12\">\n                      <ion-label><strong># Transacción</strong></ion-label>\n                    </ion-col>\n                    <ion-col size=\"12\">\n                      <ion-input name=\"numero_transaccion\" [(ngModel)]=\"adelantoViatico.numerO_TRANSACCION\"\n                        type=\"text\" placeholder=\"número transacción\"></ion-input>\n                    </ion-col>\n                  </ion-row>\n\n\n\n                </ion-col>\n              </ion-row>\n\n   \n            </ion-col>\n\n\n\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"12\">\n           \n                <ion-grid>\n                  <ion-row>\n\n  \n                    <ion-col size=\"12\">\n\n                      <ion-toolbar>\n                        <ion-title><strong>Colaboradores</strong></ion-title>\n                        <ion-fab-button (click)=\"listaColaboradores()\" color=\"dark\" size=\"small\" slot=\"end\">\n                          <ion-icon name=\"add\"></ion-icon>\n                        </ion-fab-button>\n                      </ion-toolbar>\n                       <ion-list >\n\n                        <ion-item lines=\"none\" *ngIf=\"usuarios.length == 0\">\n\n                          <ion-grid>\n                            <ion-row>\n                          \n                              <ion-col size=\"12\" style=\"display: flex;justify-content: center;align-items: center;\">\n                                <img height=\"80\" src=\"assets/imgs/empty-box.svg\" alt=\"\" style=\"margin-right: 0.5rem;\">\n                                <strong  style=\"margin-top: 0.5rem;\">Selecciona un usuario para continuar!..</strong>\n                              </ion-col>\n                  \n                            </ion-row>\n                          </ion-grid>\n                  \n                        </ion-item>\n      <ion-grid >\n        <ion-row>\n          <ion-col size=\"6\"  *ngFor=\"let usuario of  usuarios; let i = index;\">\n            <ion-item lines=\"none\"   >\n                \n              <ion-avatar  slot=\"start\">\n                <img   src=\"../assets/imgs/user.svg\" />\n              </ion-avatar>\n    \n              <ion-label   >{{usuario.usuario}}</ion-label>\n              <ion-input (ionChange)=\"incrementarMonto(usuario, $event)\" class=\"input\" slot=\"end\" name=\"monto{{i}}\" [value]=\"usuario.monto\"  type=\"number\" placeholder=\"monto\"></ion-input>\n              <ion-fab-button (click)=\"borrarUsuario(i)\"   slot=\"end\"    size=\"small\" color=\"danger\">\n                <ion-icon name=\"trash\"></ion-icon>\n               </ion-fab-button>\n         \n\n     \n           \n            </ion-item>\n          </ion-col>\n        \n        </ion-row>\n      </ion-grid>\n                       </ion-list>\n                        \n                      \n                \n                \n                    </ion-col>\n         \n                    <ion-col size=\"12\" class=\"ion-padding \" *ngIf=\"adelantoViatico.monto > 0\">\n                      \n                      <ion-toolbar  class=\"ion-text-right\">\n                        <ion-title  style=\"margin-right: 4rem;\"><strong>Monto Total  {{ adelantoViatico.monto  | colones : 2 : '.' : ',' :  adelantoViatico.moneda }}</strong></ion-title>\n              \n                       </ion-toolbar>\n                    </ion-col>\n        \n        \n\n                  </ion-row>\n                </ion-grid>\n\n\n \n            </ion-col>\n\n\n          </ion-row>\n\n        </ion-grid>\n \n      </ion-col>\n    </ion-row>\n\n  </ion-grid>\n</ion-content>\n\n<app-pie-pagina></app-pie-pagina>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_registro-anticipos_registro-anticipos_module_ts.js.map