"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_services_companias_service_ts-src_app_services_departamentos_service_ts-src_a-f8fa17"],{

/***/ 65667:
/*!***********************************************!*\
  !*** ./src/app/services/companias.service.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CompaniasService": () => (/* binding */ CompaniasService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let CompaniasService = class CompaniasService {
  constructor(http) {
    this.http = http;
    this.companias = [];
  }
  getAPI(api) {
    let test = "";
    if (!src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.prdMode) test = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.TestURL;
    const URL = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.preURL + test + src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postURL + api;
    return URL;
  }
  getCompanias() {
    const URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getCompanias);
    console.log('URL', URL);
    return this.http.get(URL);
  }
  syncGetCompaniasToPromise() {
    return this.getCompanias().toPromise();
  }
};
CompaniasService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
}];
CompaniasService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], CompaniasService);


/***/ }),

/***/ 66646:
/*!***************************************************!*\
  !*** ./src/app/services/departamentos.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DepartamentosService": () => (/* binding */ DepartamentosService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 92340);




let DepartamentosService = class DepartamentosService {
  constructor(http) {
    this.http = http;
    this.departamentos = [];
  }
  getAPI(api) {
    let test = '';
    if (!_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.prdMode) test = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.TestURL;
    const URL = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.preURL + test + _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postURL + api;
    return URL;
  }
  getDepartamentos() {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getDepartamentos);
    console.log('URL', URL);
    return this.http.get(URL);
  }
  postDepartamento(departamento) {
    const URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postDepartamento);
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control': '*'
      }
    };
    return this.http.post(URL, departamento, options);
  }
  putDepartamento(departamento) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.putDepartamento);
    URL = URL + departamento.id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    };
    console.log(URL);
    console.log(departamento);
    return this.http.put(URL, departamento, options);
  }
  deleteDepartamento(id) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.deleteDepartamento);
    URL = URL + id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    };
    return this.http.delete(URL, options);
  }
  syncGetDepartamentoToPromise() {
    return this.getDepartamentos().toPromise();
  }
  syncPostDepartamentoToPromise(departamento) {
    return this.postDepartamento(departamento).toPromise();
  }
  syncPutDepartamentoToPromise(departamento) {
    return this.putDepartamento(departamento).toPromise();
  }
  syncDeleteDepartamentoToPromise(id) {
    return this.deleteDepartamento(id).toPromise();
  }
};
DepartamentosService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
}];
DepartamentosService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], DepartamentosService);


/***/ }),

/***/ 75444:
/*!***************************************************!*\
  !*** ./src/app/services/matriz-acceso.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MatrizAccesoService": () => (/* binding */ MatrizAccesoService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 92340);




let MatrizAccesoService = class MatrizAccesoService {
  constructor(http) {
    this.http = http;
    this.matrizAcceso = [];
  }
  getAPI(api) {
    let test = '';
    if (!_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.prdMode) test = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.TestURL;
    const URL = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.preURL + test + _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postURL + api;
    return URL;
  }
  getMatrizAccesos() {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getMatrizAcceso);
    console.log('URL', URL);
    return this.http.get(URL);
  }
  getMatrizAccesosID(id) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getMatrizAccesoUsuario);
    URL = URL + id;
    console.log('URL', URL);
    return this.http.get(URL);
  }
  getUsuariosMatrizAccesosID(id) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getUsuariosMstrizAcceso);
    URL = URL + id;
    console.log('URL', URL);
    return this.http.get(URL);
  }
  getMatrizAccesosBYID(id) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getMatrizAccesoBYID);
    URL = URL + id;
    console.log('URL', URL);
    return this.http.get(URL);
  }
  postMatrizAcceso(matrizAcceso) {
    const URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postMatrizAcceo);
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control': '*'
      }
    };
    return this.http.post(URL, matrizAcceso, options);
  }
  postUsuarioMatrizAcceso(usuarioMatrizAcceso) {
    const URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postUsuarioMatrizAcceo);
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control': '*'
      }
    };
    return this.http.post(URL, usuarioMatrizAcceso, options);
  }
  putMatrizAcceso(matrizAcceso) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.putMatrizAcceso);
    URL = URL + matrizAcceso.id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    };
    console.log(URL);
    console.log(matrizAcceso);
    return this.http.put(URL, matrizAcceso, options);
  }
  deleteMatrizAcceso(id) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.deleteMatrizAcceso);
    URL = URL + id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    };
    return this.http.delete(URL, options);
  }
  syncGetMatrizAccesotoToPromise() {
    return this.getMatrizAccesos().toPromise();
  }
  syncGetMatrizAccesoByIDtoToPromise(id) {
    return this.getMatrizAccesosID(id).toPromise();
  }
  syncGetMatrizAccesoIDtoToPromise(id) {
    return this.getMatrizAccesosBYID(id).toPromise();
  }
  syncGetUsuariosMatrizAccesoIDtoToPromise(id) {
    return this.getUsuariosMatrizAccesosID(id).toPromise();
  }
  syncPostMatrizAccesoToPromise(matrizAcceso) {
    return this.postMatrizAcceso(matrizAcceso).toPromise();
  }
  syncPostUsuarioMatrizAccesoToPromise(usuarioMatrizAcceso) {
    return this.postUsuarioMatrizAcceso(usuarioMatrizAcceso).toPromise();
  }
  syncPutMatrizAccesoToPromise(matrizAcceso) {
    return this.putMatrizAcceso(matrizAcceso).toPromise();
  }
  syncDeleteMatrizAccesoToPromise(id) {
    return this.deleteMatrizAcceso(id).toPromise();
  }
};
MatrizAccesoService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
}];
MatrizAccesoService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], MatrizAccesoService);


/***/ }),

/***/ 78423:
/*!***********************************************************!*\
  !*** ./src/app/services/modulos-matriz-acceso.service.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModulosMatrizAccesoService": () => (/* binding */ ModulosMatrizAccesoService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let ModulosMatrizAccesoService = class ModulosMatrizAccesoService {
  constructor(http) {
    this.http = http;
  }
  getAPI(api) {
    let test = '';
    if (!src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.prdMode) test = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.TestURL;
    const URL = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.preURL + test + src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postURL + api;
    return URL;
  }
  getModulosMatrizAccesosID(id) {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getMatrizAccesoModulosURL);
    URL = URL + id;
    console.log('URL', URL);
    return this.http.get(URL);
  }
  postModuloMatrizAcceso(matrizAcceso) {
    const URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postModuloMatrizAcceo);
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control': '*'
      }
    };
    return this.http.post(URL, matrizAcceso, options);
  }
  putModuloMatrizAcceso(matrizAcceso) {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.putMatrizAcceso);
    URL = URL + matrizAcceso.id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    };
    console.log(URL);
    console.log(matrizAcceso);
    return this.http.put(URL, matrizAcceso, options);
  }
  deleteModuloMatrizAcceso(id) {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.deleteModuloMatrizAcceso);
    URL = URL + id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    };
    return this.http.delete(URL, options);
  }
  syncGetModulosMatrizAccesoByIDtoToPromise(id) {
    return this.getModulosMatrizAccesosID(id).toPromise();
  }
  syncPostModuloMatrizAccesoToPromise(matrizAcceso) {
    return this.postModuloMatrizAcceso(matrizAcceso).toPromise();
  }
  syncPutModuloMatrizAccesoToPromise(matrizAcceso) {
    return this.putModuloMatrizAcceso(matrizAcceso).toPromise();
  }
  syncDeleteModuloMatrizAccesoToPromise(id) {
    return this.deleteModuloMatrizAcceso(id).toPromise();
  }
};
ModulosMatrizAccesoService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
}];
ModulosMatrizAccesoService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], ModulosMatrizAccesoService);


/***/ }),

/***/ 23191:
/*!*********************************************!*\
  !*** ./src/app/services/modulos.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModulosService": () => (/* binding */ ModulosService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let ModulosService = class ModulosService {
  constructor(http) {
    this.http = http;
    this.modulos = [];
  }
  getAPI(api) {
    let test = "";
    if (!src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.prdMode) test = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.TestURL;
    const URL = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.preURL + test + src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postURL + api;
    return URL;
  }
  getModulos() {
    const URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getModulos);
    console.log('URL', URL);
    return this.http.get(URL);
  }
  syncGetModulosToPromise() {
    return this.getModulos().toPromise();
  }
};
ModulosService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
}];
ModulosService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], ModulosService);


/***/ })

}]);
//# sourceMappingURL=default-src_app_services_companias_service_ts-src_app_services_departamentos_service_ts-src_a-f8fa17.js.map