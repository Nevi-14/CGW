(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_pages_cierre-contable-linea-anticipo_cierre-contable-linea-anticipo_page_ts-s-43138b"],{

/***/ 37472:
/*!*********************************************************************************************!*\
  !*** ./src/app/pages/cierre-contable-linea-anticipo/cierre-contable-linea-anticipo.page.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CierreContableLineaAnticipoPage": () => (/* binding */ CierreContableLineaAnticipoPage)
/* harmony export */ });
/* harmony import */ var C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _cierre_contable_linea_anticipo_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cierre-contable-linea-anticipo.page.html?ngResource */ 38596);
/* harmony import */ var _cierre_contable_linea_anticipo_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./cierre-contable-linea-anticipo.page.scss?ngResource */ 33702);
/* harmony import */ var _cierre_contable_linea_anticipo_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_cierre_contable_linea_anticipo_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! date-fns */ 86712);
/* harmony import */ var src_app_services_adelanto_viaticos_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/adelanto-viaticos.service */ 45406);
/* harmony import */ var src_app_services_cierre_contable_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/cierre-contable.service */ 46926);
/* harmony import */ var src_app_services_proceso_contable_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/proceso-contable.service */ 41754);
/* harmony import */ var src_app_services_usuarios_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/usuarios.service */ 81209);











let CierreContableLineaAnticipoPage = class CierreContableLineaAnticipoPage {
  constructor(modalCtrl, adelantosService, procesoContableService, usuariosService, cierreContableService) {
    this.modalCtrl = modalCtrl;
    this.adelantosService = adelantosService;
    this.procesoContableService = procesoContableService;
    this.usuariosService = usuariosService;
    this.cierreContableService = cierreContableService;
    this.gastos = [];
    this.asientoDiario = null;
    this.diario = [];
    this.movDirSobrante = null;
    this.asientoDiarioSobrante = null;
    this.diarioSobrante = [];
  }
  ngOnInit() {
    console.log(this.adelantosService.adelantoViatico, 'anticipo');
    // Diario
    let referencia = `Liquidación de viáticos ${(0,date_fns__WEBPACK_IMPORTED_MODULE_7__["default"])(new Date(this.adelantosService.adelantoViatico.fechA_INICIAL), 'MM/dd/yyyy')} + ${(0,date_fns__WEBPACK_IMPORTED_MODULE_7__["default"])(new Date(this.adelantosService.adelantoViatico.fechA_FINAL), 'MM/dd/yyyy')}`;
    // DIARIO
    this.diario.push(this.cierreContableService.generarDiario('1-01-02-002-007', referencia, false, 0, true, this.linea.utilizado));
    this.diario.push(this.cierreContableService.generarDiario('1-01-05-004-011', referencia, true, this.linea.utilizado, false, 0));
    this.diario.push(this.cierreContableService.generarDiario('7-99-01-009-000', referencia, true, this.linea.utilizado, false, 0));
    let notas = `Liquidación de viáticos ${(0,date_fns__WEBPACK_IMPORTED_MODULE_7__["default"])(new Date(this.adelantosService.adelantoViatico.fechA_INICIAL), 'MM/dd/yyyy')} + ${(0,date_fns__WEBPACK_IMPORTED_MODULE_7__["default"])(new Date(this.adelantosService.adelantoViatico.fechA_FINAL), 'MM/dd/yyyy')}`;
    this.asientoDiario = this.cierreContableService.generarAsiento(this.linea.utilizado, notas);
    let notas2 = `Sobrante Anticipo + ${(0,date_fns__WEBPACK_IMPORTED_MODULE_7__["default"])(new Date(this.adelantosService.adelantoViatico.fechA_INICIAL), 'MM/dd/yyyy')} + ${(0,date_fns__WEBPACK_IMPORTED_MODULE_7__["default"])(new Date(this.adelantosService.adelantoViatico.fechA_FINAL), 'MM/dd/yyyy')}`;
    this.asientoDiarioSobrante = this.cierreContableService.generarAsiento(this.linea.restante, notas2);
    let concepto = `Sobrante 
    Anticipo +
    ${(0,date_fns__WEBPACK_IMPORTED_MODULE_7__["default"])(new Date(this.adelantosService.adelantoViatico.fechA_INICIAL), 'MM/dd/yyyy')} +
    ${(0,date_fns__WEBPACK_IMPORTED_MODULE_7__["default"])(new Date(this.adelantosService.adelantoViatico.fechA_FINAL), 'MM/dd/yyyy')}`;
    this.movDirSobrante = this.cierreContableService.generarMovDir(this.linea.restante, concepto);
    if (this.linea.restante > 0) {
      let referencia2 = `Sobrante 
  Anticipo +  ${(0,date_fns__WEBPACK_IMPORTED_MODULE_7__["default"])(new Date(this.adelantosService.adelantoViatico.fechA_INICIAL), 'MM/dd/yyyy')} + ${(0,date_fns__WEBPACK_IMPORTED_MODULE_7__["default"])(new Date(this.adelantosService.adelantoViatico.fechA_FINAL), 'MM/dd/yyyy')}`;
      this.diarioSobrante.push(this.cierreContableService.generarDiario('1-01-02-002-007', referencia2, true, this.linea.restante, false, 0));
      this.diarioSobrante.push(this.cierreContableService.generarDiario('1-01-05-004-011', referencia2, false, 0, true, this.linea.restante));
      this.diarioSobrante.push(this.cierreContableService.generarDiario('7-99-01-009-000', referencia2, true, this.linea.restante, false, 0));
    }
  }
  cerrarModal() {
    this.modalCtrl.dismiss();
  }
  generarPost() {
    var _this = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.procesoContableService.syncPostAsientoDiarioToPromise(_this.asientoDiario);
      yield _this.procesoContableService.syncPostDiarioToPromise(_this.diario);
    })();
  }
};
CierreContableLineaAnticipoPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController
}, {
  type: src_app_services_adelanto_viaticos_service__WEBPACK_IMPORTED_MODULE_3__.AdelantoViaticosService
}, {
  type: src_app_services_proceso_contable_service__WEBPACK_IMPORTED_MODULE_5__.ProcesoContableService
}, {
  type: src_app_services_usuarios_service__WEBPACK_IMPORTED_MODULE_6__.UsuariosService
}, {
  type: src_app_services_cierre_contable_service__WEBPACK_IMPORTED_MODULE_4__.CierreContableService
}];
CierreContableLineaAnticipoPage.propDecorators = {
  linea: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Input
  }],
  gastos: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Input
  }]
};
CierreContableLineaAnticipoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-cierre-contable-linea-anticipo',
  template: _cierre_contable_linea_anticipo_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_cierre_contable_linea_anticipo_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], CierreContableLineaAnticipoPage);


/***/ }),

/***/ 24586:
/*!***************************************!*\
  !*** ./src/app/pipes/colones.pipe.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColonesPipe": () => (/* binding */ ColonesPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);


let ColonesPipe = class ColonesPipe {
  transform(amount, decimalCount = 2, decimal = ".", thousands = ",", moneda = "¢") {
    decimalCount = Math.abs(decimalCount);
    decimalCount = isNaN(decimalCount) ? 2 : decimalCount;
    const negativeSign = amount < 0 ? "-" : "";
    let i = parseInt(amount = Math.abs(Number(amount) || 0).toFixed(decimalCount)).toString();
    let j = i.length > 3 ? i.length % 3 : 0;
    return negativeSign + moneda + (j ? i.substr(0, j) + thousands : '') + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands) + (decimalCount ? decimal + Math.abs(amount - Number(i)).toFixed(decimalCount).slice(2) : "");
  }
};
ColonesPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
  name: 'colones'
})], ColonesPipe);


/***/ }),

/***/ 79146:
/*!**************************************!*\
  !*** ./src/app/pipes/filtro.pipe.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FiltroPipe": () => (/* binding */ FiltroPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);


let FiltroPipe = class FiltroPipe {
  transform(arreglo, texto = '', columna = '') {
    if (texto === '') {
      return arreglo;
    }
    if (!arreglo) {
      return arreglo;
    }
    // todas las busquedas de javascript son case sentisive
    texto = texto.toLocaleLowerCase();
    //  return null;
    return arreglo.filter(
    //  item=> item.title.toLocaleLowerCase().includes(texto)
    item => item[columna].toLocaleLowerCase().includes(texto));
  }
};
FiltroPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
  name: 'filtro'
})], FiltroPipe);


/***/ }),

/***/ 35503:
/*!***************************************!*\
  !*** ./src/app/pipes/pipes.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PipesModule": () => (/* binding */ PipesModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _filtro_pipe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./filtro.pipe */ 79146);
/* harmony import */ var _colones_pipe__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./colones.pipe */ 24586);





let PipesModule = class PipesModule {};
PipesModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
  declarations: [_filtro_pipe__WEBPACK_IMPORTED_MODULE_0__.FiltroPipe, _colones_pipe__WEBPACK_IMPORTED_MODULE_1__.ColonesPipe],
  exports: [_filtro_pipe__WEBPACK_IMPORTED_MODULE_0__.FiltroPipe, _angular_common__WEBPACK_IMPORTED_MODULE_4__.DatePipe, _colones_pipe__WEBPACK_IMPORTED_MODULE_1__.ColonesPipe],
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule]
})], PipesModule);


/***/ }),

/***/ 46926:
/*!*****************************************************!*\
  !*** ./src/app/services/cierre-contable.service.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CierreContableService": () => (/* binding */ CierreContableService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _adelanto_viaticos_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./adelanto-viaticos.service */ 45406);
/* harmony import */ var _proceso_contable_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./proceso-contable.service */ 41754);
/* harmony import */ var _usuarios_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./usuarios.service */ 81209);





let CierreContableService = class CierreContableService {
  constructor(adelantosService, procesoContableService, usuariosService) {
    this.adelantosService = adelantosService;
    this.procesoContableService = procesoContableService;
    this.usuariosService = usuariosService;
  }
  generarMovDir(monto, concepto) {
    let movDir = {
      id: this.adelantosService.adelantoViatico.numerO_TRANSACCION,
      tipO_GASTO: 'N/D',
      tipo: 'N/D',
      suB_TIPO: 'N/D',
      fecha: new Date(),
      monto: monto,
      tipO_ASIENTO: 'CB',
      paquete: 'CB',
      concepto: concepto,
      nuM_ASIENTO: 'null'
    };
    return movDir;
  }
  generarAsiento(totaL_CREDITO_LOC, notas) {
    let asientoDiario = {
      id: null,
      coD_COMPANIA: this.adelantosService.adelantoViatico.coD_COMPANIA,
      asiento: null,
      paquete: 'CB',
      tipO_ASIENTO: 'CB',
      fecha: new Date(),
      contabilidad: 'C',
      origen: 'CB',
      clasE_ASIENTO: 'C',
      totaL_DEBITO_LOC: null,
      totaL_DEBITO_DOL: null,
      totaL_CREDITO_LOC: totaL_CREDITO_LOC,
      totaL_CREDITO_DOL: null,
      ultimO_USUARIO: this.usuariosService.usuario.usuario,
      fechA_ULT_MODIF: new Date(),
      marcado: 'N',
      notas: notas,
      totaL_CONTROL_LOC: null,
      totaL_CONTROL_DOL: null,
      usuariO_CREACION: this.usuariosService.usuario.usuario,
      fechA_CREACION: new Date(),
      rowPointer: null,
      dependencia: null,
      noteExistingFlag: null,
      recordDate: new Date(),
      createdBy: this.usuariosService.usuario.usuario,
      updatedBy: this.usuariosService.usuario.usuario,
      createdDate: new Date(),
      documentO_GLOBAL: null
    };
    return asientoDiario;
  }
  generarDiario(cuentA_CONTABLE, referencia, dbL, debitO_LOCAL, cL, creditO_LOCAL) {
    let diario = {
      id: null,
      coD_COMPANIA: this.adelantosService.adelantoViatico.coD_COMPANIA,
      asiento: null,
      consecutivo: 0,
      nit: null,
      centrO_COSTO: '00-00-00',
      cuentA_CONTABLE: cuentA_CONTABLE,
      fuente: 'fuente',
      referencia: referencia,
      debitO_LOCAL: dbL ? debitO_LOCAL : null,
      debitO_DOLAR: null,
      creditO_LOCAL: cL ? creditO_LOCAL : null,
      creditO_DOLAR: null,
      debitO_UNIDADES: 0,
      creditO_UNIDADES: 0,
      tipO_CAMBIO: 0,
      rowPointer: null,
      basE_LOCAL: 0,
      basE_DOLAR: 0,
      proyecto: null,
      fase: null,
      noteExistingFlag: 0,
      recordDate: new Date(),
      createdBy: this.usuariosService.usuario.usuario,
      updatedBy: this.usuariosService.usuario.usuario,
      createdDate: new Date(),
      documentO_GLOBAL: null
    };
    return diario;
  }
};
CierreContableService.ctorParameters = () => [{
  type: _adelanto_viaticos_service__WEBPACK_IMPORTED_MODULE_0__.AdelantoViaticosService
}, {
  type: _proceso_contable_service__WEBPACK_IMPORTED_MODULE_1__.ProcesoContableService
}, {
  type: _usuarios_service__WEBPACK_IMPORTED_MODULE_2__.UsuariosService
}];
CierreContableService = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)({
  providedIn: 'root'
})], CierreContableService);


/***/ }),

/***/ 41754:
/*!******************************************************!*\
  !*** ./src/app/services/proceso-contable.service.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProcesoContableService": () => (/* binding */ ProcesoContableService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let ProcesoContableService = class ProcesoContableService {
  constructor(http) {
    this.http = http;
  }
  getAPI(api) {
    let test = '';
    if (!src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.prdMode) test = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.TestURL;
    const URL = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.preURL + test + src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postURL + api;
    return URL;
  }
  getMovDir() {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getMovDir);
    return this.http.get(URL);
  }
  getAsientoDiario() {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getAsientoDiario);
    return this.http.get(URL);
  }
  getDiario() {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getDiario);
    return this.http.get(URL);
  }
  postMovDir(post) {
    const URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postMovDir);
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Origin': '*'
      }
    };
    console.log('URL', URL);
    console.log('post', post);
    return this.http.post(URL, post, options);
  }
  postAsientoDiario(post) {
    const URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postAsientoDiario);
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Origin': '*'
      }
    };
    console.log('URL', URL);
    console.log('post', post);
    return this.http.post(URL, post, options);
  }
  postDiario(post) {
    const URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postDiario);
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Origin': '*'
      }
    };
    console.log('URL', URL);
    console.log('post', post);
    return this.http.post(URL, post, options);
  }
  syncGetMovDirToPromise() {
    return this.getMovDir().toPromise();
  }
  syncGetAsientoDiario() {
    return this.getAsientoDiario().toPromise();
  }
  syncGetDiario() {
    return this.getDiario().toPromise();
  }
  syncPostMovDirToPromise(post) {
    return this.postMovDir(post).toPromise();
  }
  syncPostAsientoDiarioToPromise(post) {
    return this.postAsientoDiario(post).toPromise();
  }
  syncPostDiarioToPromise(post) {
    return this.postDiario(post).toPromise();
  }
};
ProcesoContableService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
}];
ProcesoContableService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], ProcesoContableService);


/***/ }),

/***/ 33702:
/*!**********************************************************************************************************!*\
  !*** ./src/app/pages/cierre-contable-linea-anticipo/cierre-contable-linea-anticipo.page.scss?ngResource ***!
  \**********************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 49579);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60931);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".odd {\n  --background:#fff;\n}\n\n.even {\n  --background: #CCC;\n}\n\nion-title {\n  font-size: 16px;\n  font-weight: bold;\n  color: #000;\n}", "",{"version":3,"sources":["webpack://./src/app/pages/cierre-contable-linea-anticipo/cierre-contable-linea-anticipo.page.scss","webpack://./../../Simple%20Design%20Experience/Control%20Viaticos/src/app/pages/cierre-contable-linea-anticipo/cierre-contable-linea-anticipo.page.scss"],"names":[],"mappings":"AAAA;EACE,iBAAA;ACCF;;ADCE;EACE,kBAAA;ACEJ;;ADAE;EACE,eAAA;EACA,iBAAA;EACA,WAAA;ACGJ","sourcesContent":[".odd{\r\n  --background:#fff;\r\n  }\r\n  .even{\r\n    --background: #CCC;\r\n  }\r\n  ion-title{\r\n    font-size: 16px;\r\n    font-weight: bold;\r\n    color: #000;\r\n  }",".odd {\n  --background:#fff;\n}\n\n.even {\n  --background: #CCC;\n}\n\nion-title {\n  font-size: 16px;\n  font-weight: bold;\n  color: #000;\n}"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 38596:
/*!**********************************************************************************************************!*\
  !*** ./src/app/pages/cierre-contable-linea-anticipo/cierre-contable-linea-anticipo.page.html?ngResource ***!
  \**********************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header class=\"ion-no-border\" >\n  <ion-toolbar>\n    <ion-button (click)=\"cerrarModal()\"   fill=\"clear\"  slot=\"start\">\n     <ion-icon slot=\"icon-only\" name=\"arrow-back\"></ion-icon>\n    </ion-button>\n    <ion-title>Cierre Contable Linea Anticipo</ion-title>\n\n\n  </ion-toolbar>\n\n</ion-header>\n\n<ion-content>\n <ion-list class=\"ion-margin\" style=\"border: 2px solid black;padding: 0;\">\n  <ion-item color=\"dark\" >\n    <ion-grid >\n      <ion-row>\n \n        <ion-col size=\"2\">\n          <strong>FECHA</strong>\n        </ion-col>\n        <ion-col size=\"2\">\n          <strong>CÓDIGO</strong>\n        </ion-col>\n        <ion-col size=\"3\">\n          <strong>DESCRIPCIÓN</strong>\n        </ion-col>\n        <ion-col size=\"5\">\n     <ion-row>\n      <ion-col size=\"6\">\n        <strong>DEBE</strong>\n      </ion-col>\n      <ion-col size=\"6\">\n        <strong>HABER</strong>\n      </ion-col>\n     </ion-row>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-item>\n<ion-item    lines=\"full\">\n  <ion-grid >\n    <ion-row>\n      <ion-col size=\"2\">\n    \n      </ion-col>\n      <ion-col size=\"2\">\n        {{linea.id}}\n      </ion-col>\n      <ion-col size=\"3\">\n        Linea Anticipo\n      </ion-col>\n      <ion-col size=\"5\">\n   <ion-row>\n    <ion-col size=\"6\">\n  \n    </ion-col>\n    <ion-col size=\"6\" style=\"font-size: 14px;\" class=\"ion-text-left\">\n      {{linea.monto | colones : 2 : '.' : ',' :  adelantosService.adelantoViatico.moneda}}\n    </ion-col>\n   </ion-row>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-item>\n<ion-item *ngFor=\"let gasto of gastos; let i = index;\"  lines=\"full\">\n  <ion-grid >\n    <ion-row>\n      <ion-col size=\"2\">\n        {{gasto.fecha | date}}\n        </ion-col>\n      <ion-col size=\"2\">\n      G-{{gasto.iD_TIPO_GASTO}}\n      </ion-col>\n      <ion-col size=\"4\">\n        {{gasto.descripcion}}\n      </ion-col>\n      <ion-col size=\"4\">\n   <ion-row>\n    <ion-col size=\"6\" style=\"font-size: 14px;\" class=\"ion-text-left\">\n      {{gasto.monto | colones : 2 : '.' : ',' :  adelantosService.adelantoViatico.moneda}}\n    </ion-col>\n    <ion-col size=\"6\">\n      \n    </ion-col>\n   </ion-row>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-item>\n<ion-item  >\n  <ion-grid >\n    <ion-row>\n      <ion-col size=\"2\">\n       \n        </ion-col>\n      <ion-col size=\"2\">\n       \n      </ion-col>\n      <ion-col size=\"4\">\n        Cuenta Por Pagar\n      </ion-col>\n      <ion-col size=\"4\">\n   <ion-row>\n    <ion-col size=\"6\" style=\"font-size: 14px;\" class=\"ion-text-left\">\n      {{linea.restante | colones : 2 : '.' : ',' :  adelantosService.adelantoViatico.moneda }}\n    </ion-col>\n    <ion-col size=\"6\" style=\"font-size: 14px;\" class=\"ion-text-left\">\n   \n    </ion-col>\n   </ion-row>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-item>\n<ion-item  lines=\"full\">\n  <ion-grid >\n    <ion-row>\n      <ion-col size=\"12\">\n       Sobrante Linea Anticipo\n        </ion-col>\n       \n   </ion-row>\n     \n  </ion-grid>\n</ion-item>\n<ion-item lines=\"none\" >\n  <ion-grid >\n    <ion-row >\n      <ion-col size=\"2\" style=\"border-bottom: 2px solid black;padding: 0;\">\n       \n        </ion-col>\n      <ion-col size=\"2\" style=\"border-bottom: 2px solid black;padding: 0;\">\n       \n      </ion-col>\n      <ion-col size=\"4\" class=\"ion-text-right\" style=\"border-bottom: 2px solid black;padding: 0;\">\n      <h3 style=\"margin: 0;\"><strong>//</strong></h3>\n      </ion-col>\n      <ion-col size=\"4\" style=\"border-bottom: 2px solid black;padding: 0;\">\n   <ion-row>\n    <ion-col size=\"6\">\n      \n    </ion-col>\n    <ion-col size=\"6\">\n       \n    </ion-col>\n   </ion-row>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-item>\n\n </ion-list>\n\n\n <ion-list>\n  <ion-toolbar>\n    <ion-title>Liquidación Linea Anticipo</ion-title>\n  </ion-toolbar>\n<ion-toolbar>\n  <ion-title>Asiento De Diario</ion-title>\n</ion-toolbar>\n  <ion-item>\n <ion-grid >\n  <ion-row>\n    <ion-col size=\"2\"><strong># Asiento</strong></ion-col>\n    <ion-col size=\"2\"><strong>Tipo</strong></ion-col>\n    <ion-col size=\"2\"><strong>Paquete</strong></ion-col>\n    <ion-col size=\"2\"><strong>Concepto</strong></ion-col>\n    <ion-col size=\"2\"><strong>Monto</strong></ion-col>\n    <ion-col size=\"2\"><strong>Fecha</strong></ion-col>\n  </ion-row>\n </ion-grid>\n  </ion-item>\n  <ion-item>\n    <ion-grid >\n     <ion-row style=\"font-size: 14px;\" class=\"ion-text-left\">\n       <ion-col size=\"2\">\n        {{asientoDiario.asiento}}\n       </ion-col>\n       <ion-col size=\"2\">\n        {{asientoDiario.tipO_ASIENTO}}\n       </ion-col>\n       <ion-col size=\"2\">\n        {{asientoDiario.paquete}}\n       </ion-col>\n       <ion-col size=\"2\">\n        {{asientoDiario.notas}}\n       </ion-col>\n       <ion-col size=\"2\">\n        {{asientoDiario.totaL_CREDITO_LOC  | colones : 2 : '.' : ',' :  adelantosService.adelantoViatico.moneda }}\n       </ion-col>\n       <ion-col size=\"2\">\n        {{asientoDiario.fecha | date}}\n       </ion-col>\n     </ion-row>\n    </ion-grid>\n     </ion-item>\n </ion-list>\n\n <ion-list>\n  <ion-toolbar>\n    <ion-title>Diario</ion-title>\n  </ion-toolbar>\n    <ion-item>\n   <ion-grid >\n    <ion-row>\n      <ion-col size=\"2\"><strong># Asiento</strong></ion-col>\n      <ion-col size=\"2\"><strong>CeCosto</strong></ion-col>\n      <ion-col size=\"2\"><strong>CuConta</strong></ion-col>\n      <ion-col size=\"2\"><strong>Deb Total</strong></ion-col>\n      <ion-col size=\"2\"><strong>Cred Local</strong></ion-col>\n      <ion-col size=\"2\"><strong>Referencia</strong></ion-col>\n    </ion-row>\n   </ion-grid>\n    </ion-item>\n    <ion-item *ngFor=\"let diario of diario\">\n      <ion-grid >\n       <ion-row style=\"font-size: 14px;\" class=\"ion-text-left\">\n         <ion-col size=\"2\">\n          {{diario.asiento}}\n\n         </ion-col>\n         <ion-col size=\"2\">\n          {{diario.centrO_COSTO   }}\n         </ion-col>\n         <ion-col size=\"2\">\n          {{diario.cuentA_CONTABLE   }}\n         </ion-col>\n         <ion-col size=\"2\">\n          {{diario.debitO_LOCAL  | colones : 2 : '.' : ',' :  adelantosService.adelantoViatico.moneda }}\n         </ion-col>\n         <ion-col size=\"2\">\n          {{diario.creditO_LOCAL  | colones : 2 : '.' : ',' :  adelantosService.adelantoViatico.moneda }}\n         </ion-col>\n         <ion-col size=\"2\">\n          {{diario.referencia}}\n         </ion-col>\n       </ion-row>\n      </ion-grid>\n       </ion-item>\n       \n   </ion-list>\n\n   <ion-list *ngIf=\"diarioSobrante.length > 0\">\n    <ion-toolbar>\n      <ion-title>Liquidación Linea Sobrantes</ion-title>\n    </ion-toolbar>\n    <ion-toolbar>\n      <ion-title>Movimiento</ion-title>\n    </ion-toolbar>\n    <ion-item>\n      <ion-grid >\n       <ion-row>\n         <ion-col size=\"2\"><strong>Monto</strong></ion-col>\n         <ion-col size=\"2\"><strong>Fecha</strong></ion-col>\n         <ion-col size=\"2\"><strong>TipoAsiento</strong></ion-col>\n         <ion-col size=\"2\"><strong>Paquete</strong></ion-col>\n         <ion-col size=\"2\"><strong>Concepto</strong></ion-col>\n         <ion-col size=\"2\"><strong>Asiento</strong></ion-col>\n       </ion-row>\n      </ion-grid>\n       </ion-item>\n       <ion-item>\n         <ion-grid >\n          <ion-row style=\"font-size: 14px;\" class=\"ion-text-left\">\n            <ion-col size=\"2\">\n              {{movDirSobrante.monto  | colones : 2 : '.' : ',' :  adelantosService.adelantoViatico.moneda  }}\n            </ion-col>\n            <ion-col size=\"2\">\n              {{movDirSobrante.fecha | date }}\n            </ion-col>\n            <ion-col size=\"2\">\n              {{movDirSobrante.tipO_ASIENTO}}\n            </ion-col>\n            <ion-col size=\"2\">\n              {{movDirSobrante.paquete}}\n            </ion-col>\n            <ion-col size=\"2\">\n              {{movDirSobrante.concepto}}\n            </ion-col>\n            <ion-col size=\"2\">\n              {{movDirSobrante.nuM_ASIENTO ? movDirSobrante.nuM_ASIENTO : ''}}\n            </ion-col>\n          </ion-row>\n         </ion-grid>\n          </ion-item>\n  <ion-toolbar>\n    <ion-title>Asiento De Diario</ion-title>\n  </ion-toolbar>\n    <ion-item>\n   <ion-grid >\n    <ion-row>\n      <ion-col size=\"2\"><strong># Asiento</strong></ion-col>\n      <ion-col size=\"2\"><strong>Tipo</strong></ion-col>\n      <ion-col size=\"2\"><strong>Paquete</strong></ion-col>\n      <ion-col size=\"2\"><strong>Concepto</strong></ion-col>\n      <ion-col size=\"2\"><strong>Monto</strong></ion-col>\n      <ion-col size=\"2\"><strong>Fecha</strong></ion-col>\n    </ion-row>\n   </ion-grid>\n    </ion-item>\n    <ion-item>\n      <ion-grid >\n       <ion-row style=\"font-size: 14px;\" class=\"ion-text-left\">\n         <ion-col size=\"2\">\n        \n         </ion-col>\n         <ion-col size=\"2\">\n          {{asientoDiarioSobrante.tipO_ASIENTO}}\n         </ion-col>\n         <ion-col size=\"2\">\n          {{asientoDiarioSobrante.paquete}}\n         </ion-col>\n         <ion-col size=\"2\">\n          {{asientoDiarioSobrante.notas}}\n         </ion-col>\n         <ion-col size=\"2\">\n          {{asientoDiarioSobrante.totaL_CREDITO_LOC  | colones : 2 : '.' : ',' :  adelantosService.adelantoViatico.moneda }}\n         </ion-col>\n         <ion-col size=\"2\">\n          {{asientoDiarioSobrante.fecha | date}}\n         </ion-col>\n       </ion-row>\n      </ion-grid>\n       </ion-item>\n   </ion-list>\n  \n   <ion-list>\n    <ion-toolbar>\n      <ion-title>Diario</ion-title>\n    </ion-toolbar>\n      <ion-item>\n     <ion-grid >\n      <ion-row>\n        <ion-col size=\"2\"><strong># Asiento</strong></ion-col>\n        <ion-col size=\"2\"><strong>CeCosto</strong></ion-col>\n        <ion-col size=\"2\"><strong>CuConta</strong></ion-col>\n        <ion-col size=\"2\"><strong>Deb Total</strong></ion-col>\n        <ion-col size=\"2\"><strong>Cred Local</strong></ion-col>\n        <ion-col size=\"2\"><strong>Referencia</strong></ion-col>\n      </ion-row>\n     </ion-grid>\n      </ion-item>\n      <ion-item *ngFor=\"let diario of diarioSobrante\">\n        <ion-grid >\n         <ion-row style=\"font-size: 14px;\" class=\"ion-text-left\">\n           <ion-col size=\"2\">\n            {{diario.asiento}}\n  \n           </ion-col>\n           <ion-col size=\"2\">\n            {{diario.centrO_COSTO   }}\n           </ion-col>\n           <ion-col size=\"2\">\n            {{diario.cuentA_CONTABLE   }}\n           </ion-col>\n           <ion-col size=\"2\">\n            {{diario.debitO_LOCAL  | colones : 2 : '.' : ',' :  adelantosService.adelantoViatico.moneda }}\n           </ion-col>\n           <ion-col size=\"2\">\n            {{diario.creditO_LOCAL  | colones : 2 : '.' : ',' :  adelantosService.adelantoViatico.moneda }}\n           </ion-col>\n           <ion-col size=\"2\">\n            {{diario.referencia}}\n           </ion-col>\n         </ion-row>\n        </ion-grid>\n         </ion-item>\n         \n     </ion-list>\n</ion-content>\n\n<ion-footer   (click)=\"cerrarModal()\" class=\"ion-no-border ion-padding\">\n  <ion-toolbar>\n    <ion-button  expand=\"block\" fill=\"solid\" color=\"dark\">\n Liquidar Cierre Contable Linea Anticipo\n      </ion-button>\n  </ion-toolbar>\n </ion-footer>";

/***/ })

}]);
//# sourceMappingURL=default-src_app_pages_cierre-contable-linea-anticipo_cierre-contable-linea-anticipo_page_ts-s-43138b.js.map