"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_editar-usuario_editar-usuario_module_ts-src_app_services_matriz-acceso_service_-3c9318"],{

/***/ 16940:
/*!***********************************************************************!*\
  !*** ./src/app/pages/editar-usuario/editar-usuario-routing.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditarUsuarioPageRoutingModule": () => (/* binding */ EditarUsuarioPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _editar_usuario_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./editar-usuario.page */ 3450);




const routes = [{
  path: '',
  component: _editar_usuario_page__WEBPACK_IMPORTED_MODULE_0__.EditarUsuarioPage
}];
let EditarUsuarioPageRoutingModule = class EditarUsuarioPageRoutingModule {};
EditarUsuarioPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
  imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
  exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
})], EditarUsuarioPageRoutingModule);


/***/ }),

/***/ 51433:
/*!***************************************************************!*\
  !*** ./src/app/pages/editar-usuario/editar-usuario.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditarUsuarioPageModule": () => (/* binding */ EditarUsuarioPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _editar_usuario_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./editar-usuario-routing.module */ 16940);
/* harmony import */ var _editar_usuario_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./editar-usuario.page */ 3450);







let EditarUsuarioPageModule = class EditarUsuarioPageModule {};
EditarUsuarioPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule, _editar_usuario_routing_module__WEBPACK_IMPORTED_MODULE_0__.EditarUsuarioPageRoutingModule],
  declarations: [_editar_usuario_page__WEBPACK_IMPORTED_MODULE_1__.EditarUsuarioPage]
})], EditarUsuarioPageModule);


/***/ }),

/***/ 75444:
/*!***************************************************!*\
  !*** ./src/app/services/matriz-acceso.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MatrizAccesoService": () => (/* binding */ MatrizAccesoService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 92340);




let MatrizAccesoService = class MatrizAccesoService {
  constructor(http) {
    this.http = http;
    this.matrizAcceso = [];
  }
  getAPI(api) {
    let test = '';
    if (!_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.prdMode) test = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.TestURL;
    const URL = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.preURL + test + _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postURL + api;
    return URL;
  }
  getMatrizAccesos() {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getMatrizAcceso);
    console.log('URL', URL);
    return this.http.get(URL);
  }
  getMatrizAccesosID(id) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getMatrizAccesoUsuario);
    URL = URL + id;
    console.log('URL', URL);
    return this.http.get(URL);
  }
  getUsuariosMatrizAccesosID(id) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getUsuariosMstrizAcceso);
    URL = URL + id;
    console.log('URL', URL);
    return this.http.get(URL);
  }
  getMatrizAccesosBYID(id) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getMatrizAccesoBYID);
    URL = URL + id;
    console.log('URL', URL);
    return this.http.get(URL);
  }
  postMatrizAcceso(matrizAcceso) {
    const URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postMatrizAcceo);
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control': '*'
      }
    };
    return this.http.post(URL, matrizAcceso, options);
  }
  postUsuarioMatrizAcceso(usuarioMatrizAcceso) {
    const URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postUsuarioMatrizAcceo);
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control': '*'
      }
    };
    return this.http.post(URL, usuarioMatrizAcceso, options);
  }
  putMatrizAcceso(matrizAcceso) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.putMatrizAcceso);
    URL = URL + matrizAcceso.id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    };
    console.log(URL);
    console.log(matrizAcceso);
    return this.http.put(URL, matrizAcceso, options);
  }
  deleteMatrizAcceso(id) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.deleteMatrizAcceso);
    URL = URL + id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    };
    return this.http.delete(URL, options);
  }
  syncGetMatrizAccesotoToPromise() {
    return this.getMatrizAccesos().toPromise();
  }
  syncGetMatrizAccesoByIDtoToPromise(id) {
    return this.getMatrizAccesosID(id).toPromise();
  }
  syncGetMatrizAccesoIDtoToPromise(id) {
    return this.getMatrizAccesosBYID(id).toPromise();
  }
  syncGetUsuariosMatrizAccesoIDtoToPromise(id) {
    return this.getUsuariosMatrizAccesosID(id).toPromise();
  }
  syncPostMatrizAccesoToPromise(matrizAcceso) {
    return this.postMatrizAcceso(matrizAcceso).toPromise();
  }
  syncPostUsuarioMatrizAccesoToPromise(usuarioMatrizAcceso) {
    return this.postUsuarioMatrizAcceso(usuarioMatrizAcceso).toPromise();
  }
  syncPutMatrizAccesoToPromise(matrizAcceso) {
    return this.putMatrizAcceso(matrizAcceso).toPromise();
  }
  syncDeleteMatrizAccesoToPromise(id) {
    return this.deleteMatrizAcceso(id).toPromise();
  }
};
MatrizAccesoService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
}];
MatrizAccesoService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], MatrizAccesoService);


/***/ }),

/***/ 4710:
/*!************************************************************!*\
  !*** ./src/app/services/usuarios-matriz-acceso.service.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UsuariosMatrizAccesoService": () => (/* binding */ UsuariosMatrizAccesoService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let UsuariosMatrizAccesoService = class UsuariosMatrizAccesoService {
  constructor(http) {
    this.http = http;
  }
  getAPI(api) {
    let test = '';
    if (!src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.prdMode) test = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.TestURL;
    const URL = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.preURL + test + src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postURL + api;
    return URL;
  }
  getUsuariosMatrizAccesosID(id) {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getUsuarioMatrizAccesoURL);
    URL = URL + id;
    console.log('URL', URL);
    return this.http.get(URL);
  }
  postUsuarioMatrizAcceso(matrizAcceso) {
    const URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postUsuarioMatrizAcceo);
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control': '*'
      }
    };
    return this.http.post(URL, matrizAcceso, options);
  }
  putUsuarioMatrizAcceso(matrizAcceso) {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.putMatrizAcceso);
    URL = URL + matrizAcceso.id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    };
    console.log(URL);
    console.log(matrizAcceso);
    return this.http.put(URL, matrizAcceso, options);
  }
  deleteUsuarioMatrizAcceso(id) {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.deleteUsuarioMatrizAcceso);
    URL = URL + id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    };
    return this.http.delete(URL, options);
  }
  syncGetUsuariosMatrizAccesoByIDtoToPromise(id) {
    return this.getUsuariosMatrizAccesosID(id).toPromise();
  }
  syncPostUsuarioMatrizAccesoToPromise(matrizAcceso) {
    return this.postUsuarioMatrizAcceso(matrizAcceso).toPromise();
  }
  syncPutUsuarioMatrizAccesoToPromise(matrizAcceso) {
    return this.putUsuarioMatrizAcceso(matrizAcceso).toPromise();
  }
  syncDeleteUsuarioMatrizAccesoToPromise(id) {
    return this.deleteUsuarioMatrizAcceso(id).toPromise();
  }
};
UsuariosMatrizAccesoService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
}];
UsuariosMatrizAccesoService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], UsuariosMatrizAccesoService);


/***/ })

}]);
//# sourceMappingURL=src_app_pages_editar-usuario_editar-usuario_module_ts-src_app_services_matriz-acceso_service_-3c9318.js.map