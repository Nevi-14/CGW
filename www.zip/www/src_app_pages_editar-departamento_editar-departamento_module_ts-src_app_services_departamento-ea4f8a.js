"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_editar-departamento_editar-departamento_module_ts-src_app_services_departamento-ea4f8a"],{

/***/ 33017:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/editar-departamento/editar-departamento-routing.module.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditarDepartamentoPageRoutingModule": () => (/* binding */ EditarDepartamentoPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _editar_departamento_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./editar-departamento.page */ 88384);




const routes = [{
  path: '',
  component: _editar_departamento_page__WEBPACK_IMPORTED_MODULE_0__.EditarDepartamentoPage
}];
let EditarDepartamentoPageRoutingModule = class EditarDepartamentoPageRoutingModule {};
EditarDepartamentoPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
  imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
  exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
})], EditarDepartamentoPageRoutingModule);


/***/ }),

/***/ 7018:
/*!*************************************************************************!*\
  !*** ./src/app/pages/editar-departamento/editar-departamento.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditarDepartamentoPageModule": () => (/* binding */ EditarDepartamentoPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _editar_departamento_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./editar-departamento-routing.module */ 33017);
/* harmony import */ var _editar_departamento_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./editar-departamento.page */ 88384);







let EditarDepartamentoPageModule = class EditarDepartamentoPageModule {};
EditarDepartamentoPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule, _editar_departamento_routing_module__WEBPACK_IMPORTED_MODULE_0__.EditarDepartamentoPageRoutingModule],
  declarations: [_editar_departamento_page__WEBPACK_IMPORTED_MODULE_1__.EditarDepartamentoPage]
})], EditarDepartamentoPageModule);


/***/ }),

/***/ 66646:
/*!***************************************************!*\
  !*** ./src/app/services/departamentos.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DepartamentosService": () => (/* binding */ DepartamentosService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 92340);




let DepartamentosService = class DepartamentosService {
  constructor(http) {
    this.http = http;
    this.departamentos = [];
  }
  getAPI(api) {
    let test = '';
    if (!_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.prdMode) test = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.TestURL;
    const URL = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.preURL + test + _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postURL + api;
    return URL;
  }
  getDepartamentos() {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getDepartamentos);
    console.log('URL', URL);
    return this.http.get(URL);
  }
  postDepartamento(departamento) {
    const URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postDepartamento);
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control': '*'
      }
    };
    return this.http.post(URL, departamento, options);
  }
  putDepartamento(departamento) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.putDepartamento);
    URL = URL + departamento.id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    };
    console.log(URL);
    console.log(departamento);
    return this.http.put(URL, departamento, options);
  }
  deleteDepartamento(id) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.deleteDepartamento);
    URL = URL + id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    };
    return this.http.delete(URL, options);
  }
  syncGetDepartamentoToPromise() {
    return this.getDepartamentos().toPromise();
  }
  syncPostDepartamentoToPromise(departamento) {
    return this.postDepartamento(departamento).toPromise();
  }
  syncPutDepartamentoToPromise(departamento) {
    return this.putDepartamento(departamento).toPromise();
  }
  syncDeleteDepartamentoToPromise(id) {
    return this.deleteDepartamento(id).toPromise();
  }
};
DepartamentosService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
}];
DepartamentosService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], DepartamentosService);


/***/ })

}]);
//# sourceMappingURL=src_app_pages_editar-departamento_editar-departamento_module_ts-src_app_services_departamento-ea4f8a.js.map