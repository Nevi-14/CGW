(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_pages_estado-cuenta_estado-cuenta_page_ts"],{

/***/ 65860:
/*!*********************************************************************!*\
  !*** ./src/app/pages/calendario-popover/calendario-popover.page.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CalendarioPopoverPage": () => (/* binding */ CalendarioPopoverPage)
/* harmony export */ });
/* harmony import */ var C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _calendario_popover_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./calendario-popover.page.html?ngResource */ 84344);
/* harmony import */ var _calendario_popover_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./calendario-popover.page.scss?ngResource */ 77057);
/* harmony import */ var _calendario_popover_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_calendario_popover_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 93819);






let CalendarioPopoverPage = class CalendarioPopoverPage {
  constructor(popOverCtrl, cd) {
    this.popOverCtrl = popOverCtrl;
    this.cd = cd;
    this.max = new Date().getFullYear() + 3;
  }
  ngOnInit() {}
  formatDate(value) {
    var _this = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const popover = yield _this.popOverCtrl.getTop();
      if (popover) {
        return _this.popOverCtrl.dismiss({
          fecha: value
        });
      }
    })();
  }
};
CalendarioPopoverPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.PopoverController
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.ChangeDetectorRef
}];
CalendarioPopoverPage.propDecorators = {
  fecha: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input
  }]
};
CalendarioPopoverPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
  selector: 'app-calendario-popover',
  template: _calendario_popover_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_calendario_popover_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], CalendarioPopoverPage);


/***/ }),

/***/ 26736:
/*!***********************************************************!*\
  !*** ./src/app/pages/estado-cuenta/estado-cuenta.page.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EstadoCuentaPage": () => (/* binding */ EstadoCuentaPage)
/* harmony export */ });
/* harmony import */ var C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _estado_cuenta_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./estado-cuenta.page.html?ngResource */ 19175);
/* harmony import */ var _estado_cuenta_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./estado-cuenta.page.scss?ngResource */ 75737);
/* harmony import */ var _estado_cuenta_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_estado_cuenta_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_services_usuarios_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/usuarios.service */ 81209);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! date-fns */ 86712);
/* harmony import */ var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/alertas.service */ 34997);
/* harmony import */ var _calendario_popover_calendario_popover_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../calendario-popover/calendario-popover.page */ 65860);
/* harmony import */ var src_app_services_estados_cuenta_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/estados-cuenta.service */ 84272);











let EstadoCuentaPage = class EstadoCuentaPage {
  constructor(modalCtrl, popOverCtrl, alertasService, usuariosService, estadosCuentaService) {
    this.modalCtrl = modalCtrl;
    this.popOverCtrl = popOverCtrl;
    this.alertasService = alertasService;
    this.usuariosService = usuariosService;
    this.estadosCuentaService = estadosCuentaService;
    this.usuarios = [];
    this.estadoCuenta = {
      id: null,
      remitente: this.usuariosService.usuario.usuario,
      destinatario: null,
      fecha: null,
      monto: 0,
      archivo: null,
      ruta: null
    };
    this.usuario = null;
    this.file = null;
    this.filePath = null;
    this.fileName = null;
    this.formatoFecha = new Date((0,date_fns__WEBPACK_IMPORTED_MODULE_7__["default"])(new Date(), 'yyy/MM/dd')).toISOString();
  }
  ngOnInit() {
    this.cargarDatos();
  }
  cerrarModal() {
    this.modalCtrl.dismiss();
  }
  cargarDatos() {
    this.estadoCuenta.fecha = new Date(this.formatoFecha);
    this.alertasService.presentaLoading('Cargando datos..');
    this.usuariosService.syncGetUsuariosToPromise().then(resp => {
      this.alertasService.loadingDissmiss();
      this.usuarios = resp;
    }, error => {
      this.alertasService.loadingDissmiss();
      this.alertasService.message('APP', 'Lo sentimos algo salio mal..');
    });
  }
  seleccionarUsuario(usuario, index) {
    this.estadoCuenta.destinatario = usuario.usuario;
    this.usuario = index;
  }
  fecha() {
    var _this = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const popover = yield _this.popOverCtrl.create({
        component: _calendario_popover_calendario_popover_page__WEBPACK_IMPORTED_MODULE_5__.CalendarioPopoverPage,
        cssClass: 'my-custom-class',
        translucent: true,
        componentProps: {
          fecha: _this.formatoFecha
        }
      });
      yield popover.present();
      const {
        data
      } = yield popover.onDidDismiss();
      if (data != undefined) {
        let fecha = new Date(data.fecha).toLocaleDateString('Es', {
          year: 'numeric',
          month: '2-digit',
          weekday: 'short',
          day: 'numeric'
        });
        _this.formatoFecha = data.fecha;
        _this.estadoCuenta.fecha = new Date(_this.formatoFecha);
      }
    })();
  }
  adjuntarArchivo($event) {
    // Get a reference to the file that has just been added to the input
    this.file = $event.target.files[0];
    let reader = new FileReader();
    reader.onload = event => {
      this.filePath = event.target.result;
      this.fileName = this.file.name;
      this.estadoCuenta.archivo = this.fileName;
      console.log('file', this.file);
    };
    reader.readAsDataURL($event.target.files[0]); // to trigger onload
  }

  generarPost() {
    if (!this.file) {
      this.alertasService.message('APP', 'Debes ed adjuntar el archivo antes de proceder..');
      return;
    }
    this.alertasService.presentaLoading('Guardando Datos...');
    this.estadosCuentaService.syncPostEstadosCuentaToPromise(this.estadoCuenta).then(resp => {
      const estado = resp;
      if (this.file) {
        const formData = new FormData();
        formData.append('image', this.file, this.file.name);
        this.estadosCuentaService.syncPostEstadoCuentaArchivoToPromise(resp.id, formData).then(resp => {
          this.alertasService.loadingDissmiss();
          this.modalCtrl.dismiss({
            estado: estado
          });
          console.log('archivo guardado  ', resp);
          this.borrarImagen();
        }, error => {
          console.log('error  ', error);
          this.borrarImagen();
          this.alertasService.message('APP', error);
          // this.cerrarModal();
        });
      } else {
        this.alertasService.loadingDissmiss();
        this.modalCtrl.dismiss(true);
      }
    }, error => {
      this.alertasService.loadingDissmiss();
      this.alertasService.message('APP', 'Lo sentimos algo salio mal...');
    });
  }
  borrarImagen() {
    this.file = null;
  }
};
EstadoCuentaPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.PopoverController
}, {
  type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_4__.AlertasService
}, {
  type: src_app_services_usuarios_service__WEBPACK_IMPORTED_MODULE_3__.UsuariosService
}, {
  type: src_app_services_estados_cuenta_service__WEBPACK_IMPORTED_MODULE_6__.EstadosCuentaService
}];
EstadoCuentaPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
  selector: 'app-estado-cuenta',
  template: _estado_cuenta_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_estado_cuenta_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], EstadoCuentaPage);


/***/ }),

/***/ 84272:
/*!****************************************************!*\
  !*** ./src/app/services/estados-cuenta.service.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EstadosCuentaService": () => (/* binding */ EstadosCuentaService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let EstadosCuentaService = class EstadosCuentaService {
  constructor(http) {
    this.http = http;
  }
  getAPI(api) {
    let test = "";
    if (!src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.prdMode) test = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.TestURL;
    const URL = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.preURL + test + src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postURL + api;
    return URL;
  }
  getEstadosCuenta() {
    const URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getEstadosCuenta);
    console.log('URL', URL);
    return this.http.get(URL);
  }
  getArchivoEstadosCuenta(ID) {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getArchivoEstadosCuenta);
    URL = URL + ID;
    console.log('URL', URL);
    return this.http.get(URL);
  }
  postEstadoCuenta(estadoCuenta) {
    const URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postEstadosCuenta);
    let options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Origin': '*'
      }
    };
    return this.http.post(URL, estadoCuenta, options);
  }
  postEstadoCuentaArchivo(ID, formData) {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postArchivoEstadosCuenta);
    URL = URL + ID;
    const options = {
      headers: {
        'enctype': 'multipart/form-data;',
        'Accept': 'plain/text',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT',
        'Access-Control-Allow-Headers': 'Authorization, Origin, Content-Type, X-CSRF-Token'
      }
    };
    return this.http.post(URL, formData, options);
  }
  syncGetEstadosCuentaToPromise() {
    return this.getEstadosCuenta().toPromise();
  }
  syncPostEstadosCuentaToPromise(estadoCuenta) {
    return this.postEstadoCuenta(estadoCuenta).toPromise();
  }
  syncPostEstadoCuentaArchivoToPromise(ID, formData) {
    return this.postEstadoCuentaArchivo(ID, formData).toPromise();
  }
  syncGetArchivoEstadosCuenta(ID) {
    return this.getArchivoEstadosCuenta(ID).toPromise();
  }
};
EstadosCuentaService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
}];
EstadosCuentaService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], EstadosCuentaService);


/***/ }),

/***/ 77057:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/calendario-popover/calendario-popover.page.scss?ngResource ***!
  \**********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 49579);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60931);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 75737:
/*!************************************************************************!*\
  !*** ./src/app/pages/estado-cuenta/estado-cuenta.page.scss?ngResource ***!
  \************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 49579);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60931);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".ion-item {\n  border-radius: 50px;\n  box-shadow: 1px 8px 8px 0px rgba(0, 0, 0, 0.08);\n  --hightlight-height:0px;\n  margin-top: 1rem;\n  margin-bottom: 1rem;\n}\n\nion-input, ion-select {\n  font-size: 18px;\n  --padding-top: 10px;\n  --padding-bottom: 10px;\n  --padding-start:5px;\n}\n\n.hideInput {\n  position: absolute;\n  bottom: -100000000px;\n}\n\nion-fab-button {\n  --background: transparent;\n  --box-shadow:none;\n}\nion-fab-button label {\n  color: #000;\n  font-size: 2rem !important;\n}\n\nion-col {\n  margin-top: 1rem;\n}", "",{"version":3,"sources":["webpack://./src/app/pages/estado-cuenta/estado-cuenta.page.scss","webpack://./../../Simple%20Design%20Experience/Control%20Viaticos/src/app/pages/estado-cuenta/estado-cuenta.page.scss"],"names":[],"mappings":"AAAA;EAEI,mBAAA;EACA,+CAAA;EACA,uBAAA;EACA,gBAAA;EACA,mBAAA;ACAJ;;ADGA;EACI,eAAA;EACA,mBAAA;EACA,sBAAA;EACA,mBAAA;ACAJ;;ADGA;EACI,kBAAA;EACA,oBAAA;ACAJ;;ADEA;EACI,yBAAA;EACA,iBAAA;ACCJ;ADAI;EACI,WAAA;EACA,0BAAA;ACER;;ADCA;EACI,gBAAA;ACEJ","sourcesContent":[".ion-item{\r\n\r\n    border-radius: 50px;\r\n    box-shadow: 1px 8px 8px 0px rgba(0,0,0,0.08);\r\n    --hightlight-height:0px;\r\n    margin-top: 1rem;\r\n    margin-bottom: 1rem;\r\n}\r\n\r\nion-input, ion-select{\r\n    font-size: 18px;\r\n    --padding-top: 10px;\r\n    --padding-bottom: 10px;\r\n    --padding-start:5px;\r\n}\r\n\r\n.hideInput{\r\n    position: absolute;\r\n    bottom: -100000000px;\r\n}\r\nion-fab-button {\r\n    --background: transparent;\r\n    --box-shadow:none;\r\n    label{\r\n        color: #000;\r\n        font-size: 2rem!important;\r\n    }\r\n}\r\nion-col{\r\n    margin-top: 1rem;\r\n}",".ion-item {\n  border-radius: 50px;\n  box-shadow: 1px 8px 8px 0px rgba(0, 0, 0, 0.08);\n  --hightlight-height:0px;\n  margin-top: 1rem;\n  margin-bottom: 1rem;\n}\n\nion-input, ion-select {\n  font-size: 18px;\n  --padding-top: 10px;\n  --padding-bottom: 10px;\n  --padding-start:5px;\n}\n\n.hideInput {\n  position: absolute;\n  bottom: -100000000px;\n}\n\nion-fab-button {\n  --background: transparent;\n  --box-shadow:none;\n}\nion-fab-button label {\n  color: #000;\n  font-size: 2rem !important;\n}\n\nion-col {\n  margin-top: 1rem;\n}"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 84344:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/calendario-popover/calendario-popover.page.html?ngResource ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\r\n\r\n<ion-content>\r\n  <ion-datetime\r\n [value]=\"fecha\"\r\n        #popoverDatetime2\r\n        presentation=\"date\"\r\n        [max]=\"max\"\r\n        (ionChange)=\"formatDate(popoverDatetime2.value)\"\r\n      ></ion-datetime>\r\n</ion-content>\r\n";

/***/ }),

/***/ 19175:
/*!************************************************************************!*\
  !*** ./src/app/pages/estado-cuenta/estado-cuenta.page.html?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <ion-button (click)=\"cerrarModal()\"  fill=\"clear\" slot=\"start\">\n      <ion-icon color=\"dark\" size=\"large\" name=\"arrow-back-outline\"></ion-icon>\n    </ion-button>\n    <ion-title>Estado de Cuenta</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n\n  <ion-grid >\n    <ion-row>\n      <ion-col size=\"6\">\n    \n        <ion-label>Fecha</ion-label>\n        <ion-item (click)=\"fecha()\" class=\"ion-item\" lines=\"none\">\n         <ion-input  readonly  [value]=\"formatoFecha  | date\" type=\"text\" placeholder=\"Fecha\"></ion-input>\n        </ion-item>\n      </ion-col>\n    \n      <ion-col size=\"6\">\n    \n        <ion-label>Monto</ion-label>\n        <ion-item class=\"ion-item\" lines=\"none\">\n         <ion-input name=\"monto\" [(ngModel)]=\"estadoCuenta.monto\" type=\"number\" placeholder=\"Monto\"></ion-input>\n        </ion-item>\n      </ion-col>\n  \n      <ion-col size=\"12\">\n        <ion-label>Archivo</ion-label>\n        <ion-item class=\"ion-item\" lines=\"none\">\n    \n            <ion-input [value]=\"fileName\" placeholder=\"Archivo\" ></ion-input>\n            <ion-fab-button size=\"small\" slot=\"end\" >\n              <label for=\"input\" style=\"font-size: 20pt; padding: 20px\" >\n                <ion-icon name=\"cloud-upload-outline\"></ion-icon>\n              </label>\n              <input  id=\"input\" type=\"file\" class=\"hideInput\" (change)=\"adjuntarArchivo($event)\">\n            </ion-fab-button>\n          </ion-item>\n       \n      </ion-col>\n      <ion-col size=\"12\">\n        <ion-radio-group [value]=\"usuario\">\n          <ion-list>\n            <ion-list-header>\n       <ion-searchbar mode=\"ios\" placeholder=\"Buscar Usuario\"  type=\"text\"   [debounce]=\"250\"  ></ion-searchbar>\n            </ion-list-header>\n            <ion-item (click)=\"seleccionarUsuario(usuario, i+1)\"  *ngFor=\"let usuario of usuarios; let i = index;\">\n              <ion-label>{{usuario.usuario}}</ion-label>\n            <ion-radio [value]=\"usuario.usuario\"></ion-radio>\n            </ion-item>\n      \n          \n          </ion-list>\n        </ion-radio-group>\n  \n        \n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n\n \n<ion-footer class=\"ion-no-border\">\n  <ion-toolbar class=\"ion-padding\">\n<ion-button (click)=\"generarPost()\" expand=\"block\" fill=\"solid\" color=\"dark\">\nEnviar Estado De Cuenta\n</ion-button>\n  </ion-toolbar>\n</ion-footer>\n";

/***/ })

}]);
//# sourceMappingURL=default-src_app_pages_estado-cuenta_estado-cuenta_page_ts.js.map