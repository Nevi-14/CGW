(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_inicio-sesion_inicio-sesion_module_ts"],{

/***/ 18438:
/*!*********************************************************************!*\
  !*** ./src/app/pages/inicio-sesion/inicio-sesion-routing.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InicioSesionPageRoutingModule": () => (/* binding */ InicioSesionPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _inicio_sesion_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./inicio-sesion.page */ 75565);




const routes = [{
  path: '',
  component: _inicio_sesion_page__WEBPACK_IMPORTED_MODULE_0__.InicioSesionPage
}];
let InicioSesionPageRoutingModule = class InicioSesionPageRoutingModule {};
InicioSesionPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
  imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
  exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
})], InicioSesionPageRoutingModule);


/***/ }),

/***/ 9943:
/*!*************************************************************!*\
  !*** ./src/app/pages/inicio-sesion/inicio-sesion.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InicioSesionPageModule": () => (/* binding */ InicioSesionPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _inicio_sesion_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./inicio-sesion-routing.module */ 18438);
/* harmony import */ var _inicio_sesion_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./inicio-sesion.page */ 75565);







let InicioSesionPageModule = class InicioSesionPageModule {};
InicioSesionPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule, _inicio_sesion_routing_module__WEBPACK_IMPORTED_MODULE_0__.InicioSesionPageRoutingModule],
  declarations: [_inicio_sesion_page__WEBPACK_IMPORTED_MODULE_1__.InicioSesionPage]
})], InicioSesionPageModule);


/***/ }),

/***/ 75565:
/*!***********************************************************!*\
  !*** ./src/app/pages/inicio-sesion/inicio-sesion.page.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InicioSesionPage": () => (/* binding */ InicioSesionPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _inicio_sesion_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./inicio-sesion.page.html?ngResource */ 67985);
/* harmony import */ var _inicio_sesion_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./inicio-sesion.page.scss?ngResource */ 11039);
/* harmony import */ var _inicio_sesion_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_inicio_sesion_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _services_alertas_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/alertas.service */ 34997);
/* harmony import */ var _services_usuarios_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/usuarios.service */ 81209);
/* harmony import */ var _services_configuraciones__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/configuraciones */ 7717);








let InicioSesionPage = class InicioSesionPage {
  constructor(route, alertas, usuariosService, activatedRoute, configuracionesService) {
    this.route = route;
    this.alertas = alertas;
    this.usuariosService = usuariosService;
    this.activatedRoute = activatedRoute;
    this.configuracionesService = configuracionesService;
    this.image = '../assets/imgs/devCodingLogo.svg';
    this.showPass = false;
    this.correo = null;
    this.clave = null;
    this.logingURL = '';
  }
  ngOnInit() {}
  ionViewWillEnter() {
    this.logingURL = this.activatedRoute.snapshot.queryParamMap.get('returnto') || 'inicio/detalle';
    this.configuracionesService.title = this.logingURL.split('/')[2];
  }
  loginMethod() {
    console.log(this.correo);
    console.log(this.clave);
    this.alertas.presentaLoading('Cargando datos..');
    this.usuariosService.getUsuarioIdToPtomise(this.correo).then(resp => {
      console.log('resp', resp);
      this.alertas.loadingDissmiss();
      if (resp.length == 0) {
        this.alertas.message('APP', 'Lo sentimos usuario o contraseña incorrectos..');
      } else if (resp[0].correo == this.correo && resp[0].clave == this.clave) {
        localStorage.setItem('usuario', JSON.stringify(resp[0]));
        this.usuariosService.usuario = resp[0];
        this.route.navigateByUrl(this.logingURL);
      } else {
        this.alertas.message('APP', 'Lo sentimos usuario o contraseña incorrectos..');
      }
    }, error => {
      this.alertas.message('APP', 'Lo sentimos algo salio mal');
      this.alertas.loadingDissmiss();
    });
    /**
     *
        this.usuariosService.syngGetUsersToPromise(this.usuario, this.clave).then(
          resp => {
            this.alertas.loadingDissmiss();
            if (resp.length > 0){
              console.log(resp);
              if (resp[0].Clave === this.clave){
                this.usuariosService.usuario = resp[0];
                this.route.navigate(['/inicio']);
              } else {
                this.alertas.message('ERROR', 'Usuario o clave incorrectos.');
              }
            } else {
              this.alertas.message('ERROR', 'Usuario o clave incorrectos.');
            }
          }, error => {
            this.alertas.loadingDissmiss();
            this.alertas.message('Error', `No se puede acceder a la BD. ${error.message}`);
          }
        )
     */
    //this.route.navigate(['/inicio']);
  }
};

InicioSesionPage.ctorParameters = () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router
}, {
  type: _services_alertas_service__WEBPACK_IMPORTED_MODULE_2__.AlertasService
}, {
  type: _services_usuarios_service__WEBPACK_IMPORTED_MODULE_3__.UsuariosService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute
}, {
  type: _services_configuraciones__WEBPACK_IMPORTED_MODULE_4__.ConfiguracionesService
}];
InicioSesionPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
  selector: 'app-inicio-sesion',
  template: _inicio_sesion_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
  styles: [(_inicio_sesion_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1___default())]
})], InicioSesionPage);


/***/ }),

/***/ 11039:
/*!************************************************************************!*\
  !*** ./src/app/pages/inicio-sesion/inicio-sesion.page.scss?ngResource ***!
  \************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 49579);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60931);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".heading {\n  margin-top: 10px;\n}\n\nH1 {\n  margin-top: 10px;\n  font-size: 24px;\n  color: #7b7b7b;\n  font-size: 1.2rem;\n  letter-spacing: 0.5rem;\n  text-transform: uppercase;\n}\n\nH3 {\n  margin-top: 10px;\n  font-size: 20px;\n  color: #7b7b7b;\n}\n\np {\n  margin-top: 10px;\n  font-size: 16px;\n  color: #7b7b7b;\n}\n\n.login-form .form-input {\n  position: relative;\n  margin-bottom: 10px;\n}\n.login-form .form-input ion-item::part(native) {\n  padding-left: 0;\n}\n.login-form .form-input ion-icon {\n  margin-right: 18px;\n}\n.login-form .form-input ion-label {\n  font-size: 18px;\n  letter-spacing: 2px;\n}\n.login-form .form-input ion-input {\n  font-size: 16px;\n  --padding-start:16px;\n  --padding-top:16px;\n  color: #7b7b7b;\n}\n\n.action-buttons {\n  text-align: center;\n}\n.action-buttons .login-button {\n  --background: rgba(37,13,76,255);\n  width: 200px;\n  font-weight: bold;\n  height: 40px;\n}\n.action-buttons p {\n  margin-top: 10px;\n  font-size: 14px;\n  color: #7b7b7b;\n}\n.action-buttons .signup-button {\n  --border-color:#b4b4b4;\n  -color: #000;\n  font-weight: bold;\n  margin-top: 20px;\n  width: 200px;\n  height: 40px;\n}", "",{"version":3,"sources":["webpack://./src/app/pages/inicio-sesion/inicio-sesion.page.scss","webpack://./../../Simple%20Design%20Experience/Control%20Viaticos/src/app/pages/inicio-sesion/inicio-sesion.page.scss"],"names":[],"mappings":"AAEA;EACI,gBAAA;ACDJ;;ADIE;EACE,gBAAA;EACA,eAAA;EACA,cAAA;EACA,iBAAA;EAAkB,sBAAA;EAClB,yBAAA;ACAJ;;ADEE;EACE,gBAAA;EACA,eAAA;EACA,cAAA;ACCJ;;ADCE;EACE,gBAAA;EACA,eAAA;EACA,cAAA;ACEJ;;ADEM;EACE,kBAAA;EACA,mBAAA;ACCR;ADAQ;EACA,eAAA;ACER;ADCQ;EACA,kBAAA;ACCR;ADGQ;EACE,eAAA;EACA,mBAAA;ACDV;ADKQ;EACE,eAAA;EACA,oBAAA;EACA,kBAAA;EACA,cAAA;ACHV;;ADUI;EACE,kBAAA;ACPN;ADQM;EACE,gCAAA;EACA,YAAA;EACA,iBAAA;EACA,YAAA;ACNR;ADQM;EACE,gBAAA;EACA,eAAA;EACA,cAAA;ACNR;ADUM;EACE,sBAAA;EACA,YAAA;EACA,iBAAA;EACA,gBAAA;EACA,YAAA;EACA,YAAA;ACRR","sourcesContent":["\r\n\r\n.heading{\r\n    margin-top: 10px;\r\n  \r\n  }\r\n  H1{\r\n    margin-top: 10px;\r\n    font-size: 24px;\r\n    color: #7b7b7b;\r\n    font-size: 1.2rem;letter-spacing: 0.5rem;\r\n    text-transform: uppercase;\r\n  }\r\n  H3{\r\n    margin-top: 10px;\r\n    font-size: 20px;\r\n    color: #7b7b7b;\r\n  }\r\n  p{\r\n    margin-top: 10px;\r\n    font-size: 16px;\r\n    color: #7b7b7b;\r\n  }\r\n    .login-form{\r\n  \r\n      .form-input{\r\n        position: relative;\r\n        margin-bottom: 10px;\r\n        ion-item::part(native){\r\n        padding-left: 0;\r\n        }\r\n  \r\n        ion-icon{\r\n        margin-right: 18px;\r\n  \r\n        }\r\n  \r\n        ion-label{\r\n          font-size: 18px;\r\n          letter-spacing: 2px;\r\n     \r\n        }\r\n  \r\n        ion-input{\r\n          font-size: 16px;\r\n          --padding-start:16px;\r\n          --padding-top:16px;\r\n          color: #7b7b7b;\r\n        }\r\n      }\r\n  \r\n  \r\n    }\r\n  \r\n    .action-buttons{\r\n      text-align: center;\r\n      .login-button{\r\n        --background: rgba(37,13,76,255);\r\n        width: 200px;\r\n        font-weight: bold;\r\n        height: 40px;\r\n      }\r\n      p{\r\n        margin-top: 10px;\r\n        font-size: 14px;\r\n        color: #7b7b7b;\r\n      \r\n      }\r\n  \r\n      .signup-button{\r\n        --border-color:#b4b4b4;\r\n        -color: #000;\r\n        font-weight: bold;\r\n        margin-top: 20px;\r\n        width: 200px;\r\n        height: 40px;\r\n      }\r\n    }\r\n   \r\n",".heading {\n  margin-top: 10px;\n}\n\nH1 {\n  margin-top: 10px;\n  font-size: 24px;\n  color: #7b7b7b;\n  font-size: 1.2rem;\n  letter-spacing: 0.5rem;\n  text-transform: uppercase;\n}\n\nH3 {\n  margin-top: 10px;\n  font-size: 20px;\n  color: #7b7b7b;\n}\n\np {\n  margin-top: 10px;\n  font-size: 16px;\n  color: #7b7b7b;\n}\n\n.login-form .form-input {\n  position: relative;\n  margin-bottom: 10px;\n}\n.login-form .form-input ion-item::part(native) {\n  padding-left: 0;\n}\n.login-form .form-input ion-icon {\n  margin-right: 18px;\n}\n.login-form .form-input ion-label {\n  font-size: 18px;\n  letter-spacing: 2px;\n}\n.login-form .form-input ion-input {\n  font-size: 16px;\n  --padding-start:16px;\n  --padding-top:16px;\n  color: #7b7b7b;\n}\n\n.action-buttons {\n  text-align: center;\n}\n.action-buttons .login-button {\n  --background: rgba(37,13,76,255);\n  width: 200px;\n  font-weight: bold;\n  height: 40px;\n}\n.action-buttons p {\n  margin-top: 10px;\n  font-size: 14px;\n  color: #7b7b7b;\n}\n.action-buttons .signup-button {\n  --border-color:#b4b4b4;\n  -color: #000;\n  font-weight: bold;\n  margin-top: 20px;\n  width: 200px;\n  height: 40px;\n}"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 67985:
/*!************************************************************************!*\
  !*** ./src/app/pages/inicio-sesion/inicio-sesion.page.html?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\r\n\r\n<ion-content class=\"ion-padding\">\r\n  <ion-grid  style=\"height: 100%;\">\r\n      <ion-row  style=\"display: flex;justify-content: center; align-items: center;height: 100%;\">\r\n \r\n          <ion-col size=\"12\"  size-md=\"4\" >\r\n             <form  >\r\n   \r\n   \r\n                 <div class=\"login-section\" >\r\n                   <div class=\"heading ion-padding ion-text-uppercase ion-text-center\"   >\r\n                     <h3 class=\"ion-text-left\">Control-Viáticos</h3>\r\n                   </div>\r\n                   \r\n             \r\n                   <div class=\"login-form ion-padding\">\r\n             \r\n                     <div class=\"form-input\" lines=\"none\">\r\n                      <ion-label  position=\"stacked\"><ion-icon  name=\"mail-outline\"></ion-icon>Usuario</ion-label>\r\n                       <ion-item lines=\"none\" class=\"ion-item\" >\r\n                 \r\n                        \r\n                         <ion-input type=\"text\" placeholder=\"Usuario\" name=\"usuario\" [(ngModel)]=\"correo\"></ion-input>\r\n                       </ion-item>\r\n                     </div>\r\n             \r\n                     <div class=\"form-input\">\r\n                      <ion-label  position=\"stacked\">            <ion-icon  name=\"lock-closed-outline\" ></ion-icon>Contraseña</ion-label>\r\n                       <ion-item class=\"ion-item\" lines=\"none\">\r\n             \r\n                \r\n                         \r\n                       \r\n                         <ion-input type=\"password\" name=\"contrasena\" autocomplete=\"off\"  type=\"{{showPass ? 'text' : 'password'}}\" placeholder=\"contraseña\" [(ngModel)]=\"clave\"></ion-input>\r\n                         <ion-icon slot=\"end\"  item-right name=\"{{showPass ? 'eye' : 'eye-off'}}\" (click)=\"showPass=!showPass\"></ion-icon>\r\n                       </ion-item>\r\n                     </div>\r\n             \r\n             \r\n               \r\n                   </div>\r\n             \r\n             \r\n                   <div class=\"action-buttons ion-padding\">\r\n                     <ion-button  color=\"dark\" shape=\"round\" type=\"submit\" (click)=\"loginMethod()\">\r\n                       Iniciar Sesion\r\n                     </ion-button>\r\n   \r\n                  \r\n                   </div>\r\n          \r\n               </div>\r\n               </form>\r\n          </ion-col>\r\n         \r\n      </ion-row>\r\n  </ion-grid>\r\n   </ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_inicio-sesion_inicio-sesion_module_ts.js.map