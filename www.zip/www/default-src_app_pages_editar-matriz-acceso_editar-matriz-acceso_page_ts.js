(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_pages_editar-matriz-acceso_editar-matriz-acceso_page_ts"],{

/***/ 69989:
/*!*************************************************************************!*\
  !*** ./src/app/pages/editar-matriz-acceso/editar-matriz-acceso.page.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditarMatrizAccesoPage": () => (/* binding */ EditarMatrizAccesoPage)
/* harmony export */ });
/* harmony import */ var C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _editar_matriz_acceso_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./editar-matriz-acceso.page.html?ngResource */ 26714);
/* harmony import */ var _editar_matriz_acceso_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./editar-matriz-acceso.page.scss?ngResource */ 26138);
/* harmony import */ var _editar_matriz_acceso_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_editar_matriz_acceso_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/alertas.service */ 34997);
/* harmony import */ var src_app_services_companias_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/companias.service */ 65667);
/* harmony import */ var src_app_services_departamentos_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/departamentos.service */ 66646);
/* harmony import */ var src_app_services_matriz_acceso_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/matriz-acceso.service */ 75444);
/* harmony import */ var src_app_services_modulos_matriz_acceso_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/modulos-matriz-acceso.service */ 78423);
/* harmony import */ var src_app_services_modulos_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/modulos.service */ 23191);
/* harmony import */ var src_app_services_usuarios_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/services/usuarios.service */ 81209);













let EditarMatrizAccesoPage = class EditarMatrizAccesoPage {
  constructor(modalCtrl, modulosService, companiaService, departamentosService, alertasService, usuariosService, matrizAccesoService, cd, modulosMatrizccesoService) {
    this.modalCtrl = modalCtrl;
    this.modulosService = modulosService;
    this.companiaService = companiaService;
    this.departamentosService = departamentosService;
    this.alertasService = alertasService;
    this.usuariosService = usuariosService;
    this.matrizAccesoService = matrizAccesoService;
    this.cd = cd;
    this.modulosMatrizccesoService = modulosMatrizccesoService;
    this.modulos = [];
    this.total = 0;
    this.usuarios = [];
  }
  ngOnInit() {
    this.total = this.modulos.length;
    console.log(this.acceso, 'acceso');
    this.alertasService.presentaLoading('Cargando datos..');
    this.modulosService.syncGetModulosToPromise().then(modulos => {
      this.modulosService.modulos = modulos;
      this.companiaService.syncGetCompaniasToPromise().then(companias => {
        this.companiaService.companias = companias;
        this.departamentosService.syncGetDepartamentoToPromise().then(departamentos => {
          this.departamentosService.departamentos = departamentos;
          this.alertasService.loadingDissmiss();
          console.log('modulos', this.modulosService.modulos);
          console.log('companias', this.companiaService.companias);
          console.log('departamentos', this.departamentosService.departamentos);
        }, error => {
          this.alertasService.loadingDissmiss();
          this.alertasService.message('Dione', 'Lo sentimos algo salio mal..');
        });
      }, error => {
        this.alertasService.loadingDissmiss();
        this.alertasService.message('Dione', 'Lo sentimos algo salio mal..');
      });
    }, error => {
      this.alertasService.loadingDissmiss();
      this.alertasService.message('Dione', 'Lo sentimos algo salio mal..');
    });
  }
  cerrarModal() {
    this.modalCtrl.dismiss();
  }
  borrarModulo($event) {
    console.log($event);
  }
  generarPost() {
    var _this = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.modulosMatrizccesoService.syncDeleteModuloMatrizAccesoToPromise(_this.acceso.id);
      _this.alertasService.presentaLoading('Guardando cambios..');
      _this.matrizAccesoService.syncPutMatrizAccesoToPromise(_this.acceso).then(resp => {
        _this.alertasService.loadingDissmiss();
        _this.matrizAccesoService.syncGetMatrizAccesotoToPromise().then(accesos => {
          _this.matrizAccesoService.matrizAcceso = accesos;
          if (_this.modulos.length == 0) {
            _this.modalCtrl.dismiss();
            _this.alertasService.message('Dione', 'Acceso actualizado');
            _this.modalCtrl.dismiss(true);
          }
          _this.modulos.forEach( /*#__PURE__*/function () {
            var _ref = (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (modulo, index) {
              let mod = {
                id: null,
                iD_MATRIZ_ACCESO: _this.acceso.id,
                iD_MODULO: modulo
              };
              console.log(mod);
              yield _this.modulosMatrizccesoService.syncPostModuloMatrizAccesoToPromise(mod);
              if (index == _this.modulos.length - 1) {
                _this.modalCtrl.dismiss();
                _this.alertasService.message('Dione', 'Acceso actualizado');
                _this.modalCtrl.dismiss(true);
              }
            });
            return function (_x, _x2) {
              return _ref.apply(this, arguments);
            };
          }());
        }, error => {
          _this.alertasService.loadingDissmiss();
          _this.alertasService.message('Dione', 'Lo sentimos algo salio mal..');
        });
      }, error => {
        _this.alertasService.loadingDissmiss();
        _this.alertasService.message('Dione', 'Lo sentimos algo salio mal..');
      });
    })();
  }
};
EditarMatrizAccesoPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.ModalController
}, {
  type: src_app_services_modulos_service__WEBPACK_IMPORTED_MODULE_8__.ModulosService
}, {
  type: src_app_services_companias_service__WEBPACK_IMPORTED_MODULE_4__.CompaniasService
}, {
  type: src_app_services_departamentos_service__WEBPACK_IMPORTED_MODULE_5__.DepartamentosService
}, {
  type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_3__.AlertasService
}, {
  type: src_app_services_usuarios_service__WEBPACK_IMPORTED_MODULE_9__.UsuariosService
}, {
  type: src_app_services_matriz_acceso_service__WEBPACK_IMPORTED_MODULE_6__.MatrizAccesoService
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_11__.ChangeDetectorRef
}, {
  type: src_app_services_modulos_matriz_acceso_service__WEBPACK_IMPORTED_MODULE_7__.ModulosMatrizAccesoService
}];
EditarMatrizAccesoPage.propDecorators = {
  acceso: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_11__.Input
  }],
  modulos: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_11__.Input
  }]
};
EditarMatrizAccesoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
  selector: 'app-editar-matriz-acceso',
  template: _editar_matriz_acceso_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_editar_matriz_acceso_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], EditarMatrizAccesoPage);


/***/ }),

/***/ 26138:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/editar-matriz-acceso/editar-matriz-acceso.page.scss?ngResource ***!
  \**************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 49579);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60931);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "ion-input, ion-select {\n  border-radius: 10px;\n  border: solid 1px rgb(218, 218, 218);\n  height: 2.5rem;\n  width: 100%;\n  padding: 0.2rem;\n  text-indent: 0.2cm;\n}\n\nion-label {\n  font-size: 1rem;\n  font-weight: 500;\n}\n\n.description {\n  height: 4rem;\n}\n\n.has-focus {\n  border: 2px solid #5b9bd1 !important;\n}\n\nion-item {\n  border-radius: 10px;\n  --ion-item-background: rgba(0, 0, 0, 0.09);\n  margin: 0.5rem;\n}", "",{"version":3,"sources":["webpack://./src/app/pages/editar-matriz-acceso/editar-matriz-acceso.page.scss","webpack://./../../Simple%20Design%20Experience/Control%20Viaticos/src/app/pages/editar-matriz-acceso/editar-matriz-acceso.page.scss"],"names":[],"mappings":"AACA;EACI,mBAAA;EACA,oCAAA;EACA,cAAA;EACA,WAAA;EACJ,eAAA;EACA,kBAAA;ACAA;;ADEA;EACI,eAAA;EACA,gBAAA;ACCJ;;ADCA;EACI,YAAA;ACEJ;;ADAA;EACI,oCAAA;ACGJ;;ADAG;EACC,mBAAA;EACA,0CAAA;EACA,cAAA;ACGJ","sourcesContent":[" \r\nion-input, ion-select {\r\n    border-radius: 10px;\r\n    border: solid 1px rgba(218,218,218,1);\r\n    height: 2.5rem;\r\n    width: 100%;\r\npadding: 0.2rem;\r\ntext-indent: 0.2cm;\r\n}\r\nion-label{\r\n    font-size: 1rem;\r\n    font-weight: 500;\r\n}\r\n.description {\r\n    height: 4rem;\r\n}\r\n.has-focus {\r\n    border: 2px solid #5b9bd1 !important;\r\n  }\r\n \r\n   ion-item{\r\n    border-radius: 10px;\r\n    --ion-item-background:  rgba(0, 0, 0, 0.09);\r\n    margin: 0.5rem;\r\n   }\r\n\r\n   ion-content{\r\n   // --background: #e7edfb;\r\n   }\r\n\r\n   ion-card{\r\n   // --background:rgba(0, 0, 0, 0.08);\r\n   //box-shadow: 1px 8px 8px 0px rgba(0, 0, 0, 0.05);\r\n}\r\n ","ion-input, ion-select {\n  border-radius: 10px;\n  border: solid 1px rgb(218, 218, 218);\n  height: 2.5rem;\n  width: 100%;\n  padding: 0.2rem;\n  text-indent: 0.2cm;\n}\n\nion-label {\n  font-size: 1rem;\n  font-weight: 500;\n}\n\n.description {\n  height: 4rem;\n}\n\n.has-focus {\n  border: 2px solid #5b9bd1 !important;\n}\n\nion-item {\n  border-radius: 10px;\n  --ion-item-background: rgba(0, 0, 0, 0.09);\n  margin: 0.5rem;\n}"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 26714:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/editar-matriz-acceso/editar-matriz-acceso.page.html?ngResource ***!
  \**************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <ion-button (click)=\"cerrarModal()\"  fill=\"clear\" slot=\"start\">\n      <ion-icon color=\"dark\" size=\"large\" name=\"arrow-back-outline\"></ion-icon>\n    </ion-button>\n    <ion-title>Editar Acceso</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n\n\n<ion-content class=\"ion-padding\">\n\n  <ion-grid >\n   <ion-row>\n     <ion-col size=\"6\">\n       <ion-row>\n         <ion-col size=\"12\" style=\"display: flex;justify-content: space-between;align-items: center;\">\n           <ion-label>ID Role</ion-label>\n          \n         </ion-col>\n         <ion-col size=\"12\">\n          \n <ion-input readonly type=\"text\" type=\"text\" name=\"id\" [(ngModel)]=\"acceso.id\" placeholder=\"ex: R001\"></ion-input>\n         \n         </ion-col>\n       </ion-row>\n           </ion-col>\n  \n     <ion-col size=\"6\">\n       <ion-row>\n         <ion-col size=\"12\" style=\"display: flex;justify-content: space-between;align-items: center;\">\n           <ion-label>Role</ion-label>\n          \n         </ion-col>\n         <ion-col size=\"12\">\n          \n <ion-input type=\"text\" name=\"nombre\" [(ngModel)]=\"acceso.nombre\" placeholder=\"nombre\"></ion-input>\n         \n         </ion-col>\n       </ion-row>\n           </ion-col>\n  \n     <ion-col size=\"6\">\n <ion-row>\n   <ion-col size=\"12\" style=\"display: flex;justify-content: space-between;align-items: center;\">\n     <ion-label>Compañia</ion-label>\n     \n   </ion-col>\n   <ion-col size=\"12\">\n     <ion-select name=\"compania\" [(ngModel)]=\"acceso.iD_COMPANIA\"     placeholder=\"Seleccionar\">\n       <ion-select-option *ngFor=\"let compania of companiaService.companias\" [value]=\"compania.id\">{{compania.nombre}}</ion-select-option>\n     </ion-select>\n \n   </ion-col>\n </ion-row>\n     </ion-col>\n     <ion-col size=\"6\">\n       <ion-row>\n         <ion-col size=\"12\" style=\"display: flex;justify-content: space-between;align-items: center;\">\n           <ion-label>Departamento</ion-label>\n           \n         </ion-col>\n         <ion-col size=\"12\">\n        \n           <ion-select  name=\"departamento\" [(ngModel)]=\"acceso.iD_DEPARTAMENTO\"   placeholder=\"Seleccionar\">\n             <ion-select-option *ngFor=\"let departamento of departamentosService.departamentos\"  [value]=\"departamento.id\">{{departamento.nombre}}</ion-select-option>\n           </ion-select>\n           \n         </ion-col>\n       </ion-row>\n           </ion-col>\n           <ion-col size=\"12\" style=\"display: flex;justify-content: space-between;align-items: center;\">\n             <ion-label>Modulos</ion-label>\n            \n           </ion-col>\n           <ion-col size=\"12\" class=\"ion-margin-bottom\">\n            \n               <ion-select   interface=\"action-sheet\"  multiple=\"true\"  name=\"modulo\" [(ngModel)]=\"modulos\"   placeholder=\"Seleccionar\">\n   \n   \n                 <ng-template ngFor let-modulo [ngForOf]=\"modulosService.modulos\"\n                 let-i=\"index\"  >\n               \n                 <ion-select-option  *ngIf=\"i > 0\"  [value]=\"modulo.id\">{{modulo.nombre}}</ion-select-option>\n               </ng-template>\n              \n       \n               </ion-select>\n           \n           </ion-col>\n           <ion-col size=\"3\">\n             Lectura\n           </ion-col>\n           <ion-col size=\"3\">\n             Creación\n           </ion-col>\n           <ion-col size=\"3\">\n             Modificar\n           </ion-col>\n           <ion-col size=\"3\">\n             Borrar\n           </ion-col>\n         <ion-col size=\"3\">\n         <ion-toggle  [disabled]=\"true\" name=\"r\" [(ngModel)]=\"acceso.r\"></ion-toggle>\n         </ion-col>\n         <ion-col size=\"3\">\n         <ion-toggle name=\"c\" [(ngModel)]=\"acceso.c\" ></ion-toggle>\n         </ion-col>\n         <ion-col size=\"3\">\n         <ion-toggle name=\"u\" [(ngModel)]=\"acceso.u\"></ion-toggle>\n         </ion-col>\n         <ion-col size=\"3\">\n         <ion-toggle name=\"d\" [(ngModel)]=\"acceso.d\"></ion-toggle>\n         </ion-col>\n  \n         </ion-row>\n \n    \n  \n \n  </ion-grid>\n </ion-content>\n <ion-footer (click)=\"generarPost()\" class=\"ion-no-border ion-padding\">\n  <ion-toolbar>\n    <ion-button  expand=\"block\" fill=\"solid\" color=\"dark\">\n      Editar Acceso\n      </ion-button>\n  </ion-toolbar>\n </ion-footer>";

/***/ })

}]);
//# sourceMappingURL=default-src_app_pages_editar-matriz-acceso_editar-matriz-acceso_page_ts.js.map