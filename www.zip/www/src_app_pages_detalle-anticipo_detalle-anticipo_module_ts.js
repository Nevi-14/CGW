(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_detalle-anticipo_detalle-anticipo_module_ts"],{

/***/ 51185:
/*!***************************************************************************!*\
  !*** ./src/app/pages/detalle-anticipo/detalle-anticipo-routing.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetalleAnticipoPageRoutingModule": () => (/* binding */ DetalleAnticipoPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _detalle_anticipo_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./detalle-anticipo.page */ 81266);




const routes = [{
  path: '',
  component: _detalle_anticipo_page__WEBPACK_IMPORTED_MODULE_0__.DetalleAnticipoPage
}];
let DetalleAnticipoPageRoutingModule = class DetalleAnticipoPageRoutingModule {};
DetalleAnticipoPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
  imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
  exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
})], DetalleAnticipoPageRoutingModule);


/***/ }),

/***/ 39483:
/*!*******************************************************************!*\
  !*** ./src/app/pages/detalle-anticipo/detalle-anticipo.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetalleAnticipoPageModule": () => (/* binding */ DetalleAnticipoPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _detalle_anticipo_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./detalle-anticipo-routing.module */ 51185);
/* harmony import */ var _detalle_anticipo_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./detalle-anticipo.page */ 81266);
/* harmony import */ var src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/pipes/pipes.module */ 35503);
/* harmony import */ var src_app_components_component_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/components/component.module */ 78443);









let DetalleAnticipoPageModule = class DetalleAnticipoPageModule {};
DetalleAnticipoPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule, _detalle_anticipo_routing_module__WEBPACK_IMPORTED_MODULE_0__.DetalleAnticipoPageRoutingModule, src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_2__.PipesModule, src_app_components_component_module__WEBPACK_IMPORTED_MODULE_3__.ComponentModule],
  declarations: [_detalle_anticipo_page__WEBPACK_IMPORTED_MODULE_1__.DetalleAnticipoPage]
})], DetalleAnticipoPageModule);


/***/ }),

/***/ 81266:
/*!*****************************************************************!*\
  !*** ./src/app/pages/detalle-anticipo/detalle-anticipo.page.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetalleAnticipoPage": () => (/* binding */ DetalleAnticipoPage)
/* harmony export */ });
/* harmony import */ var C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _detalle_anticipo_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./detalle-anticipo.page.html?ngResource */ 90276);
/* harmony import */ var _detalle_anticipo_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./detalle-anticipo.page.scss?ngResource */ 10262);
/* harmony import */ var _detalle_anticipo_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_detalle_anticipo_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_services_adelanto_viaticos_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/adelanto-viaticos.service */ 45406);
/* harmony import */ var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/alertas.service */ 34997);
/* harmony import */ var src_app_services_gastos_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/gastos.service */ 40354);
/* harmony import */ var src_app_services_lineas_anticipos_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/lineas-anticipos.service */ 37568);
/* harmony import */ var _linea_gastos_linea_gastos_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../linea-gastos/linea-gastos.page */ 7935);
/* harmony import */ var src_app_services_correo_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/correo.service */ 31534);












let DetalleAnticipoPage = class DetalleAnticipoPage {
  constructor(modalCtrl, alertasService, adelantosService, linaAnticiposService, gtastosService, correosService) {
    this.modalCtrl = modalCtrl;
    this.alertasService = alertasService;
    this.adelantosService = adelantosService;
    this.linaAnticiposService = linaAnticiposService;
    this.gtastosService = gtastosService;
    this.correosService = correosService;
    this.isOpen = false;
    this.lineas = [];
    this.gastos = [];
  }
  ngOnInit() {
    var _this = this;
    console.log(this.adelantosService.adelantoViatico, 'adelantooooo');
    this.linaAnticiposService.syncGetLineasAnriciposToPromise(this.adelantosService.adelantoViatico.id).then( /*#__PURE__*/function () {
      var _ref = (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (lineas) {
        _this.lineas = lineas;
        console.log('lineas', lineas);
        _this.gastos = yield _this.adelantosService.syncGetGastosAnticipo(_this.adelantosService.adelantoViatico.id);
      });
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }());
  }
  cerrarModal() {
    this.modalCtrl.dismiss();
  }
  liquidar() {
    this.alertasService.message('DIONE', 'La opción no se encuentra disponible..');
  }
  lineaGastos(linea) {
    var _this2 = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.isOpen = true;
      const modal = yield _this2.modalCtrl.create({
        component: _linea_gastos_linea_gastos_page__WEBPACK_IMPORTED_MODULE_7__.LineaGastosPage,
        cssClass: 'alert-modal',
        componentProps: {
          linea
        }
      });
      if (_this2.isOpen) {
        modal.present();
        const {
          data
        } = yield modal.onWillDismiss();
        _this2.isOpen = false;
        if (data != undefined) {}
      }
    })();
  }
  enviarCorreo(linea) {
    if (linea.estatus == 'A') {
      this.alertasService.message('APP', 'Lo sentimos no se pueden enviar mas correos!');
      return;
    }
    this.alertasService.presentaLoading('Enviando correo...');
    let correo = {
      toEmail: 'workemailnelson@gmail.com',
      file: null,
      subject: 'Recordatorio Liquidacion Gastos',
      body: 'Por favor proceder a liquidar los gatos '
    };
    this.correosService.syncPostEmailToPromise(correo).then(resp => {
      this.alertasService.message('APP', 'Correo enviado..');
      this.alertasService.loadingDissmiss();
      console.log('resp', resp);
    }, error => {
      this.alertasService.loadingDissmiss();
      this.alertasService.message('APP', 'Lo sentimos algo salio mal...');
    });
  }
  liquidarAnticipo() {
    var _this3 = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let filter = _this3.lineas.filter(e => e.estatus == 'A');
      if (filter.length != _this3.lineas.length) {
        _this3.alertasService.message('SD1', 'Lo sentimos, debes de aprobar todas las lineas de anticipo para continuar!.');
        return;
      }
      _this3.adelantosService.adelantoViatico.eSTATUS = 'F';
      yield _this3.adelantosService.syncPuttAdelantoViaticosToPromise(_this3.adelantosService.adelantoViatico);
      _this3.alertasService.message('APP', 'Anticipo Atualizado');
    })();
  }
};
DetalleAnticipoPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.ModalController
}, {
  type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_4__.AlertasService
}, {
  type: src_app_services_adelanto_viaticos_service__WEBPACK_IMPORTED_MODULE_3__.AdelantoViaticosService
}, {
  type: src_app_services_lineas_anticipos_service__WEBPACK_IMPORTED_MODULE_6__.LineasAnticiposService
}, {
  type: src_app_services_gastos_service__WEBPACK_IMPORTED_MODULE_5__.GastosService
}, {
  type: src_app_services_correo_service__WEBPACK_IMPORTED_MODULE_8__.CorreoService
}];
DetalleAnticipoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
  selector: 'app-detalle-anticipo',
  template: _detalle_anticipo_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_detalle_anticipo_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], DetalleAnticipoPage);


/***/ }),

/***/ 10262:
/*!******************************************************************************!*\
  !*** ./src/app/pages/detalle-anticipo/detalle-anticipo.page.scss?ngResource ***!
  \******************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 49579);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60931);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "ion-footer ion-toolbar {\n  --background: #f5f5f3;\n}\nion-footer ion-button {\n  --padding-top: 1rem;\n  --padding-bottom: 1rem;\n  --padding-start: 0.75rem;\n  --padding-end: 0.75rem;\n  letter-spacing: 1.5px;\n  height: 3.5rem;\n  font-weight: 700;\n}\n\n.ion-item {\n  border-radius: 10px;\n  --ion-item-background: rgba(0, 0, 0, 0.09);\n  margin: 0.5rem;\n  margin-bottom: 1rem;\n}", "",{"version":3,"sources":["webpack://./src/app/pages/detalle-anticipo/detalle-anticipo.page.scss","webpack://./../../Simple%20Design%20Experience/Control%20Viaticos/src/app/pages/detalle-anticipo/detalle-anticipo.page.scss"],"names":[],"mappings":"AACI;EACI,qBAAA;ACAR;ADEQ;EACI,mBAAA;EACA,sBAAA;EACA,wBAAA;EACA,sBAAA;EACA,qBAAA;EACA,cAAA;EACA,gBAAA;ACAZ;;ADII;EACI,mBAAA;EACA,0CAAA;EACA,cAAA;EACA,mBAAA;ACDR","sourcesContent":["ion-footer{\r\n    ion-toolbar{\r\n        --background: #f5f5f3;\r\n    }\r\n        ion-button {\r\n            --padding-top: 1rem;\r\n            --padding-bottom: 1rem;\r\n            --padding-start: 0.75rem;\r\n            --padding-end: 0.75rem;\r\n            letter-spacing: 1.5px;\r\n            height: 3.5rem;\r\n            font-weight: 700;\r\n        }\r\n    }\r\n    \r\n    .ion-item{\r\n        border-radius: 10px;\r\n        --ion-item-background:  rgba(0, 0, 0, 0.09);\r\n        margin: 0.5rem;\r\n        margin-bottom: 1rem;\r\n       }\r\n    \r\n       ","ion-footer ion-toolbar {\n  --background: #f5f5f3;\n}\nion-footer ion-button {\n  --padding-top: 1rem;\n  --padding-bottom: 1rem;\n  --padding-start: 0.75rem;\n  --padding-end: 0.75rem;\n  letter-spacing: 1.5px;\n  height: 3.5rem;\n  font-weight: 700;\n}\n\n.ion-item {\n  border-radius: 10px;\n  --ion-item-background: rgba(0, 0, 0, 0.09);\n  margin: 0.5rem;\n  margin-bottom: 1rem;\n}"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 90276:
/*!******************************************************************************!*\
  !*** ./src/app/pages/detalle-anticipo/detalle-anticipo.page.html?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n\n \n<ion-content class=\"ion-padding\">\n  <ion-grid *ngIf=\"gastos.length > 0\" style=\"height: 100%;width: 80%;\" >\n    <ion-row style=\"height: 100%;\">\n\n      <ion-col size=\"12\"  class=\"ion-padding\">\n        <app-pie-chart ></app-pie-chart>\n                </ion-col>\n    </ion-row>\n  </ion-grid>\n  \n  <ion-grid  style=\"max-width: 80%;\">\n    <ion-row>\n\n      <ion-col size=\"6\">\n<ion-row>\n  <ion-col size=\"12\" class=\"ion-text-left\">\n<h6 class=\"ion-text-wrap\"> <strong>Anticipo # {{adelantosService.adelantoViatico.id}} -  {{adelantosService.adelantoViatico.coD_COMPANIA}}</strong></h6>\n  </ion-col>\n\n</ion-row>\n\n      </ion-col>\n      <ion-col size=\"6\">\n        <ion-row>\n \n          <ion-col size=\"12\" class=\"ion-text-left\">\n            <ion-label>Fecha Transacción {{adelantosService.adelantoViatico.fechA_TRANSACCION  | date:'shortDate'}}</ion-label>\n          </ion-col>\n          <ion-col size=\"12\" class=\"ion-text-left\">\n            <ion-label>Fecha Inicial {{adelantosService.adelantoViatico.fechA_INICIAL  | date:'shortDate'}}</ion-label>\n          </ion-col>\n          <ion-col size=\"12\" class=\"ion-text-left\">\n            <ion-label>Fecha Final {{adelantosService.adelantoViatico.fechA_FINAL | date:'shortDate'}}</ion-label>\n          </ion-col>\n\n        </ion-row>\n      </ion-col>\n\n\n    </ion-row>\n    <ion-row class=\"ion-padding\">\n      <ion-col size=\"3\">\n        <ion-label><strong># Transacción</strong></ion-label>\n        </ion-col>\n      <ion-col size=\"3\">\n      <ion-label><strong>Descripción</strong></ion-label>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-label><strong>Monto</strong></ion-label>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-label><strong>Usuarios</strong></ion-label>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-label>{{adelantosService.adelantoViatico.numerO_TRANSACCION}}</ion-label>\n      </ion-col>\n      <ion-col size=\"3\">\n      <ion-label>{{adelantosService.adelantoViatico.detalle}}</ion-label>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-label>{{adelantosService.adelantoViatico.monto | colones : 2 : '.' : ',' :  adelantosService.adelantoViatico.moneda }}</ion-label>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-label>{{lineas.length}}</ion-label>\n      </ion-col>\n    </ion-row>\n\n  </ion-grid>\n\n  <ion-grid  style=\"max-width: 80%;\">\n    <ion-row>\n \n      <ion-col size=\"12\">\n\n        <ion-item class=\"ion-item\" lines=\"none\" *ngFor=\"let usuario of  lineas; let i = index;\"  >\n      \n          <ion-avatar  slot=\"start\">\n            <img   src=\"../assets/imgs/user.svg\" />\n          </ion-avatar>\n      \n          <ion-label slot=\"start\">{{usuario.usuario}}\n      \n            <p style=\"margin-top: 0.5rem;\">\n              <ion-badge color=\"primary\" mode=\"ios\">{{usuario.monto | colones : 2 : '.' : ',' :  adelantosService.adelantoViatico.moneda }}</ion-badge>\n            </p>\n      \n          </ion-label>\n          <ion-badge  slot=\"end\" color=\"warning\" mode=\"ios\">{{usuario.estatus == 'P' ?  'Pendiente' :  usuario.estatus == 'A' ? 'Aprobada' : usuario.estatus == 'I' ? 'Requiere Aprobacion' : 'Rechazada'}}</ion-badge>\n          <span slot=\"end\"   style=\"position: relative;\">\n            <ion-fab-button (click)=\"enviarCorreo(usuario)\" size=\"small\">\n              <ion-icon name=\"mail\"></ion-icon>\n            </ion-fab-button>\n            <ion-badge style=\"position: absolute; top: 0rem;right: -1rem;\" color=\"warning\" mode=\"ios\">{{usuario.correO_ENVIADO}}</ion-badge>\n          </span>\n          <ion-fab-button (click)=\"lineaGastos(usuario)\" slot=\"end\" size=\"small\">\n            <ion-icon name=\"eye\"></ion-icon>\n          </ion-fab-button>\n        </ion-item>\n        <ion-item lines=\"none\">\n          <ion-grid >\n            <ion-row>\n              <ion-col size=\"6\">\n              <ion-label><strong>Pendientes</strong></ion-label>\n              </ion-col>\n              <ion-col size=\"6\"  class=\"ion-text-right\">\n                <ion-label>\n                  <ion-badge color=\"warning\" mode=\"ios\">0</ion-badge>\n                </ion-label>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n       \n                </ion-item>\n        <ion-item lines=\"none\">\n          <ion-grid >\n            <ion-row>\n              <ion-col size=\"6\">\n              <ion-label><strong>Sobrantes</strong></ion-label>\n              </ion-col>\n              <ion-col size=\"6\"  class=\"ion-text-right\">\n                <ion-label>\n                  <ion-badge color=\"warning\" mode=\"ios\">{{adelantosService.adelantoViatico.restante | colones : 2 : '.' : ',' :  adelantosService.adelantoViatico.moneda }}</ion-badge>\n                </ion-label>\n              </ion-col>\n           \n              \n            </ion-row>\n          </ion-grid>\n       \n                </ion-item>\n\n                <ion-item lines=\"none\">\n                  <ion-grid >\n                    <ion-row>\n                      <ion-col size=\"6\">\n                      <ion-label><strong>Excedentes</strong></ion-label>\n                      </ion-col>\n                      <ion-col size=\"6\"  class=\"ion-text-right\">\n                        <ion-label>\n                          <ion-badge color=\"warning\" mode=\"ios\">{{0 | colones : 2 : '.' : ',' :  adelantosService.adelantoViatico.moneda }}</ion-badge>\n                        </ion-label>\n                      </ion-col>\n                    </ion-row>\n                  </ion-grid>\n               \n                        </ion-item>\n\n                        <ion-item lines=\"none\">\n                          <ion-grid >\n                            <ion-row>\n                              <ion-col size=\"6\">\n                              <ion-label><strong>Total</strong></ion-label>\n                              </ion-col>\n                              <ion-col size=\"6\"  class=\"ion-text-right\">\n                                <ion-label>\n                                  <ion-badge color=\"warning\" mode=\"ios\">{{adelantosService.adelantoViatico.monto | colones : 2 : '.' : ',' :  adelantosService.adelantoViatico.moneda }}</ion-badge>\n                                </ion-label>\n                              </ion-col>\n                            </ion-row>\n                          </ion-grid>\n                       \n                                </ion-item>\n      </ion-col>\n      <ion-col size=\"12\" class=\"ion-padding\" *ngIf=\"adelantosService.adelantoViatico.eSTATUS  != 'F'\">\n        <ion-button (click)=\"liquidarAnticipo()\"   expand=\"block\" fill=\"solid\" color=\"dark\" mode=\"ios\">\n          Liquidar Anticipo\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n  \n  </ion-content>\n  <app-pie-pagina></app-pie-pagina>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_detalle-anticipo_detalle-anticipo_module_ts.js.map