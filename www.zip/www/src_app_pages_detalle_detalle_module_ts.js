(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_detalle_detalle_module_ts"],{

/***/ 38465:
/*!*********************************************************!*\
  !*** ./src/app/pages/detalle/detalle-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetallePageRoutingModule": () => (/* binding */ DetallePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _detalle_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./detalle.page */ 25671);




const routes = [{
  path: '',
  component: _detalle_page__WEBPACK_IMPORTED_MODULE_0__.DetallePage
}];
let DetallePageRoutingModule = class DetallePageRoutingModule {};
DetallePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
  imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
  exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
})], DetallePageRoutingModule);


/***/ }),

/***/ 12293:
/*!*************************************************!*\
  !*** ./src/app/pages/detalle/detalle.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetallePageModule": () => (/* binding */ DetallePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _detalle_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./detalle-routing.module */ 38465);
/* harmony import */ var _detalle_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./detalle.page */ 25671);
/* harmony import */ var src_app_components_component_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/component.module */ 78443);








let DetallePageModule = class DetallePageModule {};
DetallePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule, _detalle_routing_module__WEBPACK_IMPORTED_MODULE_0__.DetallePageRoutingModule, src_app_components_component_module__WEBPACK_IMPORTED_MODULE_2__.ComponentModule],
  declarations: [_detalle_page__WEBPACK_IMPORTED_MODULE_1__.DetallePage]
})], DetallePageModule);


/***/ }),

/***/ 25671:
/*!***********************************************!*\
  !*** ./src/app/pages/detalle/detalle.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetallePage": () => (/* binding */ DetallePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _detalle_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./detalle.page.html?ngResource */ 77450);
/* harmony import */ var _detalle_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./detalle.page.scss?ngResource */ 61828);
/* harmony import */ var _detalle_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_detalle_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);




let DetallePage = class DetallePage {
  constructor() {
    this.image = '../assets/imgs/devCodingLogo.svg';
    this.appPages = [{
      title: 'Inicio',
      url: '/inicio/detalle',
      icon: 'home'
    }, {
      title: 'Departamentos',
      url: '/inicio/control-departamentos',
      icon: 'business'
    }, {
      title: 'Acceso',
      url: '/inicio/control-matriz-acceso',
      icon: 'shield'
    }, {
      title: 'Usuarios',
      url: '/inicio/control-usuarios',
      icon: 'people'
    }, {
      title: 'Gestión Anticipos',
      url: '/inicio/control-anticipos',
      icon: 'document-text'
    },
    //{ title: 'Viáticos', url: '/inicio/control-viaticos', icon: 'cash' },
    {
      title: 'Estados Cuenta',
      url: '/inicio/control-estados-cuenta',
      icon: 'card'
    }];
  }
  ngOnInit() {}
};
DetallePage.ctorParameters = () => [];
DetallePage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
  selector: 'app-detalle',
  template: _detalle_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
  styles: [(_detalle_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1___default())]
})], DetallePage);


/***/ }),

/***/ 61828:
/*!************************************************************!*\
  !*** ./src/app/pages/detalle/detalle.page.scss?ngResource ***!
  \************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 49579);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60931);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 77450:
/*!************************************************************!*\
  !*** ./src/app/pages/detalle/detalle.page.html?ngResource ***!
  \************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\r\n\r\n<ion-content class=\"ion-padding\">\r\n\r\n<ion-grid >\r\n<ion-row>\r\n  <ion-col size=\"12\" size-md=\"6\">\r\n    <ion-row>\r\n \r\n      <ion-col size=\"12\">\r\n       <h1><strong>Control-Viáticos</strong></h1>\r\n      </ion-col>\r\n      <ion-col size=\"12\">\r\n        <ion-label><strong>Distribuidora Coris</strong></ion-label>\r\n     </ion-col>\r\n\r\n      <ion-col size=\"12\">\r\n         <ion-label>Telefono: (506) xxx-xxx</ion-label>\r\n      </ion-col>\r\n \r\n      <ion-col size=\"12\">\r\n         <ion-label>Dirección:xxxxxxx</ion-label>\r\n      </ion-col>\r\n      <ion-col size=\"12\">\r\n         <ion-label><a href=\"https://\" target=\"_blank\">https://</a></ion-label>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-col>\r\n  <ion-col size=\"12\" size-md=\"6\">\r\n    <ion-list>\r\n      <ion-item>\r\n        <ion-label class=\"ion-text-uppercase\"><strong>Modulos Incluidos </strong></ion-label>\r\n      </ion-item>\r\n\r\n      <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages; let i = index\">\r\n        <ion-item     style=\"margin-top:0.5rem\"   lines=\"full\" detail=\"false\" routerLinkActive=\"selected\">\r\n          <ion-icon slot=\"start\" [ios]=\"p.icon + '-outline'\" [md]=\"p.icon + '-sharp'\"></ion-icon>\r\n          <ion-label  >{{ p.title }}</ion-label>\r\n        </ion-item>\r\n      </ion-menu-toggle>\r\n    </ion-list>\r\n  </ion-col>\r\n</ion-row>\r\n</ion-grid>\r\n</ion-content>\r\n<app-pie-pagina></app-pie-pagina>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_detalle_detalle_module_ts.js.map