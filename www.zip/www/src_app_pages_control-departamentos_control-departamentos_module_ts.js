(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_control-departamentos_control-departamentos_module_ts"],{

/***/ 96321:
/*!*************************************************************************************!*\
  !*** ./src/app/pages/control-departamentos/control-departamentos-routing.module.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ControlDepartamentosPageRoutingModule": () => (/* binding */ ControlDepartamentosPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _control_departamentos_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./control-departamentos.page */ 45216);




const routes = [{
  path: '',
  component: _control_departamentos_page__WEBPACK_IMPORTED_MODULE_0__.ControlDepartamentosPage
}];
let ControlDepartamentosPageRoutingModule = class ControlDepartamentosPageRoutingModule {};
ControlDepartamentosPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
  imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
  exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
})], ControlDepartamentosPageRoutingModule);


/***/ }),

/***/ 89504:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/control-departamentos/control-departamentos.module.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ControlDepartamentosPageModule": () => (/* binding */ ControlDepartamentosPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _control_departamentos_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./control-departamentos-routing.module */ 96321);
/* harmony import */ var _control_departamentos_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./control-departamentos.page */ 45216);
/* harmony import */ var src_app_components_component_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/component.module */ 78443);








let ControlDepartamentosPageModule = class ControlDepartamentosPageModule {};
ControlDepartamentosPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule, _control_departamentos_routing_module__WEBPACK_IMPORTED_MODULE_0__.ControlDepartamentosPageRoutingModule, src_app_components_component_module__WEBPACK_IMPORTED_MODULE_2__.ComponentModule],
  declarations: [_control_departamentos_page__WEBPACK_IMPORTED_MODULE_1__.ControlDepartamentosPage]
})], ControlDepartamentosPageModule);


/***/ }),

/***/ 45216:
/*!***************************************************************************!*\
  !*** ./src/app/pages/control-departamentos/control-departamentos.page.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ControlDepartamentosPage": () => (/* binding */ ControlDepartamentosPage)
/* harmony export */ });
/* harmony import */ var C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _control_departamentos_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./control-departamentos.page.html?ngResource */ 95193);
/* harmony import */ var _control_departamentos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./control-departamentos.page.scss?ngResource */ 57729);
/* harmony import */ var _control_departamentos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_control_departamentos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/alertas.service */ 34997);
/* harmony import */ var src_app_services_departamentos_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/departamentos.service */ 66646);
/* harmony import */ var _crear_departamento_crear_departamento_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../crear-departamento/crear-departamento.page */ 78063);
/* harmony import */ var _editar_departamento_editar_departamento_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../editar-departamento/editar-departamento.page */ 88384);
/* harmony import */ var src_app_services_usuarios_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/usuarios.service */ 81209);











let ControlDepartamentosPage = class ControlDepartamentosPage {
  constructor(alertasService, modalCtrl, departamentosService, alertCrl, usuariosService) {
    this.alertasService = alertasService;
    this.modalCtrl = modalCtrl;
    this.departamentosService = departamentosService;
    this.alertCrl = alertCrl;
    this.usuariosService = usuariosService;
    this.isOpen = false;
  }
  ngOnInit() {
    this.alertasService.presentaLoading('Cargando datos..');
    this.departamentosService.syncGetDepartamentoToPromise().then(departamentos => {
      this.departamentosService.departamentos = departamentos;
      this.alertasService.loadingDissmiss();
    }, error => {
      this.alertasService.loadingDissmiss();
    });
  }
  crearDepartamento() {
    var _this = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.isOpen = true;
      const modal = yield _this.modalCtrl.create({
        component: _crear_departamento_crear_departamento_page__WEBPACK_IMPORTED_MODULE_5__.CrearDepartamentoPage,
        cssClass: 'alert-modal'
      });
      if (_this.isOpen) {
        modal.present();
        const {
          data
        } = yield modal.onWillDismiss();
        _this.isOpen = false;
        if (data != undefined) {}
      }
    })();
  }
  editarDepartamento(departamento) {
    var _this2 = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.isOpen = true;
      const modal = yield _this2.modalCtrl.create({
        component: _editar_departamento_editar_departamento_page__WEBPACK_IMPORTED_MODULE_6__.EditarDepartamentoPage,
        cssClass: 'alert-modal',
        componentProps: {
          departamento
        }
      });
      if (_this2.isOpen) {
        modal.present();
        const {
          data
        } = yield modal.onWillDismiss();
        _this2.isOpen = false;
        if (data != undefined) {}
      }
    })();
  }
  borrarDepartamento(departamento) {
    var _this3 = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this3.alertCrl.create({
        subHeader: 'Dione',
        message: `¿Desea borrar el departamento ${departamento.nombre}?`,
        buttons: [{
          text: 'cancelar',
          role: 'cancel',
          handler: () => {
            console.log('cancel');
          }
        }, {
          text: 'continuar',
          role: 'confirm',
          handler: function () {
            var _ref = (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
              _this3.alertasService.presentaLoading('Borrando datos..');
              _this3.departamentosService.syncDeleteDepartamentoToPromise(departamento.id).then(resp => {
                _this3.alertasService.loadingDissmiss();
                _this3.departamentosService.syncGetDepartamentoToPromise().then(departamentos => {
                  _this3.departamentosService.departamentos = departamentos;
                }, error => {
                  _this3.alertasService.loadingDissmiss();
                  _this3.alertasService.message('Dione', 'Lo sentimos algo salio mal...');
                });
              }, error => {
                _this3.alertasService.loadingDissmiss();
                _this3.alertasService.message('Dione', 'Lo sentimos algo salio mal...');
              });
            });
            return function handler() {
              return _ref.apply(this, arguments);
            };
          }()
        }]
      });
      alert.present();
    })();
  }
};
ControlDepartamentosPage.ctorParameters = () => [{
  type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_3__.AlertasService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController
}, {
  type: src_app_services_departamentos_service__WEBPACK_IMPORTED_MODULE_4__.DepartamentosService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.AlertController
}, {
  type: src_app_services_usuarios_service__WEBPACK_IMPORTED_MODULE_7__.UsuariosService
}];
ControlDepartamentosPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
  selector: 'app-control-departamentos',
  template: _control_departamentos_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_control_departamentos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], ControlDepartamentosPage);


/***/ }),

/***/ 66646:
/*!***************************************************!*\
  !*** ./src/app/services/departamentos.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DepartamentosService": () => (/* binding */ DepartamentosService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 92340);




let DepartamentosService = class DepartamentosService {
  constructor(http) {
    this.http = http;
    this.departamentos = [];
  }
  getAPI(api) {
    let test = '';
    if (!_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.prdMode) test = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.TestURL;
    const URL = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.preURL + test + _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postURL + api;
    return URL;
  }
  getDepartamentos() {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getDepartamentos);
    console.log('URL', URL);
    return this.http.get(URL);
  }
  postDepartamento(departamento) {
    const URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postDepartamento);
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control': '*'
      }
    };
    return this.http.post(URL, departamento, options);
  }
  putDepartamento(departamento) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.putDepartamento);
    URL = URL + departamento.id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    };
    console.log(URL);
    console.log(departamento);
    return this.http.put(URL, departamento, options);
  }
  deleteDepartamento(id) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.deleteDepartamento);
    URL = URL + id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    };
    return this.http.delete(URL, options);
  }
  syncGetDepartamentoToPromise() {
    return this.getDepartamentos().toPromise();
  }
  syncPostDepartamentoToPromise(departamento) {
    return this.postDepartamento(departamento).toPromise();
  }
  syncPutDepartamentoToPromise(departamento) {
    return this.putDepartamento(departamento).toPromise();
  }
  syncDeleteDepartamentoToPromise(id) {
    return this.deleteDepartamento(id).toPromise();
  }
};
DepartamentosService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
}];
DepartamentosService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], DepartamentosService);


/***/ }),

/***/ 57729:
/*!****************************************************************************************!*\
  !*** ./src/app/pages/control-departamentos/control-departamentos.page.scss?ngResource ***!
  \****************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 49579);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60931);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 95193:
/*!****************************************************************************************!*\
  !*** ./src/app/pages/control-departamentos/control-departamentos.page.html?ngResource ***!
  \****************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n<ion-header class=\"ion-no-border ion-padding\">\n  <ion-toolbar  >\n    <ion-title class=\"ion-text-capitalize\" class=\"page-title\"> \n      Departamentos</ion-title>\n    <ion-searchbar    slot=\"end\" style=\"width:30%;margin-top: 1rem;\" mode=\"ios\" placeholder=\"buscar departamento\"  type=\"text\"   [debounce]=\"250\"  ></ion-searchbar>\n    <ion-fab-button *ngIf=\"usuariosService.moduloAcceso.c\" (click)=\"crearDepartamento()\" size=\"small\"    class=\"margin-right\"  slot=\"end\" color=\"dark\"  >\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n\n  </ion-toolbar>\n\n  <ion-list >\n    <ion-item lines=\"full\"  >\n      <ion-grid >\n        <ion-row>\n          <ion-col>\n            <ion-label><strong>\n              Nombre\n            </strong></ion-label>\n                  </ion-col>\n          <ion-col >\n    <ion-label><strong>\n      Descripción\n    </strong></ion-label>\n          </ion-col>\n          <ion-col>\n            <ion-label><strong>\n             Opciones\n            </strong></ion-label>\n                  </ion-col>\n \n  \n        </ion-row>\n      </ion-grid>\n    </ion-item>\n  </ion-list>\n</ion-header>\n\n\n<ion-content>\n<ion-grid   style=\"height: 100%;\">\n<ion-list>\n  <ion-item  *ngFor=\"let departamento of departamentosService.departamentos\" >\n<ion-grid >\n  <ion-row>\n    <ion-col>\n<ion-label>{{departamento.nombre}} </ion-label>\n            </ion-col>\n    <ion-col >\n      <ion-label>{{departamento.descripcion}} </ion-label>\n    </ion-col>\n \n    <ion-col style=\"display: flex;justify-content: flex-start;align-items: center;\">\n <ion-button *ngIf=\"usuariosService.moduloAcceso.d\" (click)=\"borrarDepartamento(departamento)\"   fill=\"clear\"  >\n<ion-icon color=\"danger\" slot=\"icon-only\" name=\"trash\"></ion-icon>\n </ion-button>\n <ion-button  *ngIf=\"usuariosService.moduloAcceso.u\" (click)=\"editarDepartamento(departamento)\"   fill=\"clear\"  >\n  <ion-icon color=\"primary\" slot=\"icon-only\" name=\"create\"></ion-icon>\n   </ion-button>\n    </ion-col>\n \n  </ion-row>\n</ion-grid>\n  </ion-item>\n</ion-list>\n  <ion-row  *ngIf=\"departamentosService.departamentos.length == 0\"\n  style=\"height: 100%;display: flex;justify-content: center;align-items: center;\">\n  <ion-col size=\"12\">\n    <ion-list>\n      <ion-item lines=\"none\">\n\n        <ion-grid>\n          <ion-row>\n            <ion-col size=\"12\" class=\"ion-text-center ion-margin-top\">\n              <img height=\"150\" src=\"assets/imgs/empty-box.svg\" alt=\"\">\n            </ion-col>\n            <ion-col size=\"12\" class=\"ion-text-center\">\n              <strong class=\"ion-text-capitalize\">No hay datos que mostrar</strong>\n            </ion-col>\n\n          </ion-row>\n        </ion-grid>\n\n      </ion-item>\n    </ion-list>\n  </ion-col>\n</ion-row>\n\n</ion-grid>\n</ion-content>\n<app-pie-pagina></app-pie-pagina>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_control-departamentos_control-departamentos_module_ts.js.map