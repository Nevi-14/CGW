(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_control-usuarios_control-usuarios_module_ts"],{

/***/ 2830:
/*!***************************************************************************!*\
  !*** ./src/app/pages/control-usuarios/control-usuarios-routing.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ControlUsuariosPageRoutingModule": () => (/* binding */ ControlUsuariosPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _control_usuarios_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./control-usuarios.page */ 56135);




const routes = [{
  path: '',
  component: _control_usuarios_page__WEBPACK_IMPORTED_MODULE_0__.ControlUsuariosPage
}];
let ControlUsuariosPageRoutingModule = class ControlUsuariosPageRoutingModule {};
ControlUsuariosPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
  imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
  exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
})], ControlUsuariosPageRoutingModule);


/***/ }),

/***/ 8448:
/*!*******************************************************************!*\
  !*** ./src/app/pages/control-usuarios/control-usuarios.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ControlUsuariosPageModule": () => (/* binding */ ControlUsuariosPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _control_usuarios_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./control-usuarios-routing.module */ 2830);
/* harmony import */ var _control_usuarios_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./control-usuarios.page */ 56135);
/* harmony import */ var src_app_components_component_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/component.module */ 78443);








let ControlUsuariosPageModule = class ControlUsuariosPageModule {};
ControlUsuariosPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule, _control_usuarios_routing_module__WEBPACK_IMPORTED_MODULE_0__.ControlUsuariosPageRoutingModule, src_app_components_component_module__WEBPACK_IMPORTED_MODULE_2__.ComponentModule],
  declarations: [_control_usuarios_page__WEBPACK_IMPORTED_MODULE_1__.ControlUsuariosPage]
})], ControlUsuariosPageModule);


/***/ }),

/***/ 56135:
/*!*****************************************************************!*\
  !*** ./src/app/pages/control-usuarios/control-usuarios.page.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ControlUsuariosPage": () => (/* binding */ ControlUsuariosPage)
/* harmony export */ });
/* harmony import */ var C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _control_usuarios_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./control-usuarios.page.html?ngResource */ 54586);
/* harmony import */ var _control_usuarios_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./control-usuarios.page.scss?ngResource */ 78594);
/* harmony import */ var _control_usuarios_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_control_usuarios_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/alertas.service */ 34997);
/* harmony import */ var src_app_services_usuarios_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/usuarios.service */ 81209);
/* harmony import */ var _crear_usuario_crear_usuario_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../crear-usuario/crear-usuario.page */ 4842);
/* harmony import */ var _editar_usuario_editar_usuario_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../editar-usuario/editar-usuario.page */ 3450);
/* harmony import */ var src_app_services_usuarios_matriz_acceso_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/usuarios-matriz-acceso.service */ 4710);
/* harmony import */ var src_app_services_matriz_acceso_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/matriz-acceso.service */ 75444);












let ControlUsuariosPage = class ControlUsuariosPage {
  constructor(usuariosService, alertasService, modalCtrl, alertCrl, usuarioMatrizAccesoService, matrizAccesoService) {
    this.usuariosService = usuariosService;
    this.alertasService = alertasService;
    this.modalCtrl = modalCtrl;
    this.alertCrl = alertCrl;
    this.usuarioMatrizAccesoService = usuarioMatrizAccesoService;
    this.matrizAccesoService = matrizAccesoService;
    this.isOpen = false;
  }
  ngOnInit() {
    this.alertasService.presentaLoading('cargando datos..');
    this.usuariosService.syncGetUsuariosToPromise().then(usuarios => {
      this.alertasService.loadingDissmiss();
      this.usuariosService.usuarios = usuarios;
    }, error => {
      this.alertasService.loadingDissmiss();
    });
  }
  crearUsuario() {
    var _this = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.isOpen = true;
      const modal = yield _this.modalCtrl.create({
        component: _crear_usuario_crear_usuario_page__WEBPACK_IMPORTED_MODULE_5__.CrearUsuarioPage,
        cssClass: 'alert-modal'
      });
      if (_this.isOpen) {
        modal.present();
        const {
          data
        } = yield modal.onWillDismiss();
        _this.isOpen = false;
        if (data != undefined) {}
      }
    })();
  }
  editarUsuario(usuario) {
    var _this2 = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let rolesArray = yield _this2.usuarioMatrizAccesoService.syncGetUsuariosMatrizAccesoByIDtoToPromise(usuario.id);
      console.log('rolesArray', rolesArray);
      let roles = [];
      if (rolesArray.length == 0) {
        _this2.editaUsuario(usuario, roles);
      }
      rolesArray.forEach( /*#__PURE__*/function () {
        var _ref = (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (role, index) {
          roles.push(role.iD_ONE_MATRIZ_ACCESO);
          if (index == rolesArray.length - 1) {
            console.log(roles);
            _this2.editaUsuario(usuario, roles);
          }
        });
        return function (_x, _x2) {
          return _ref.apply(this, arguments);
        };
      }());
    })();
  }
  editaUsuario(usuario, roles) {
    var _this3 = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let matriz = yield _this3.matrizAccesoService.syncGetMatrizAccesotoToPromise();
      _this3.isOpen = true;
      const modal = yield _this3.modalCtrl.create({
        component: _editar_usuario_editar_usuario_page__WEBPACK_IMPORTED_MODULE_6__.EditarUsuarioPage,
        cssClass: 'alert-modal',
        componentProps: {
          usuario,
          roles,
          matriz
        }
      });
      if (_this3.isOpen) {
        modal.present();
        const {
          data
        } = yield modal.onWillDismiss();
        _this3.isOpen = false;
        if (data != undefined) {}
      }
    })();
  }
  borrarUsuario(usuario) {
    var _this4 = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this4.alertCrl.create({
        subHeader: 'Dione',
        message: `¿Desea borrar el usuario ${usuario.nombre}?`,
        buttons: [{
          text: 'cancelar',
          role: 'cancel',
          handler: () => {
            console.log('cancel');
          }
        }, {
          text: 'continuar',
          role: 'confirm',
          handler: function () {
            var _ref2 = (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
              _this4.alertasService.presentaLoading('Borrando datos..');
              _this4.usuariosService.syncDeleteUsuarioToPromise(usuario.id).then(resp => {
                _this4.alertasService.loadingDissmiss();
                _this4.usuariosService.syncGetUsuariosToPromise().then(usuarios => {
                  _this4.usuariosService.usuarios = usuarios;
                }, error => {
                  _this4.alertasService.loadingDissmiss();
                  _this4.alertasService.message('Dione', 'Lo sentimos algo salio mal...');
                });
              }, error => {
                _this4.alertasService.loadingDissmiss();
                _this4.alertasService.message('Dione', 'Lo sentimos algo salio mal...');
              });
            });
            return function handler() {
              return _ref2.apply(this, arguments);
            };
          }()
        }]
      });
      alert.present();
    })();
  }
};
ControlUsuariosPage.ctorParameters = () => [{
  type: src_app_services_usuarios_service__WEBPACK_IMPORTED_MODULE_4__.UsuariosService
}, {
  type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_3__.AlertasService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.ModalController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.AlertController
}, {
  type: src_app_services_usuarios_matriz_acceso_service__WEBPACK_IMPORTED_MODULE_7__.UsuariosMatrizAccesoService
}, {
  type: src_app_services_matriz_acceso_service__WEBPACK_IMPORTED_MODULE_8__.MatrizAccesoService
}];
ControlUsuariosPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
  selector: 'app-control-usuarios',
  template: _control_usuarios_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_control_usuarios_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], ControlUsuariosPage);


/***/ }),

/***/ 78594:
/*!******************************************************************************!*\
  !*** ./src/app/pages/control-usuarios/control-usuarios.page.scss?ngResource ***!
  \******************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 49579);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60931);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 54586:
/*!******************************************************************************!*\
  !*** ./src/app/pages/control-usuarios/control-usuarios.page.html?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n<ion-header class=\"ion-no-border ion-padding\">\n  <ion-toolbar  >\n    <ion-title class=\"ion-text-capitalize\" class=\"page-title\"> \n      Usuarios</ion-title>\n    <ion-searchbar    slot=\"end\" style=\"width:30%;margin-top: 1rem;\" mode=\"ios\" placeholder=\"buscar usuario\"  type=\"text\"   [debounce]=\"250\"  ></ion-searchbar>\n    <ion-fab-button *ngIf=\"usuariosService.moduloAcceso.c\" (click)=\"crearUsuario()\"  size=\"small\"    class=\"margin-right\"  slot=\"end\" color=\"dark\"  >\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n\n  </ion-toolbar>\n\n  <ion-list >\n    <ion-item lines=\"full\"  >\n      <ion-grid >\n        <ion-row>\n          <ion-col>\n            <ion-label><strong>\n              Usuario\n            </strong></ion-label>\n                  </ion-col>\n                  <ion-col>\n                    <ion-label><strong>\n                      Apellido\n                    </strong></ion-label>\n                          </ion-col>\n                          <ion-col>\n                            <ion-label><strong>\n                              Apellido\n                            </strong></ion-label>\n                                  </ion-col>\n          <ion-col size=\"3\">\n    <ion-label><strong>\n      Correo\n    </strong></ion-label>\n          </ion-col>\n          <ion-col>\n            <ion-label><strong>\n             Fecha\n            </strong></ion-label>\n                  </ion-col>\n          <ion-col >\n    <ion-label><strong>\n      Estatus\n    </strong></ion-label>\n          </ion-col>\n     \n          <ion-col>\n            <ion-label><strong>\n              Opciones\n            </strong></ion-label>\n          </ion-col>\n  \n        </ion-row>\n      </ion-grid>\n    </ion-item>\n  </ion-list>\n</ion-header>\n\n\n<ion-content>\n<ion-grid   style=\"height: 100%;\">\n<ion-list>\n  <ion-item  *ngFor=\"let usuario of usuariosService.usuarios\" >\n<ion-grid >\n  <ion-row>\n    <ion-col>\n<ion-label>{{usuario.usuario}} </ion-label>\n            </ion-col>\n            <ion-col>\n              <ion-label>{{usuario.nombre}} </ion-label>\n                          </ion-col>\n                          <ion-col>\n                            <ion-label>{{usuario.apellido}} </ion-label>\n                                        </ion-col>\n    <ion-col  size=\"3\">\n      <ion-label>{{usuario.correo}} </ion-label>\n    </ion-col>\n    <ion-col>\n      <ion-label>{{usuario.fecha | date}} </ion-label>\n            </ion-col>\n    <ion-col >\n      <ion-label><ion-badge color=\"warning\" mode=\"ios\">{{usuario.estatus ? 'Activo' : 'Inactivo'}}</ion-badge> </ion-label>\n    </ion-col>\n \n    <ion-col style=\"display: flex;justify-content: flex-start;align-items: center;\">\n <ion-button  *ngIf=\"usuariosService.moduloAcceso.d\" (click)=\"borrarUsuario(usuario)\"  fill=\"clear\"  >\n<ion-icon color=\"danger\" slot=\"icon-only\" name=\"trash\"></ion-icon>\n </ion-button>\n <ion-button *ngIf=\"usuariosService.moduloAcceso.u\"  (click)=\"editarUsuario(usuario)\"   fill=\"clear\"  >\n  <ion-icon color=\"primary\" slot=\"icon-only\" name=\"create\"></ion-icon>\n   </ion-button>\n    </ion-col>\n \n  </ion-row>\n</ion-grid>\n  </ion-item>\n</ion-list>\n  <ion-row  *ngIf=\"usuariosService.usuarios.length == 0\" \n  style=\"height: 100%;display: flex;justify-content: center;align-items: center;\">\n  <ion-col size=\"12\">\n    <ion-list>\n      <ion-item lines=\"none\">\n\n        <ion-grid>\n          <ion-row>\n            <ion-col size=\"12\" class=\"ion-text-center ion-margin-top\">\n              <img height=\"150\" src=\"assets/imgs/empty-box.svg\" alt=\"\">\n            </ion-col>\n            <ion-col size=\"12\" class=\"ion-text-center\">\n              <strong class=\"ion-text-capitalize\">No hay datos que mostrar</strong>\n            </ion-col>\n\n          </ion-row>\n        </ion-grid>\n\n      </ion-item>\n    </ion-list>\n  </ion-col>\n</ion-row>\n\n</ion-grid>\n</ion-content>\n<app-pie-pagina></app-pie-pagina>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_control-usuarios_control-usuarios_module_ts.js.map