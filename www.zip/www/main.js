(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["main"],{

/***/ 90158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _guards_matriz_acceso_guard__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./guards/matriz-acceso.guard */ 49640);
/* harmony import */ var _guards_usuario_autenticado_guard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./guards/usuario-autenticado.guard */ 69170);





const routes = [{
  path: '',
  redirectTo: 'inicio-sesion',
  pathMatch: 'full'
}, {
  path: 'calendario-popover',
  loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_calendario-popover_calendario-popover_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/calendario-popover/calendario-popover.module */ 58230)).then(m => m.CalendarioPopoverPageModule)
}, {
  path: 'inicio-sesion',
  loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_inicio-sesion_inicio-sesion_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/inicio-sesion/inicio-sesion.module */ 9943)).then(m => m.InicioSesionPageModule)
}, {
  path: 'inicio',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_inicio_inicio_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/inicio/inicio.module */ 83633)).then(m => m.InicioPageModule),
  canLoad: [_guards_usuario_autenticado_guard__WEBPACK_IMPORTED_MODULE_1__.UsuarioAutenticadoGuard],
  canActivate: [_guards_matriz_acceso_guard__WEBPACK_IMPORTED_MODULE_0__.MatrizAccesoGuard]
}, {
  path: 'perfil',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_perfil_perfil_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/perfil/perfil.module */ 16217)).then(m => m.PerfilPageModule)
}, {
  path: 'estado-cuenta',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_date-fns_esm_format_index_js"), __webpack_require__.e("default-src_app_pages_estado-cuenta_estado-cuenta_page_ts"), __webpack_require__.e("src_app_pages_estado-cuenta_estado-cuenta_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/estado-cuenta/estado-cuenta.module */ 84493)).then(m => m.EstadoCuentaPageModule)
}, {
  path: 'crear-matriz-acceso',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_companias_service_ts-src_app_services_departamentos_service_ts-src_a-f8fa17"), __webpack_require__.e("default-src_app_pages_crear-matriz-acceso_crear-matriz-acceso_page_ts"), __webpack_require__.e("src_app_pages_crear-matriz-acceso_crear-matriz-acceso_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/crear-matriz-acceso/crear-matriz-acceso.module */ 33611)).then(m => m.CrearMatrizAccesoPageModule)
}, {
  path: 'editar-matriz-acceso',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_companias_service_ts-src_app_services_departamentos_service_ts-src_a-f8fa17"), __webpack_require__.e("default-src_app_pages_editar-matriz-acceso_editar-matriz-acceso_page_ts"), __webpack_require__.e("src_app_pages_editar-matriz-acceso_editar-matriz-acceso_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/editar-matriz-acceso/editar-matriz-acceso.module */ 72164)).then(m => m.EditarMatrizAccesoPageModule)
}, {
  path: 'crear-usuario',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_pages_crear-usuario_crear-usuario_page_ts"), __webpack_require__.e("src_app_pages_crear-usuario_crear-usuario_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/crear-usuario/crear-usuario.module */ 95501)).then(m => m.CrearUsuarioPageModule)
}, {
  path: 'editar-usuario',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_editar-usuario_editar-usuario_module_ts-src_app_services_matriz-acceso_service_-3c9318")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/editar-usuario/editar-usuario.module */ 51433)).then(m => m.EditarUsuarioPageModule)
}, {
  path: 'crear-departamento',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_crear-departamento_crear-departamento_module_ts-src_app_services_departamentos_-0c498b")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/crear-departamento/crear-departamento.module */ 75327)).then(m => m.CrearDepartamentoPageModule)
}, {
  path: 'editar-departamento',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_editar-departamento_editar-departamento_module_ts-src_app_services_departamento-ea4f8a")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/editar-departamento/editar-departamento.module */ 7018)).then(m => m.EditarDepartamentoPageModule)
}, {
  path: 'linea-gastos',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_date-fns_esm_format_index_js"), __webpack_require__.e("default-src_app_pages_cierre-contable-linea-anticipo_cierre-contable-linea-anticipo_page_ts-s-43138b"), __webpack_require__.e("default-src_app_pages_linea-gastos_linea-gastos_page_ts"), __webpack_require__.e("common"), __webpack_require__.e("src_app_pages_linea-gastos_linea-gastos_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/linea-gastos/linea-gastos.module */ 56842)).then(m => m.LineaGastosPageModule)
}, {
  path: 'lista-usuarios',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_lista-usuarios_lista-usuarios_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/lista-usuarios/lista-usuarios.module */ 61689)).then(m => m.ListaUsuariosPageModule)
}, {
  path: 'cierre-contable-linea-anticipo',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_date-fns_esm_format_index_js"), __webpack_require__.e("default-src_app_pages_cierre-contable-linea-anticipo_cierre-contable-linea-anticipo_page_ts-s-43138b"), __webpack_require__.e("common"), __webpack_require__.e("src_app_pages_cierre-contable-linea-anticipo_cierre-contable-linea-anticipo_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/cierre-contable-linea-anticipo/cierre-contable-linea-anticipo.module */ 81332)).then(m => m.CierreContableLineaAnticipoPageModule)
}, {
  path: 'cierre-contable-anticipo',
  loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_cierre-contable-anticipo_cierre-contable-anticipo_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/cierre-contable-anticipo/cierre-contable-anticipo.module */ 16061)).then(m => m.CierreContableAnticipoPageModule)
}];
let AppRoutingModule = class AppRoutingModule {};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
  imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forRoot(routes, {
    preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_4__.PreloadAllModules
  })],
  exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
})], AppRoutingModule);


/***/ }),

/***/ 55041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component.html?ngResource */ 33383);
/* harmony import */ var _app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.scss?ngResource */ 79595);
/* harmony import */ var _app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _services_configuraciones__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./services/configuraciones */ 7717);





let AppComponent = class AppComponent {
  constructor(configuracionesService) {
    this.configuracionesService = configuracionesService;
  }
  ngOnInit() {
    this.configuracionesService.getURL();
  }
};
AppComponent.ctorParameters = () => [{
  type: _services_configuraciones__WEBPACK_IMPORTED_MODULE_2__.ConfiguracionesService
}];
AppComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
  selector: 'app-root',
  template: _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
  styles: [(_app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1___default())]
})], AppComponent);


/***/ }),

/***/ 36747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
var pdfmake_build_vfs_fonts__WEBPACK_IMPORTED_MODULE_3___namespace_cache;
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser */ 34497);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component */ 55041);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-routing.module */ 90158);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var pdfmake_wrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! pdfmake-wrapper */ 65473);
/* harmony import */ var pdfmake_build_vfs_fonts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! pdfmake/build/vfs_fonts */ 50786);










// set font to PDF
pdfmake_wrapper__WEBPACK_IMPORTED_MODULE_2__.PdfMakeWrapper.setFonts(/*#__PURE__*/ (pdfmake_build_vfs_fonts__WEBPACK_IMPORTED_MODULE_3___namespace_cache || (pdfmake_build_vfs_fonts__WEBPACK_IMPORTED_MODULE_3___namespace_cache = __webpack_require__.t(pdfmake_build_vfs_fonts__WEBPACK_IMPORTED_MODULE_3__, 2))));
let AppModule = class AppModule {};
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
  declarations: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent],
  imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__.BrowserModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule.forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_1__.AppRoutingModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_8__.HttpClientModule],
  providers: [{
    provide: _angular_router__WEBPACK_IMPORTED_MODULE_9__.RouteReuseStrategy,
    useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicRouteStrategy
  }],
  bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent]
})], AppModule);


/***/ }),

/***/ 49640:
/*!***********************************************!*\
  !*** ./src/app/guards/matriz-acceso.guard.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MatrizAccesoGuard": () => (/* binding */ MatrizAccesoGuard)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _services_usuarios_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../services/usuarios.service */ 81209);
/* harmony import */ var _services_alertas_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../services/alertas.service */ 34997);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 59151);






let MatrizAccesoGuard = class MatrizAccesoGuard {
  constructor(usuariosService, router, alertasService) {
    this.usuariosService = usuariosService;
    this.router = router;
    this.alertasService = alertasService;
    this.previousUrl = undefined;
    this.currentUrl = undefined;
    router.events.subscribe(event => {
      if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_2__.NavigationEnd) {
        this.previousUrl = this.currentUrl;
        this.currentUrl = event.url;
      }
      ;
    });
  }
  canActivate(route, state) {
    this.currentUrl = this.router.url;
    this.router.events.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.filter)(event => event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_2__.NavigationEnd)).subscribe(event => {
      let url = event.urlAfterRedirects;
      console.log(url);
      this.usuariosService.syncGetUsuarioMatrizAccesosToPromise(this.usuariosService.usuario.id).then(accesos => {
        console.log(this.currentUrl, 'current module');
        this.usuariosService.accesoModulos = [];
        this.usuariosService.accesoModulos = accesos;
        if (this.currentUrl == '/inicio-sesion' || this.currentUrl == '/inicio/detalle') return true;
        let indexControlAnticipos = accesos.findIndex(e => e.ruta == '/inicio/control-anticipos');
        if (indexControlAnticipos >= 0 && this.currentUrl == '/inicio/registro-anticipos' || indexControlAnticipos >= 0 && this.currentUrl == '/inicio/detalle-anticipo') {
          this.usuariosService.moduloAcceso = null;
          this.usuariosService.moduloAcceso = accesos[indexControlAnticipos];
          return true;
        }
        let index = accesos.findIndex(e => e.ruta == this.currentUrl);
        console.log('accesos', accesos);
        if (index >= 0) {
          this.usuariosService.moduloAcceso = null;
          this.usuariosService.moduloAcceso = accesos[index];
          //this.alertasService.message('Ruta Encontrada',url)
          //  this.router.navigateByUrl(this.previousUrl)
          return true;
        } else {
          this.alertasService.message('Dione', `Acceso denegado - contacte al administrador para el  acceso al modulo.`);
          this.router.navigateByUrl(this.previousUrl);
        }
      }, error => {
        this.alertasService.message('DiOne', 'Error cargando permisos');
      });
      // this.alertasService.message('Allowed URL',this.currentUrl)
      return true;
    });
    return true;
  }
};
MatrizAccesoGuard.ctorParameters = () => [{
  type: _services_usuarios_service__WEBPACK_IMPORTED_MODULE_0__.UsuariosService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router
}, {
  type: _services_alertas_service__WEBPACK_IMPORTED_MODULE_1__.AlertasService
}];
MatrizAccesoGuard = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
  providedIn: 'root'
})], MatrizAccesoGuard);


/***/ }),

/***/ 69170:
/*!*****************************************************!*\
  !*** ./src/app/guards/usuario-autenticado.guard.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UsuarioAutenticadoGuard": () => (/* binding */ UsuarioAutenticadoGuard)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _services_usuarios_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../services/usuarios.service */ 81209);
/* harmony import */ var _services_alertas_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../services/alertas.service */ 34997);





let UsuarioAutenticadoGuard = class UsuarioAutenticadoGuard {
  constructor(usuariosService, router, alertasService) {
    this.usuariosService = usuariosService;
    this.router = router;
    this.alertasService = alertasService;
  }
  canLoad(route, segments) {
    if (this.usuariosService.usuario) {
      return true;
    } else {
      this.alertasService.message('DiOne', 'Inicia sesión para continuar');
      return this.router.createUrlTree(['/inicio-sesion']);
    }
  }
};
UsuarioAutenticadoGuard.ctorParameters = () => [{
  type: _services_usuarios_service__WEBPACK_IMPORTED_MODULE_0__.UsuariosService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router
}, {
  type: _services_alertas_service__WEBPACK_IMPORTED_MODULE_1__.AlertasService
}];
UsuarioAutenticadoGuard = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)({
  providedIn: 'root'
})], UsuarioAutenticadoGuard);


/***/ }),

/***/ 34997:
/*!*********************************************!*\
  !*** ./src/app/services/alertas.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertasService": () => (/* binding */ AlertasService)
/* harmony export */ });
/* harmony import */ var C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 93819);




let AlertasService = class AlertasService {
  constructor(loadingCtrl, alertCtrl, modalCtrl) {
    this.loadingCtrl = loadingCtrl;
    this.alertCtrl = alertCtrl;
    this.modalCtrl = modalCtrl;
    this.isLoading = false;
    this.elementos = [];
  }
  dismissAllLoaders() {
    var _this = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let topLoader = yield _this.loadingCtrl.getTop();
      while (topLoader) {
        if (!(yield topLoader.dismiss())) {
          throw new Error('Could not dismiss the topmost loader. Aborting...');
        }
        topLoader = yield _this.loadingCtrl.getTop();
      }
    })();
  }
  presentaLoading(message) {
    var _this2 = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.isLoading = true;
      yield _this2.loadingCtrl.create({
        message: message ? message : 'Please wait...'
      }).then(loader => {
        loader.present().then(() => {
          if (!_this2.isLoading) {
            loader.dismiss();
          }
        });
      });
    })();
  }
  loadingDissmiss() {
    var _this3 = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this3.isLoading = false;
      let topLoader = yield _this3.loadingCtrl.getTop();
      while (topLoader) {
        if (!(yield topLoader.dismiss())) {
          //   throw new Error('Could not dismiss the topmost loader. Aborting...');
        }
        topLoader = yield _this3.loadingCtrl.getTop();
      }
    })();
  }
  message(header, message) {
    var _this4 = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this4.alertCtrl.create({
        cssClass: 'alert-popup',
        header: header,
        message: message,
        buttons: ['OK']
      });
      yield alert.present();
    })();
  }
};
AlertasService.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.LoadingController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.AlertController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ModalController
}];
AlertasService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], AlertasService);


/***/ }),

/***/ 7717:
/*!*********************************************!*\
  !*** ./src/app/services/configuraciones.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConfiguracionesService": () => (/* binding */ ConfiguracionesService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 92340);




let ConfiguracionesService = class ConfiguracionesService {
  constructor(loadingCtrl, alertCtrl, modalCtrl) {
    this.loadingCtrl = loadingCtrl;
    this.alertCtrl = alertCtrl;
    this.modalCtrl = modalCtrl;
    this.menu = false;
    this.isLoading = false;
    this.elementos = [];
    this.chartHeight = '0px';
    this.title = "";
  }
  getURL() {
    let test = '';
    if (!_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.prdMode) {
      test = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.TestURL;
      this.isPRD = false;
    } else {
      this.isPRD = true;
    }
    this.url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.preURL + test + _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postURL;
    console.log('URL', this.url, 'isPRD', this.isPRD);
  }
};
ConfiguracionesService.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.LoadingController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.AlertController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ModalController
}];
ConfiguracionesService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], ConfiguracionesService);


/***/ }),

/***/ 81209:
/*!**********************************************!*\
  !*** ./src/app/services/usuarios.service.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UsuariosService": () => (/* binding */ UsuariosService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 92340);




let UsuariosService = class UsuariosService {
  constructor(http) {
    this.http = http;
    this.usuario = null;
    this.usuarios = [];
    this.accesoModulos = [];
    this.moduloAcceso = {
      id: null,
      iD_USUARIO: null,
      estatus: null,
      aprobador: null,
      c: null,
      r: null,
      u: null,
      d: null,
      iD_MODULO: null,
      nombre: null,
      ruta: null
    };
  }
  getAPI(api) {
    let test = '';
    if (!_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.prdMode) test = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.TestURL;
    const URL = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.preURL + test + _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postURL + api;
    return URL;
  }
  getUsuarioID(id) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getUsuarioID);
    URL = URL + id;
    console.log(URL);
    return this.http.get(URL);
  }
  getUsuarios() {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getUsuarios);
    return this.http.get(URL);
  }
  getUsuariosExactus() {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getusuariosExactus);
    return this.http.get(URL);
  }
  getUsuarioMatrizAccesos(id) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getMatrizAccesoUsuario);
    URL = URL + id;
    console.log(URL);
    return this.http.get(URL);
  }
  postUsuario(usuario) {
    const URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postUsuario);
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control': '*'
      }
    };
    return this.http.post(URL, usuario, options);
  }
  putUsuario(usuario) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.putUsuario);
    URL = URL + usuario.id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    };
    console.log(URL);
    console.log(usuario);
    return this.http.put(URL, usuario, options);
  }
  deleteUsuario(id) {
    let URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.deleteUsuario);
    URL = URL + id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    };
    return this.http.delete(URL, options);
  }
  getUsuarioIdToPtomise(id) {
    return this.getUsuarioID(id).toPromise();
  }
  syncGetUsuariosToPromise() {
    return this.getUsuarios().toPromise();
  }
  syncGetUsuariosExactusToPromise() {
    return this.getUsuariosExactus().toPromise();
  }
  syncPostUsuarioToPromise(usuario) {
    return this.postUsuario(usuario).toPromise();
  }
  syncPutUsuarioToPromise(usuario) {
    return this.putUsuario(usuario).toPromise();
  }
  syncGetUsuarioMatrizAccesosToPromise(id) {
    return this.getUsuarioMatrizAccesos(id).toPromise();
  }
  syncDeleteUsuarioToPromise(id) {
    return this.deleteUsuario(id).toPromise();
  }
};
UsuariosService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
}];
UsuariosService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], UsuariosService);


/***/ }),

/***/ 92340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
  production: true,
  maxCharCodigoProd: 6,
  preURL: 'https://isa-app.dev/apis/development/',
  TestURL: '_test',
  preURL2: 'https://api_isa',
  postURL: 'control-viaticos/api/',
  prdMode: true,
  // APIS
  // GASTOS
  getGastos: 'get/gastos/estado/rango/fecha?estado=',
  getGastosAnticipo: 'get/gastos/anticipo?id=',
  getGastosAnticipoLineas: 'get/gastos/linea-anticipo?id=',
  putGastos: 'put/gasto/linea-anticipo?id=',
  getFacturaGastos: 'get/gasto?id=',
  getUsuarioGastos: 'get/gastos/usuario?id=',
  getUsuarioGastosRangoFecha: 'get/usuario/gastos/estado/rango/fecha?id=',
  // ADELANTO VIATICOS
  getAdelantoViaticos: 'get/anticipos',
  postAdelantoViaticos: 'post/anticipo',
  putAdelantoViaticos: 'put/anticipo?id=',
  // LINEA ANTICIPOS
  postLineaAnticipos: 'post/linea/anticipo',
  putLineaAnticipos: 'put/linea/anticipo?id=',
  getLineasAnticipos: 'get/linea/web/anticipo?id=',
  // ESTADOS CUENTA
  getEstadosCuenta: 'get/estados/cuenta',
  postEstadosCuenta: 'post/estados/cuenta',
  // ARCHIVOS
  getArchivoEstadosCuenta: 'get/estados/cuenta/archivo/?ID=',
  postArchivoEstadosCuenta: 'post/estados/cuenta/archivo/?ID=',
  // EMAIL
  postEmail: 'post/enviar/correo',
  // MOV DIR
  getMovDir: 'get/movdir',
  postMovDir: 'post/movdir',
  // ASIENTO DIARIO
  getAsientoDiario: 'get/asiento-diario',
  postAsientoDiario: 'post/asiento-diario',
  //  DIARIO
  getDiario: 'get/diario',
  postDiario: 'post/diario',
  getusuariosExactus: 'get/usuarios/exactus',
  getGastosAnticipos: 'get/gastos/anticipo?id=',
  // USUARIOS
  getUsuarios: 'get/usuarios',
  getUsuarioID: 'get/usuario?correo=',
  postUsuario: 'post/usuario',
  putUsuario: 'put/usuario?id=',
  deleteUsuario: 'delete/usuario?id=',
  // COMPANIAS
  getCompanias: 'get/companias',
  // MODULOS
  getModulos: 'get/modulos',
  // DEPARTAMENTOS
  getDepartamentos: 'get/departamentos',
  postDepartamento: 'post/departamento',
  putDepartamento: 'put/departamento?id=',
  deleteDepartamento: 'delete/departamento?id=',
  // ROLES
  getRoles: 'get/roles',
  postRole: 'post/role',
  putRole: 'put/role?id=',
  deleteRole: 'delete/role?id=',
  // MATRIZ ACCESO
  getMatrizAccesobyIDURL: 'get/matriz-acceso?id=',
  getMatrizAcceso: 'get/matriz-accesos',
  getMatrizAccesoUsuario: 'get/matriz-acceso/usuario?id=',
  getMatrizAccesoBYID: 'get/matriz-acceso?id=',
  getMatrizAccesoCheckModuloUsuario: 'get/matriz-acceso/usuario?id=',
  getUsuariosMstrizAcceso: 'get/usuarios/matriz-acceso?id=',
  postMatrizAcceo: 'post/matriz-acceso',
  postUsuarioMatrizAcceo: 'post/usuario/matriz-acceso',
  putMatrizAcceso: 'put/matriz-acceso?id=',
  deleteMatrizAcceso: 'delete/matriz-acceso?id=',
  deleteUsuarioMatrizAcceso: 'delete/usuario/matriz-accesos?id=',
  // MODULOS 
  getMatrizAccesoModulosURL: 'get/matriz-acceso/modulos?id=',
  postModuloMatrizAcceo: 'post/matriz-acceso/modulo',
  putModuloMatrizAcceo: 'post/matriz-acceso/modulo?id=',
  deleteModuloMatrizAcceso: 'delete/matriz-acceso/modulos?id=',
  ONE_LinGastoURL: 'put/gasto/linea-anticipo?id=',
  // USUARIO MATRIZ ACCESO
  getUsuarioMatrizAccesoURL: 'get/usuario/matriz-acceso?id=',
  TipGastosURL: 'get/tipos/gastos'
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.

/***/ }),

/***/ 14431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 76057);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 36747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 92340);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
  (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule).catch(err => console.log(err));

/***/ }),

/***/ 50863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-accordion_2.entry.js": [
		70079,
		"common",
		"node_modules_ionic_core_dist_esm_ion-accordion_2_entry_js"
	],
	"./ion-action-sheet.entry.js": [
		25593,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		13225,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		4812,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		86655,
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		44856,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		13059,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-breadcrumb_2.entry.js": [
		58648,
		"common",
		"node_modules_ionic_core_dist_esm_ion-breadcrumb_2_entry_js"
	],
	"./ion-button_2.entry.js": [
		98308,
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		44690,
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		64090,
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		36214,
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		69447,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime-button.entry.js": [
		17950,
		"default-node_modules_ionic_core_dist_esm_data-cb72448c_js-node_modules_ionic_core_dist_esm_th-29e28e",
		"node_modules_ionic_core_dist_esm_ion-datetime-button_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		79689,
		"default-node_modules_ionic_core_dist_esm_data-cb72448c_js-node_modules_ionic_core_dist_esm_th-29e28e",
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		18840,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		40749,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		69667,
		"common",
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		83288,
		"common",
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		35473,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		53634,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		22855,
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		495,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		58737,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		99632,
		"common",
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-picker-column-internal.entry.js": [
		54446,
		"common",
		"node_modules_ionic_core_dist_esm_ion-picker-column-internal_entry_js"
	],
	"./ion-picker-internal.entry.js": [
		32275,
		"node_modules_ionic_core_dist_esm_ion-picker-internal_entry_js"
	],
	"./ion-popover.entry.js": [
		48050,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		18994,
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		23592,
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		35454,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		290,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		92666,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		64816,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		45534,
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		94902,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		91938,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		78179,
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		90668,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		61624,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		19989,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		28902,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		70199,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		48395,
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		96357,
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		38268,
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		15269,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		32875,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 50863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 79595:
/*!***********************************************!*\
  !*** ./src/app/app.component.scss?ngResource ***!
  \***********************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 49579);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ 60931);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 33383:
/*!***********************************************!*\
  !*** ./src/app/app.component.html?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-app>\r\n  <ion-router-outlet></ion-router-outlet>\r\n</ion-app>\r\n";

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(14431)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map