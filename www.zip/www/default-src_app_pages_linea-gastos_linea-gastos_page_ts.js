(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_pages_linea-gastos_linea-gastos_page_ts"],{

/***/ 7935:
/*!*********************************************************!*\
  !*** ./src/app/pages/linea-gastos/linea-gastos.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LineaGastosPage": () => (/* binding */ LineaGastosPage)
/* harmony export */ });
/* harmony import */ var C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _linea_gastos_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./linea-gastos.page.html?ngResource */ 48947);
/* harmony import */ var _linea_gastos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./linea-gastos.page.scss?ngResource */ 68028);
/* harmony import */ var _linea_gastos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_linea_gastos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_services_adelanto_viaticos_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/adelanto-viaticos.service */ 45406);
/* harmony import */ var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/alertas.service */ 34997);
/* harmony import */ var src_app_services_gastos_anticipos_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/gastos-anticipos.service */ 45486);
/* harmony import */ var src_app_services_lineas_anticipos_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/lineas-anticipos.service */ 37568);
/* harmony import */ var _cierre_contable_linea_anticipo_cierre_contable_linea_anticipo_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../cierre-contable-linea-anticipo/cierre-contable-linea-anticipo.page */ 37472);











let LineaGastosPage = class LineaGastosPage {
  constructor(modalCtrl, adelantosService, lineasAnticiposService, alertasService, gastosAnticiposService) {
    this.modalCtrl = modalCtrl;
    this.adelantosService = adelantosService;
    this.lineasAnticiposService = lineasAnticiposService;
    this.alertasService = alertasService;
    this.gastosAnticiposService = gastosAnticiposService;
    this.gastos = [];
    this.observaciones = null;
    this.isOpen = false;
    this.url = "https://sde1.sderp.site/api-coris-control-viaticos/api/descargar-archivo?id=";
  }
  ngOnInit() {
    console.log(this.linea);
    this.lineasAnticiposService.syncGetGastosLineasToPromise(this.linea.id).then(resp => {
      this.gastos = resp;
      console.log(this.gastos);
    });
  }
  cerrarModal() {
    this.modalCtrl.dismiss();
  }
  aprobar(linea) {
    var _this = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      linea.estatus = 'A';
      yield _this.gastosAnticiposService.syncPutGastoToPromise(linea);
      _this.alertasService.message('SD1', 'Linea Actualizada');
      _this.actualizar();
    })();
  }
  rechazar(linea) {
    var _this2 = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      linea.estatus = 'R';
      yield _this2.gastosAnticiposService.syncPutGastoToPromise(linea);
      _this2.alertasService.message('SD1', 'Linea Actualizada');
      _this2.actualizar();
    })();
  }
  actualizar() {
    let count = this.gastos.length;
    let filter = 0;
    this.gastos.forEach((gasto, index) => {
      if (gasto.estatus == 'A') filter += 1;
      if (gasto.estatus == 'R') this.linea.estatus = "R";
      if (index == this.gastos.length - 1) {
        if (count == filter) {
          this.linea.estatus = "A";
        } else if (this.linea.estatus != 'R') {
          this.linea.estatus = "I";
        }
        this.lineasAnticiposService.syncPutLineaAnticipoToPromise(this.linea).then(resp => {
          if (resp.estatus == 'A') {
            console.log(resp);
          }
        });
      }
    });
  }
  cierreContableLineaAnticipo() {
    var _this3 = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this3.isOpen = true;
      const modal = yield _this3.modalCtrl.create({
        component: _cierre_contable_linea_anticipo_cierre_contable_linea_anticipo_page__WEBPACK_IMPORTED_MODULE_7__.CierreContableLineaAnticipoPage,
        cssClass: 'alert-modal',
        componentProps: {
          linea: _this3.linea,
          gastos: _this3.gastos
        }
      });
      if (_this3.isOpen) {
        modal.present();
        const {
          data
        } = yield modal.onWillDismiss();
        _this3.isOpen = false;
        if (data != undefined) {}
      }
    })();
  }
};
LineaGastosPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController
}, {
  type: src_app_services_adelanto_viaticos_service__WEBPACK_IMPORTED_MODULE_3__.AdelantoViaticosService
}, {
  type: src_app_services_lineas_anticipos_service__WEBPACK_IMPORTED_MODULE_6__.LineasAnticiposService
}, {
  type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_4__.AlertasService
}, {
  type: src_app_services_gastos_anticipos_service__WEBPACK_IMPORTED_MODULE_5__.GastosAnticiposService
}];
LineaGastosPage.propDecorators = {
  linea: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Input
  }]
};
LineaGastosPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-linea-gastos',
  template: _linea_gastos_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_linea_gastos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], LineaGastosPage);


/***/ }),

/***/ 45486:
/*!******************************************************!*\
  !*** ./src/app/services/gastos-anticipos.service.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GastosAnticiposService": () => (/* binding */ GastosAnticiposService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let GastosAnticiposService = class GastosAnticiposService {
  constructor(http) {
    this.http = http;
  }
  getIRPURL(api, id) {
    let test = '';
    if (!src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.prdMode) {
      test = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.TestURL;
    }
    const URL = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.preURL + test + src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postURL + api + id;
    console.log(URL);
    return URL;
  }
  putGasto(lineasGasto) {
    let URL = this.getIRPURL(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.ONE_LinGastoURL, ``);
    URL = URL + lineasGasto.id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    };
    console.log(JSON.stringify(lineasGasto));
    return this.http.put(URL, JSON.stringify(lineasGasto), options);
  }
  syncPutGastoToPromise(gasto) {
    return this.putGasto(gasto).toPromise();
  }
};
GastosAnticiposService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
}];
GastosAnticiposService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], GastosAnticiposService);


/***/ }),

/***/ 37568:
/*!******************************************************!*\
  !*** ./src/app/services/lineas-anticipos.service.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LineasAnticiposService": () => (/* binding */ LineasAnticiposService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let LineasAnticiposService = class LineasAnticiposService {
  constructor(http) {
    this.http = http;
  }
  getAPI(api) {
    let test = "";
    if (!src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.prdMode) test = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.TestURL;
    const URL = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.preURL + test + src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postURL + api;
    return URL;
  }
  getGastosLineas(id) {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getGastosAnticipoLineas);
    URL = URL + id;
    console.log('URL', URL);
    return this.http.get(URL);
  }
  getLineasAnticipos(id) {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getLineasAnticipos);
    URL = URL + id;
    console.log('URL', URL);
    return this.http.get(URL);
  }
  getLineasAnticiposLineas(id) {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getGastosAnticipoLineas);
    URL = URL + id;
    console.log('URL', URL);
    return this.http.get(URL);
  }
  postLineaAnticipo(lineaAnticipo) {
    const URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postLineaAnticipos);
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Origin': '*'
      }
    };
    console.log('URL', URL);
    console.log('lineaAnticipo', lineaAnticipo);
    return this.http.post(URL, lineaAnticipo, options);
  }
  putLineaAnticipo(lineaAnticipo) {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.putLineaAnticipos);
    URL = URL + lineaAnticipo.id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Origin': '*'
      }
    };
    console.log('URL', URL);
    console.log('lineaAnticipo', lineaAnticipo);
    return this.http.put(URL, lineaAnticipo, options);
  }
  syncGetLineasAnriciposToPromise(id) {
    return this.getLineasAnticipos(id).toPromise();
  }
  syncGetLineasAnticiposLineasToPromise(id) {
    return this.getLineasAnticiposLineas(id).toPromise();
  }
  syncGetGastosLineasToPromise(id) {
    return this.getGastosLineas(id).toPromise();
  }
  syncPutLineaAnticipoToPromise(lineaAnticipo) {
    return this.putLineaAnticipo(lineaAnticipo).toPromise();
  }
  syncPostLineaAnticipoToPromise(lineaAnticipo) {
    return this.postLineaAnticipo(lineaAnticipo).toPromise();
  }
};
LineasAnticiposService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
}];
LineasAnticiposService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], LineasAnticiposService);


/***/ }),

/***/ 68028:
/*!**********************************************************************!*\
  !*** ./src/app/pages/linea-gastos/linea-gastos.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 49579);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60931);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "ion-input {\n  border-radius: 10px;\n  border: solid 1px rgb(218, 218, 218);\n  height: 2.5rem;\n}\n\nion-label {\n  font-weight: 500;\n}\n\n.description {\n  height: 4rem;\n}\n\n.has-focus {\n  border: 2px solid #5b9bd1 !important;\n}", "",{"version":3,"sources":["webpack://./src/app/pages/linea-gastos/linea-gastos.page.scss","webpack://./../../Simple%20Design%20Experience/Control%20Viaticos/src/app/pages/linea-gastos/linea-gastos.page.scss"],"names":[],"mappings":"AACA;EACI,mBAAA;EACA,oCAAA;EACA,cAAA;ACAJ;;ADEA;EACI,gBAAA;ACCJ;;ADCA;EACI,YAAA;ACEJ;;ADAA;EACI,oCAAA;ACGJ","sourcesContent":["\r\nion-input {\r\n    border-radius: 10px;\r\n    border: solid 1px rgba(218,218,218,1);\r\n    height: 2.5rem;\r\n}\r\nion-label{\r\n    font-weight: 500;\r\n}\r\n.description{\r\n    height: 4rem;\r\n}\r\n.has-focus{\r\n    border: 2px solid #5b9bd1 !important;\r\n}\r\n ","ion-input {\n  border-radius: 10px;\n  border: solid 1px rgb(218, 218, 218);\n  height: 2.5rem;\n}\n\nion-label {\n  font-weight: 500;\n}\n\n.description {\n  height: 4rem;\n}\n\n.has-focus {\n  border: 2px solid #5b9bd1 !important;\n}"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 48947:
/*!**********************************************************************!*\
  !*** ./src/app/pages/linea-gastos/linea-gastos.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header class=\"ion-no-border ion-padding\">\n  <ion-toolbar>\n    <ion-button (click)=\"cerrarModal()\"   fill=\"clear\"  slot=\"start\">\n     <ion-icon slot=\"icon-only\" name=\"arrow-back\"></ion-icon>\n    </ion-button>\n    <ion-title>{{linea.usuario}}  - Estado   <ion-badge color=\"primary\" mode=\"ios\">{{linea.estatus == 'P' ?  'Pendiente' :  linea.estatus == 'A' ? 'Aprobada' : linea.estatus == 'I' ? 'Requiere Aprobacion' : 'Rechazada'}}</ion-badge></ion-title>\n\n\n  </ion-toolbar>\n\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <ion-grid >\n    <ion-row>\n      <ion-col size=\"12\">\n    <ion-item>\n      <ion-label><strong>Monto Dispensado</strong> </ion-label>\n      <ion-label slot=\"end\"> {{linea.monto | colones}}</ion-label>\n    </ion-item>\n      </ion-col>\n      <ion-col size=\"12\">\n      \n   <ion-item>\n    <ion-label><strong>Monto Utilizado</strong> </ion-label>\n    <ion-label slot=\"end\">{{linea.utilizado | colones}}</ion-label>\n   </ion-item>\n      </ion-col>\n  \n      <ion-col size=\"12\">\n      \n <ion-item>\n  <ion-label><strong>Monto Sobrante</strong></ion-label>\n  <ion-label slot=\"end\">{{linea.restante | colones}}</ion-label>\n </ion-item>\n <ion-item>\n  <ion-label><strong>Metodo Devolución</strong></ion-label> \n  <ion-label slot=\"end\"><strong>{{linea.metodO_DEVOLUCION }}</strong></ion-label>\n\n </ion-item>\n    </ion-col>\n    </ion-row>\n   </ion-grid>\n\n  <ion-list>\n\n    <ion-accordion-group>\n      <ion-accordion  *ngFor=\"let item of gastos; let i = index;\" >\n        <ion-item slot=\"header\" color=\"light\">\n          <ion-grid  >\n            <ion-row>\n              <ion-col size=\"12\"  style=\"display: flex;justify-content: space-between;align-items: center;\">\n                <ion-label class=\"ion-text-capitalize\">{{item.proveedor}}</ion-label>  \n       \n                <a *ngIf=\"item.adjunto\" target=\"_blank\"   href=\"{{url+item.id}}\"  download> \n                  <ion-fab-button   size=\"small\" >\n                \n                    <ion-icon name=\"cloud-download-outline\">\n                 \n            \n                    </ion-icon>\n               \n                  </ion-fab-button>\n                \n                </a>\n\n                <ion-badge color=\"warning\" mode=\"ios\">{{item.estatus == 'P' ?  'Pendiente' :  item.estatus == 'A' ? 'Aprobada' : item.estatus == 'I' ? 'Requiere Aprobacion' : 'Rechazada'}}\n                </ion-badge>\n              </ion-col>\n              <ion-col size=\"12\" style=\"display: flex;justify-content: space-between;align-items: center;\">\n      \n                <ion-label>M# {{item.referencia}}</ion-label>\n                <ion-label><strong> -{{item.monto | colones}}</strong></ion-label>\n              </ion-col>\n       \n              <ion-col size=\"12\">\n           <ion-label>{{item.fecha | date }}</ion-label>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </ion-item>\n        <div class=\"ion-padding\" slot=\"content\">\n          <ion-grid >\n            <ion-row>\n       \n            <ion-col size=\"12\">\n              <ion-toolbar>\n                <ion-title>Observaciones</ion-title>\n                <ion-fab-button *ngIf=\"item.estatus !='A'\"   (click)=\"aprobar(item)\" slot=\"end\" size=\"small\" color=\"success\">\n                  <ion-icon name=\"checkmark\"></ion-icon>\n                </ion-fab-button>\n                <ion-fab-button  *ngIf=\"item.estatus !='A'\"     (click)=\"rechazar(item)\"  slot=\"end\" size=\"small\" color=\"danger\">\n                  <ion-icon name=\"close\"></ion-icon>\n                </ion-fab-button>\n              </ion-toolbar>\n            </ion-col>\n            <ion-col size=\"12\">\n              <ion-input  [(ngModel)]=\"item.observaciones\" name=\"observaciones\"  class=\"description\" type=\"text\" placeholder=\"Observaciones\"></ion-input>\n            </ion-col>\n            </ion-row>\n          </ion-grid>\n           \n        </div>\n      </ion-accordion>\n \n     \n    </ion-accordion-group>\n\n\n\n    \n\n\n  </ion-list>\n</ion-content>\n\n<ion-footer   *ngIf=\"linea.estatus == 'A'\"   (click)=\"cierreContableLineaAnticipo()\" class=\"ion-no-border ion-padding\">\n  <ion-toolbar>\n    <ion-button  expand=\"block\" fill=\"solid\" color=\"dark\">\n  Cierre Contable Linea Anticipo\n      </ion-button>\n  </ion-toolbar>\n </ion-footer>";

/***/ })

}]);
//# sourceMappingURL=default-src_app_pages_linea-gastos_linea-gastos_page_ts.js.map