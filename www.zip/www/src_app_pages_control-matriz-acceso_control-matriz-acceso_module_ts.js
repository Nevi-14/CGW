(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_control-matriz-acceso_control-matriz-acceso_module_ts"],{

/***/ 45458:
/*!*************************************************************************************!*\
  !*** ./src/app/pages/control-matriz-acceso/control-matriz-acceso-routing.module.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ControlMatrizAccesoPageRoutingModule": () => (/* binding */ ControlMatrizAccesoPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _control_matriz_acceso_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./control-matriz-acceso.page */ 32699);




const routes = [{
  path: '',
  component: _control_matriz_acceso_page__WEBPACK_IMPORTED_MODULE_0__.ControlMatrizAccesoPage
}];
let ControlMatrizAccesoPageRoutingModule = class ControlMatrizAccesoPageRoutingModule {};
ControlMatrizAccesoPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
  imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
  exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
})], ControlMatrizAccesoPageRoutingModule);


/***/ }),

/***/ 82964:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/control-matriz-acceso/control-matriz-acceso.module.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ControlMatrizAccesoPageModule": () => (/* binding */ ControlMatrizAccesoPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _control_matriz_acceso_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./control-matriz-acceso-routing.module */ 45458);
/* harmony import */ var _control_matriz_acceso_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./control-matriz-acceso.page */ 32699);
/* harmony import */ var src_app_components_component_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/component.module */ 78443);








let ControlMatrizAccesoPageModule = class ControlMatrizAccesoPageModule {};
ControlMatrizAccesoPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule, _control_matriz_acceso_routing_module__WEBPACK_IMPORTED_MODULE_0__.ControlMatrizAccesoPageRoutingModule, src_app_components_component_module__WEBPACK_IMPORTED_MODULE_2__.ComponentModule],
  declarations: [_control_matriz_acceso_page__WEBPACK_IMPORTED_MODULE_1__.ControlMatrizAccesoPage]
})], ControlMatrizAccesoPageModule);


/***/ }),

/***/ 32699:
/*!***************************************************************************!*\
  !*** ./src/app/pages/control-matriz-acceso/control-matriz-acceso.page.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ControlMatrizAccesoPage": () => (/* binding */ ControlMatrizAccesoPage)
/* harmony export */ });
/* harmony import */ var C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _control_matriz_acceso_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./control-matriz-acceso.page.html?ngResource */ 88690);
/* harmony import */ var _control_matriz_acceso_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./control-matriz-acceso.page.scss?ngResource */ 75892);
/* harmony import */ var _control_matriz_acceso_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_control_matriz_acceso_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _crear_matriz_acceso_crear_matriz_acceso_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../crear-matriz-acceso/crear-matriz-acceso.page */ 18288);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/alertas.service */ 34997);
/* harmony import */ var src_app_services_matriz_acceso_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/matriz-acceso.service */ 75444);
/* harmony import */ var _editar_matriz_acceso_editar_matriz_acceso_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../editar-matriz-acceso/editar-matriz-acceso.page */ 69989);
/* harmony import */ var src_app_services_modulos_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/modulos.service */ 23191);
/* harmony import */ var src_app_services_companias_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/companias.service */ 65667);
/* harmony import */ var src_app_services_departamentos_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/services/departamentos.service */ 66646);
/* harmony import */ var src_app_services_usuarios_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/services/usuarios.service */ 81209);
/* harmony import */ var src_app_services_modulos_matriz_acceso_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/services/modulos-matriz-acceso.service */ 78423);















let ControlMatrizAccesoPage = class ControlMatrizAccesoPage {
  constructor(modalCtrl, alertasService, matrizAccesoService, modulosService, companiaService, departamentosService, alertCrl, usuariosService, modulosMatrizAccesoService) {
    this.modalCtrl = modalCtrl;
    this.alertasService = alertasService;
    this.matrizAccesoService = matrizAccesoService;
    this.modulosService = modulosService;
    this.companiaService = companiaService;
    this.departamentosService = departamentosService;
    this.alertCrl = alertCrl;
    this.usuariosService = usuariosService;
    this.modulosMatrizAccesoService = modulosMatrizAccesoService;
    this.isOpen = false;
  }
  ngOnInit() {
    console.log(this.usuariosService.moduloAcceso, 'accesos');
    this.alertasService.presentaLoading('Cargando datos...');
    this.matrizAccesoService.syncGetMatrizAccesotoToPromise().then(accesos => {
      //
      this.matrizAccesoService.matrizAcceso = accesos;
      //   this.alertasService.presentaLoading('Cargando datos..');
      this.modulosService.syncGetModulosToPromise().then(modulos => {
        this.modulosService.modulos = modulos;
        this.companiaService.syncGetCompaniasToPromise().then(companias => {
          this.companiaService.companias = companias;
          this.departamentosService.syncGetDepartamentoToPromise().then(departamentos => {
            this.departamentosService.departamentos = departamentos;
            this.alertasService.loadingDissmiss();
            console.log('modulos', this.modulosService.modulos);
            console.log('companias', this.companiaService.companias);
            console.log('departamentos', this.departamentosService.departamentos);
          }, error => {
            this.alertasService.loadingDissmiss();
            this.alertasService.message('Dione', 'Lo sentimos algo salio mal..');
          });
        }, error => {
          this.alertasService.loadingDissmiss();
          this.alertasService.message('Dione', 'Lo sentimos algo salio mal..');
        });
      }, error => {
        this.alertasService.loadingDissmiss();
        this.alertasService.message('Dione', 'Lo sentimos algo salio mal..');
      });
    }, error => {
      this.alertasService.loadingDissmiss();
      this.alertasService.message('Dione', 'Lo sentimos algo salio mal!..');
    });
  }
  crearMatrizAcceso() {
    var _this = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.isOpen = true;
      const modal = yield _this.modalCtrl.create({
        component: _crear_matriz_acceso_crear_matriz_acceso_page__WEBPACK_IMPORTED_MODULE_3__.CrearMatrizAccesoPage,
        cssClass: 'alert-modal'
      });
      if (_this.isOpen) {
        modal.present();
        const {
          data
        } = yield modal.onWillDismiss();
        _this.isOpen = false;
        if (data != undefined) {
          _this.matrizAccesoService.syncGetMatrizAccesotoToPromise().then(accesos => {
            //
            _this.matrizAccesoService.matrizAcceso = accesos;
          }, error => {
            console.log(error);
          });
        }
      }
    })();
  }
  EditarMatrizAcceso(acceso1) {
    var _this2 = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log(acceso1, '1');
      let acceso = yield _this2.matrizAccesoService.syncGetMatrizAccesoIDtoToPromise(acceso1.iD_MATRIZ_ACCESO);
      let modulosArray = yield _this2.modulosMatrizAccesoService.syncGetModulosMatrizAccesoByIDtoToPromise(acceso1.iD_MATRIZ_ACCESO);
      let modulos = [];
      if (modulosArray.length == 0) {
        _this2.editarMatriz(modulos, acceso[0]);
      }
      modulosArray.forEach( /*#__PURE__*/function () {
        var _ref = (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (modulo, index) {
          modulos.push(modulo.iD_MODULO);
          if (index == modulosArray.length - 1) {
            console.log(modulosArray);
            console.log(acceso, 'to edit');
            _this2.editarMatriz(modulos, acceso[0]);
          }
        });
        return function (_x, _x2) {
          return _ref.apply(this, arguments);
        };
      }());
    })();
  }
  editarMatriz(modulos, acceso) {
    var _this3 = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this3.isOpen = true;
      const modal = yield _this3.modalCtrl.create({
        component: _editar_matriz_acceso_editar_matriz_acceso_page__WEBPACK_IMPORTED_MODULE_6__.EditarMatrizAccesoPage,
        cssClass: 'alert-modal',
        componentProps: {
          acceso,
          modulos
        }
      });
      if (_this3.isOpen) {
        modal.present();
        const {
          data
        } = yield modal.onWillDismiss();
        _this3.isOpen = false;
        if (data != undefined) {}
      }
    })();
  }
  borrarMatrizAcceso(acceso1) {
    var _this4 = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this4.alertCrl.create({
        subHeader: 'Dione',
        message: `¿Desea borrar el acceso # ${acceso1.nombre}?`,
        buttons: [{
          text: 'cancelar',
          role: 'cancel',
          handler: () => {
            console.log('cancel');
          }
        }, {
          text: 'continuar',
          role: 'confirm',
          handler: function () {
            var _ref2 = (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
              _this4.alertasService.presentaLoading('Borrando datos..');
              _this4.matrizAccesoService.syncDeleteMatrizAccesoToPromise(acceso1.iD_MATRIZ_ACCESO).then(resp => {
                _this4.alertasService.loadingDissmiss();
                _this4.matrizAccesoService.syncGetMatrizAccesotoToPromise().then(accesos => {
                  _this4.matrizAccesoService.matrizAcceso = accesos;
                }, error => {
                  _this4.alertasService.loadingDissmiss();
                  _this4.alertasService.message('Dione', 'Lo sentimos algo salio mal...');
                });
              }, error => {
                _this4.alertasService.loadingDissmiss();
                _this4.alertasService.message('Dione', 'Lo sentimos algo salio mal...');
              });
            });
            return function handler() {
              return _ref2.apply(this, arguments);
            };
          }()
        }]
      });
      alert.present();
    })();
  }
};
ControlMatrizAccesoPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.ModalController
}, {
  type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_4__.AlertasService
}, {
  type: src_app_services_matriz_acceso_service__WEBPACK_IMPORTED_MODULE_5__.MatrizAccesoService
}, {
  type: src_app_services_modulos_service__WEBPACK_IMPORTED_MODULE_7__.ModulosService
}, {
  type: src_app_services_companias_service__WEBPACK_IMPORTED_MODULE_8__.CompaniasService
}, {
  type: src_app_services_departamentos_service__WEBPACK_IMPORTED_MODULE_9__.DepartamentosService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.AlertController
}, {
  type: src_app_services_usuarios_service__WEBPACK_IMPORTED_MODULE_10__.UsuariosService
}, {
  type: src_app_services_modulos_matriz_acceso_service__WEBPACK_IMPORTED_MODULE_11__.ModulosMatrizAccesoService
}];
ControlMatrizAccesoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.Component)({
  selector: 'app-control-matriz-acceso',
  template: _control_matriz_acceso_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_control_matriz_acceso_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], ControlMatrizAccesoPage);


/***/ }),

/***/ 75892:
/*!****************************************************************************************!*\
  !*** ./src/app/pages/control-matriz-acceso/control-matriz-acceso.page.scss?ngResource ***!
  \****************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 49579);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60931);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 88690:
/*!****************************************************************************************!*\
  !*** ./src/app/pages/control-matriz-acceso/control-matriz-acceso.page.html?ngResource ***!
  \****************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n<ion-header class=\"ion-no-border ion-padding\">\n  <ion-toolbar  >\n    <ion-title class=\"ion-text-capitalize\" class=\"page-title\">Matriz Acceso</ion-title>\n    <ion-searchbar    slot=\"end\" style=\"width:30%;margin-top: 1rem;\" mode=\"ios\" placeholder=\"buscar usuario\"  type=\"text\"   [debounce]=\"250\"  ></ion-searchbar>\n    <ion-fab-button *ngIf=\"usuariosService.moduloAcceso.c\" size=\"small\" (click)=\"crearMatrizAcceso()\"  class=\"margin-right\"  slot=\"end\" color=\"dark\"  >\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n\n  </ion-toolbar>\n\n  <ion-list >\n    <ion-item lines=\"full\"  >\n      <ion-grid >\n        <ion-row>\n          <ion-col>\n            <ion-label><strong>\n              Id\n            </strong></ion-label>\n                  </ion-col>\n          <ion-col   >\n    <ion-label><strong>\n      Compañia\n    </strong></ion-label>\n          </ion-col>\n          <ion-col>\n            <ion-label><strong>\n             Departamento\n            </strong></ion-label>\n                  </ion-col>\n          <ion-col >\n    <ion-label><strong>\n      Nombre Rol\n    </strong></ion-label>\n          </ion-col>\n    \n          <ion-col >\n          <ion-label><strong>\n            Creación\n          </strong></ion-label>\n          </ion-col>\n          <ion-col >\n            <ion-label><strong>\n              Lectura\n            </strong></ion-label>\n          </ion-col>\n          <ion-col >\n            <ion-label><strong>\n              Editor\n            </strong></ion-label>\n          </ion-col>\n          <ion-col >\n            <ion-label><strong>\n              Borrar\n            </strong></ion-label>\n          </ion-col>\n          <ion-col>\n       Opciones\n          </ion-col>\n  \n        </ion-row>\n      </ion-grid>\n    </ion-item>\n  </ion-list>\n</ion-header>\n\n\n<ion-content>\n<ion-grid   style=\"height: 100%;\">\n<ion-list>\n  <ion-item *ngFor=\"let acceso of matrizAccesoService.matrizAcceso\">\n<ion-grid >\n  <ion-row>\n    <ion-col>\n<ion-label>{{acceso.iD_ONE_MATRIZ_ACCESO}}</ion-label>\n            </ion-col>\n    <ion-col  >\n      <ion-label>{{acceso.nombrE_COMPANIA}}</ion-label>\n    </ion-col>\n    <ion-col>\n      <ion-label>{{acceso.nombrE_DEPARTAMENTO}}</ion-label>\n            </ion-col>\n    <ion-col >\n      <ion-label>{{acceso.nombre}}</ion-label>\n    </ion-col>\n\n    <ion-col >\n      <ion-label>{{acceso.c ? 'Si' : 'No'}}</ion-label>\n    </ion-col>\n    <ion-col >\n      <ion-label>{{acceso.r ? 'Si' : 'No'}}</ion-label>\n    </ion-col>\n    <ion-col >\n      <ion-label>{{acceso.u ? 'Si' : 'No' }}</ion-label>\n    </ion-col>\n    <ion-col >\n      <ion-label>{{acceso.d ? 'Si' : 'No' }}</ion-label>\n    </ion-col>\n    <ion-col style=\"display: flex;justify-content: flex-start;align-items: center;\">\n <ion-button *ngIf=\"usuariosService.moduloAcceso.d\"  (click)=\"borrarMatrizAcceso(acceso)\"   fill=\"clear\"  >\n<ion-icon   color=\"danger\" slot=\"icon-only\" name=\"trash\"></ion-icon>\n </ion-button>\n <ion-button  *ngIf=\"usuariosService.moduloAcceso.u\"  (click)=\"EditarMatrizAcceso(acceso)\"  fill=\"clear\"  >\n  <ion-icon color=\"primary\" slot=\"icon-only\" name=\"create\"></ion-icon>\n   </ion-button>\n    </ion-col>\n \n  </ion-row>\n</ion-grid>\n  </ion-item>\n</ion-list>\n  <ion-row   *ngIf=\"matrizAccesoService.matrizAcceso.length == 0\"\n  style=\"height: 100%;display: flex;justify-content: center;align-items: center;\">\n  <ion-col size=\"12\">\n    <ion-list>\n      <ion-item lines=\"none\">\n\n        <ion-grid>\n          <ion-row>\n            <ion-col size=\"12\" class=\"ion-text-center ion-margin-top\">\n              <img height=\"150\" src=\"assets/imgs/empty-box.svg\" alt=\"\">\n            </ion-col>\n            <ion-col size=\"12\" class=\"ion-text-center\">\n              <strong class=\"ion-text-capitalize\">No hay datos que mostrar</strong>\n            </ion-col>\n\n          </ion-row>\n        </ion-grid>\n\n      </ion-item>\n    </ion-list>\n  </ion-col>\n</ion-row>\n\n</ion-grid>\n</ion-content>\n<app-pie-pagina></app-pie-pagina>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_control-matriz-acceso_control-matriz-acceso_module_ts.js.map