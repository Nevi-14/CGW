(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["common"],{

/***/ 78063:
/*!*********************************************************************!*\
  !*** ./src/app/pages/crear-departamento/crear-departamento.page.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CrearDepartamentoPage": () => (/* binding */ CrearDepartamentoPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _crear_departamento_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./crear-departamento.page.html?ngResource */ 32472);
/* harmony import */ var _crear_departamento_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./crear-departamento.page.scss?ngResource */ 71489);
/* harmony import */ var _crear_departamento_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_crear_departamento_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/alertas.service */ 34997);
/* harmony import */ var src_app_services_departamentos_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/departamentos.service */ 66646);







let CrearDepartamentoPage = class CrearDepartamentoPage {
  constructor(modalCtrl, alertasService, departamentosService) {
    this.modalCtrl = modalCtrl;
    this.alertasService = alertasService;
    this.departamentosService = departamentosService;
    this.departamento = {
      id: null,
      nombre: null,
      descripcion: null
    };
  }
  ngOnInit() {}
  cerrarModal() {
    this.modalCtrl.dismiss();
  }
  post() {
    this.alertasService.presentaLoading('Guardando datos..');
    this.departamentosService.syncPostDepartamentoToPromise(this.departamento).then(resp => {
      this.alertasService.loadingDissmiss();
      this.departamentosService.syncGetDepartamentoToPromise().then(departamentos => {
        this.departamentosService.departamentos = departamentos;
        this.modalCtrl.dismiss();
      }, error => {
        this.alertasService.message('Dione', 'Lo sentimos algo salio mal!..');
      });
    }, error => {
      this.alertasService.loadingDissmiss();
      this.alertasService.message('Dione', 'Lo sentimos algo salio mal!..');
    });
  }
};
CrearDepartamentoPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController
}, {
  type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_2__.AlertasService
}, {
  type: src_app_services_departamentos_service__WEBPACK_IMPORTED_MODULE_3__.DepartamentosService
}];
CrearDepartamentoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
  selector: 'app-crear-departamento',
  template: _crear_departamento_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
  styles: [(_crear_departamento_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1___default())]
})], CrearDepartamentoPage);


/***/ }),

/***/ 88384:
/*!***********************************************************************!*\
  !*** ./src/app/pages/editar-departamento/editar-departamento.page.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditarDepartamentoPage": () => (/* binding */ EditarDepartamentoPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _editar_departamento_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./editar-departamento.page.html?ngResource */ 53796);
/* harmony import */ var _editar_departamento_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./editar-departamento.page.scss?ngResource */ 98228);
/* harmony import */ var _editar_departamento_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_editar_departamento_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/alertas.service */ 34997);
/* harmony import */ var src_app_services_departamentos_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/departamentos.service */ 66646);







let EditarDepartamentoPage = class EditarDepartamentoPage {
  constructor(modalCtrl, alertasService, departamentosService) {
    this.modalCtrl = modalCtrl;
    this.alertasService = alertasService;
    this.departamentosService = departamentosService;
  }
  ngOnInit() {}
  cerrarModal() {
    this.modalCtrl.dismiss();
  }
  post() {
    this.alertasService.presentaLoading('Actualizando datos..');
    this.departamentosService.syncPutDepartamentoToPromise(this.departamento).then(resp => {
      this.alertasService.loadingDissmiss();
      this.departamentosService.syncGetDepartamentoToPromise().then(departamentos => {
        this.departamentosService.departamentos = departamentos;
        this.modalCtrl.dismiss();
      }, error => {
        this.alertasService.message('Dione', 'Lo sentimos algo salio mal!..');
      });
    }, error => {
      this.alertasService.loadingDissmiss();
      this.alertasService.message('Dione', 'Lo sentimos algo salio mal!..');
    });
  }
};
EditarDepartamentoPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController
}, {
  type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_2__.AlertasService
}, {
  type: src_app_services_departamentos_service__WEBPACK_IMPORTED_MODULE_3__.DepartamentosService
}];
EditarDepartamentoPage.propDecorators = {
  departamento: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input
  }]
};
EditarDepartamentoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
  selector: 'app-editar-departamento',
  template: _editar_departamento_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
  styles: [(_editar_departamento_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1___default())]
})], EditarDepartamentoPage);


/***/ }),

/***/ 3450:
/*!*************************************************************!*\
  !*** ./src/app/pages/editar-usuario/editar-usuario.page.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditarUsuarioPage": () => (/* binding */ EditarUsuarioPage)
/* harmony export */ });
/* harmony import */ var C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _editar_usuario_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./editar-usuario.page.html?ngResource */ 58853);
/* harmony import */ var _editar_usuario_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./editar-usuario.page.scss?ngResource */ 63275);
/* harmony import */ var _editar_usuario_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_editar_usuario_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/alertas.service */ 34997);
/* harmony import */ var src_app_services_matriz_acceso_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/matriz-acceso.service */ 75444);
/* harmony import */ var src_app_services_usuarios_matriz_acceso_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/usuarios-matriz-acceso.service */ 4710);
/* harmony import */ var src_app_services_usuarios_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/usuarios.service */ 81209);










let EditarUsuarioPage = class EditarUsuarioPage {
  constructor(usuariosService, alertasService, modalCtrl, matrizAccesoService, usuariosMatrizAccesoService) {
    this.usuariosService = usuariosService;
    this.alertasService = alertasService;
    this.modalCtrl = modalCtrl;
    this.matrizAccesoService = matrizAccesoService;
    this.usuariosMatrizAccesoService = usuariosMatrizAccesoService;
    this.roles = [];
    this.matriz = [];
  }
  ngOnInit() {
    var _this = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('roles', _this.roles);
    })();
  }
  post() {
    var _this2 = this;
    return (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log(_this2.usuario);
      yield _this2.usuariosMatrizAccesoService.syncDeleteUsuarioMatrizAccesoToPromise(_this2.usuario.id);
      _this2.alertasService.presentaLoading('guardando cambios..');
      _this2.usuariosService.syncPutUsuarioToPromise(_this2.usuario).then(resp => {
        _this2.usuariosService.syncGetUsuariosToPromise().then(usuarios => {
          _this2.usuariosService.usuarios = usuarios;
          if (_this2.roles.length == 0) {
            _this2.usuariosService.syncGetUsuariosToPromise().then(usuarios => {
              _this2.usuariosService.usuarios = usuarios;
              _this2.alertasService.loadingDissmiss();
              _this2.modalCtrl.dismiss();
              _this2.alertasService.message('Dione', 'usuario Editado');
            }, error => {
              _this2.alertasService.loadingDissmiss();
            });
          }
          _this2.roles.forEach( /*#__PURE__*/function () {
            var _ref = (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (role, index) {
              let rod = {
                id: null,
                iD_ONE_MATRIZ_ACCESO: role,
                iD_USUARIO: _this2.usuario.id
              };
              console.log(rod);
              yield _this2.usuariosMatrizAccesoService.syncPostUsuarioMatrizAccesoToPromise(rod);
              if (index == _this2.roles.length - 1) {
                _this2.usuariosService.syncGetUsuariosToPromise().then(usuarios => {
                  _this2.usuariosService.usuarios = usuarios;
                  _this2.alertasService.loadingDissmiss();
                  _this2.modalCtrl.dismiss();
                  _this2.alertasService.message('Dione', 'usuario Editado');
                }, error => {
                  _this2.alertasService.loadingDissmiss();
                });
              }
            });
            return function (_x, _x2) {
              return _ref.apply(this, arguments);
            };
          }());
        }, error => {
          _this2.alertasService.loadingDissmiss();
        });
      }, error => {
        _this2.alertasService.loadingDissmiss();
      });
    })();
  }
  cerrarModal() {
    this.modalCtrl.dismiss();
  }
};
EditarUsuarioPage.ctorParameters = () => [{
  type: src_app_services_usuarios_service__WEBPACK_IMPORTED_MODULE_6__.UsuariosService
}, {
  type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_3__.AlertasService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController
}, {
  type: src_app_services_matriz_acceso_service__WEBPACK_IMPORTED_MODULE_4__.MatrizAccesoService
}, {
  type: src_app_services_usuarios_matriz_acceso_service__WEBPACK_IMPORTED_MODULE_5__.UsuariosMatrizAccesoService
}];
EditarUsuarioPage.propDecorators = {
  usuario: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input
  }],
  roles: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input
  }],
  matriz: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input
  }]
};
EditarUsuarioPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
  selector: 'app-editar-usuario',
  template: _editar_usuario_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_editar_usuario_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], EditarUsuarioPage);


/***/ }),

/***/ 44018:
/*!*************************************************************!*\
  !*** ./src/app/pages/lista-usuarios/lista-usuarios.page.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ListaUsuariosPage": () => (/* binding */ ListaUsuariosPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _lista_usuarios_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./lista-usuarios.page.html?ngResource */ 64545);
/* harmony import */ var _lista_usuarios_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./lista-usuarios.page.scss?ngResource */ 27255);
/* harmony import */ var _lista_usuarios_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lista_usuarios_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/alertas.service */ 34997);
/* harmony import */ var src_app_services_usuarios_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/usuarios.service */ 81209);







let ListaUsuariosPage = class ListaUsuariosPage {
  constructor(usuariosService, alertasService, modalCtrl) {
    this.usuariosService = usuariosService;
    this.alertasService = alertasService;
    this.modalCtrl = modalCtrl;
    this.usuarios = [];
    this.usuariosAnticipo = [];
    this.textoBuscar = '';
  }
  ngOnInit() {
    this.alertasService.presentaLoading('Cargando datos...');
    this.usuariosService.syncGetUsuariosExactusToPromise().then(resp => {
      this.alertasService.loadingDissmiss();
      this.usuarios = resp;
    }, error => {
      this.alertasService.loadingDissmiss();
      this.alertasService.message('APP', 'Lo sentimos algo salio mal..');
    });
  }
  agregarUsuario($event, u) {
    const isChecked = $event.detail.checked;
    console.log('isChecked', isChecked);
    if (isChecked) {
      this.usuariosAnticipo.push(this.usuarios[u]);
    } else {
      let i = this.usuariosAnticipo.findIndex(k => k.usuario == this.usuarios[u].usuario);
      if (i >= 0) {
        this.usuariosAnticipo.splice(i, 1);
      }
    }
    console.log('This.usuariosAnticipo', this.usuariosAnticipo);
  }
  cerrarModal() {
    this.modalCtrl.dismiss();
  }
  retornarUsuarios() {
    this.modalCtrl.dismiss(this.usuariosAnticipo);
  }
};
ListaUsuariosPage.ctorParameters = () => [{
  type: src_app_services_usuarios_service__WEBPACK_IMPORTED_MODULE_3__.UsuariosService
}, {
  type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_2__.AlertasService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController
}];
ListaUsuariosPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
  selector: 'app-lista-usuarios',
  template: _lista_usuarios_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
  styles: [(_lista_usuarios_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1___default())]
})], ListaUsuariosPage);


/***/ }),

/***/ 7992:
/*!*********************************************!*\
  !*** ./src/app/pages/perfil/perfil.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PerfilPage": () => (/* binding */ PerfilPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _perfil_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./perfil.page.html?ngResource */ 15246);
/* harmony import */ var _perfil_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./perfil.page.scss?ngResource */ 3976);
/* harmony import */ var _perfil_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_perfil_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _services_usuarios_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/usuarios.service */ 81209);






let PerfilPage = class PerfilPage {
  constructor(modalCtrl, usuariosService) {
    this.modalCtrl = modalCtrl;
    this.usuariosService = usuariosService;
  }
  ngOnInit() {
    console.log('usuariosService', this.usuariosService.usuario);
  }
  cerrarModal() {
    this.modalCtrl.dismiss();
  }
};
PerfilPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController
}, {
  type: _services_usuarios_service__WEBPACK_IMPORTED_MODULE_2__.UsuariosService
}];
PerfilPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
  selector: 'app-perfil',
  template: _perfil_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
  styles: [(_perfil_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1___default())]
})], PerfilPage);


/***/ }),

/***/ 45406:
/*!*******************************************************!*\
  !*** ./src/app/services/adelanto-viaticos.service.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AdelantoViaticosService": () => (/* binding */ AdelantoViaticosService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let AdelantoViaticosService = class AdelantoViaticosService {
  constructor(http) {
    this.http = http;
    this.lineasAnticipo = [];
    this.adelantoVaticos = [];
  }
  getAPI(api) {
    let test = "";
    if (!src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.prdMode) test = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.TestURL;
    const URL = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.preURL + test + src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postURL + api;
    return URL;
  }
  getAdelantoViaticos() {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getAdelantoViaticos);
    console.log('URL', URL);
    return this.http.get(URL);
  }
  getGastosAnticipo(id) {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.getGastosAnticipos);
    URL = URL + id;
    console.log('URL', URL);
    return this.http.get(URL);
  }
  postAdelantoViaticos(adelanto) {
    const URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postAdelantoViaticos);
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Origin': '*'
      }
    };
    console.log('URL', URL);
    return this.http.post(URL, adelanto, options);
  }
  putAdelantoViaticos(adelanto) {
    let URL = this.getAPI(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.putAdelantoViaticos);
    URL = URL + adelanto.id;
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Origin': '*'
      }
    };
    console.log('URL', URL);
    return this.http.put(URL, adelanto, options);
  }
  syncGetAdelantoViaticosToPromise() {
    return this.getAdelantoViaticos().toPromise();
  }
  syncGetGastosAnticipo(id) {
    return this.getGastosAnticipo(id).toPromise();
  }
  syncPostAdelantoViaticosToPromise(adelanto) {
    return this.postAdelantoViaticos(adelanto).toPromise();
  }
  syncPuttAdelantoViaticosToPromise(adelanto) {
    return this.putAdelantoViaticos(adelanto).toPromise();
  }
};
AdelantoViaticosService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
}];
AdelantoViaticosService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], AdelantoViaticosService);


/***/ }),

/***/ 31534:
/*!********************************************!*\
  !*** ./src/app/services/correo.service.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CorreoService": () => (/* binding */ CorreoService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 92340);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _alertas_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./alertas.service */ 34997);
/* harmony import */ var _usuarios_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./usuarios.service */ 81209);






let CorreoService = class CorreoService {
  constructor(http, alertasService, usuariosService) {
    this.http = http;
    this.alertasService = alertasService;
    this.usuariosService = usuariosService;
  }
  getAPI(api) {
    let test = "";
    if (!_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.prdMode) test = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.TestURL;
    const URL = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.preURL + test + _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postURL + api;
    return URL;
  }
  postEmailApi(email) {
    const URL = this.getAPI(_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.postEmail);
    const options = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    };
    console.log('URL post lineas: ', URL);
    console.log('JSON Lineas:', JSON.stringify(email));
    return this.http.post(URL, JSON.stringify(email), options);
  }
  syncPostEmailToPromise(email) {
    return this.postEmailApi(email).toPromise();
  }
  enviarCorreo(estado) {
    this.usuariosService.syncGetUsuariosToPromise().then(resp => {
      let i = resp.findIndex(u => u.usuario == estado.destinatario);
      if (i >= 0) {
        this.alertasService.presentaLoading('Enviando correo...');
        let correo = {
          toEmail: resp[i].correo,
          file: estado.archivo,
          subject: 'Estado De Cuenta ' + estado.archivo,
          body: 'Se adjunta el estado de cuenta ' + estado.archivo
        };
        this.syncPostEmailToPromise(correo).then(resp => {
          this.alertasService.message('APP', 'Correo enviado..');
          this.alertasService.loadingDissmiss();
          console.log('resp', resp);
        }, error => {
          this.alertasService.loadingDissmiss();
          this.alertasService.message('APP', 'Lo sentimos algo salio mal...');
        });
      }
    });
  }
};
CorreoService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient
}, {
  type: _alertas_service__WEBPACK_IMPORTED_MODULE_1__.AlertasService
}, {
  type: _usuarios_service__WEBPACK_IMPORTED_MODULE_2__.UsuariosService
}];
CorreoService = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
  providedIn: 'root'
})], CorreoService);


/***/ }),

/***/ 65539:
/*!*********************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/button-active-a4d897e8.js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "c": () => (/* binding */ createButtonActiveGesture)
/* harmony export */ });
/* harmony import */ var _index_8e692445_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-8e692445.js */ 91559);
/* harmony import */ var _haptic_029a46f6_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./haptic-029a46f6.js */ 12815);
/* harmony import */ var _index_422b6e83_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./index-422b6e83.js */ 88759);
/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */



const createButtonActiveGesture = (el, isButton) => {
  let currentTouchedButton;
  let initialTouchedButton;
  const activateButtonAtPoint = (x, y, hapticFeedbackFn) => {
    if (typeof document === 'undefined') {
      return;
    }
    const target = document.elementFromPoint(x, y);
    if (!target || !isButton(target)) {
      clearActiveButton();
      return;
    }
    if (target !== currentTouchedButton) {
      clearActiveButton();
      setActiveButton(target, hapticFeedbackFn);
    }
  };
  const setActiveButton = (button, hapticFeedbackFn) => {
    currentTouchedButton = button;
    if (!initialTouchedButton) {
      initialTouchedButton = currentTouchedButton;
    }
    const buttonToModify = currentTouchedButton;
    (0,_index_8e692445_js__WEBPACK_IMPORTED_MODULE_0__.c)(() => buttonToModify.classList.add('ion-activated'));
    hapticFeedbackFn();
  };
  const clearActiveButton = (dispatchClick = false) => {
    if (!currentTouchedButton) {
      return;
    }
    const buttonToModify = currentTouchedButton;
    (0,_index_8e692445_js__WEBPACK_IMPORTED_MODULE_0__.c)(() => buttonToModify.classList.remove('ion-activated'));
    /**
     * Clicking on one button, but releasing on another button
     * does not dispatch a click event in browsers, so we
     * need to do it manually here. Some browsers will
     * dispatch a click if clicking on one button, dragging over
     * another button, and releasing on the original button. In that
     * case, we need to make sure we do not cause a double click there.
     */
    if (dispatchClick && initialTouchedButton !== currentTouchedButton) {
      currentTouchedButton.click();
    }
    currentTouchedButton = undefined;
  };
  return (0,_index_422b6e83_js__WEBPACK_IMPORTED_MODULE_2__.createGesture)({
    el,
    gestureName: 'buttonActiveDrag',
    threshold: 0,
    onStart: ev => activateButtonAtPoint(ev.currentX, ev.currentY, _haptic_029a46f6_js__WEBPACK_IMPORTED_MODULE_1__.a),
    onMove: ev => activateButtonAtPoint(ev.currentX, ev.currentY, _haptic_029a46f6_js__WEBPACK_IMPORTED_MODULE_1__.b),
    onEnd: () => {
      clearActiveButton(true);
      (0,_haptic_029a46f6_js__WEBPACK_IMPORTED_MODULE_1__.h)();
      initialTouchedButton = undefined;
    }
  });
};


/***/ }),

/***/ 17481:
/*!***********************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/dir-e8b767a8.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "i": () => (/* binding */ isRTL)
/* harmony export */ });
/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
/**
 * Returns `true` if the document or host element
 * has a `dir` set to `rtl`. The host value will always
 * take priority over the root document value.
 */
const isRTL = hostEl => {
  if (hostEl) {
    if (hostEl.dir !== '') {
      return hostEl.dir.toLowerCase() === 'rtl';
    }
  }
  return (document === null || document === void 0 ? void 0 : document.dir.toLowerCase()) === 'rtl';
};


/***/ }),

/***/ 69118:
/*!*********************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/focus-visible-bd02518b.js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "startFocusVisible": () => (/* binding */ startFocusVisible)
/* harmony export */ });
/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
const ION_FOCUSED = 'ion-focused';
const ION_FOCUSABLE = 'ion-focusable';
const FOCUS_KEYS = ['Tab', 'ArrowDown', 'Space', 'Escape', ' ', 'Shift', 'Enter', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'Home', 'End'];
const startFocusVisible = rootEl => {
  let currentFocus = [];
  let keyboardMode = true;
  const ref = rootEl ? rootEl.shadowRoot : document;
  const root = rootEl ? rootEl : document.body;
  const setFocus = elements => {
    currentFocus.forEach(el => el.classList.remove(ION_FOCUSED));
    elements.forEach(el => el.classList.add(ION_FOCUSED));
    currentFocus = elements;
  };
  const pointerDown = () => {
    keyboardMode = false;
    setFocus([]);
  };
  const onKeydown = ev => {
    keyboardMode = FOCUS_KEYS.includes(ev.key);
    if (!keyboardMode) {
      setFocus([]);
    }
  };
  const onFocusin = ev => {
    if (keyboardMode && ev.composedPath !== undefined) {
      const toFocus = ev.composedPath().filter(el => {
        // TODO(FW-2832): type
        if (el.classList) {
          return el.classList.contains(ION_FOCUSABLE);
        }
        return false;
      });
      setFocus(toFocus);
    }
  };
  const onFocusout = () => {
    if (ref.activeElement === root) {
      setFocus([]);
    }
  };
  ref.addEventListener('keydown', onKeydown);
  ref.addEventListener('focusin', onFocusin);
  ref.addEventListener('focusout', onFocusout);
  ref.addEventListener('touchstart', pointerDown);
  ref.addEventListener('mousedown', pointerDown);
  const destroy = () => {
    ref.removeEventListener('keydown', onKeydown);
    ref.removeEventListener('focusin', onFocusin);
    ref.removeEventListener('focusout', onFocusout);
    ref.removeEventListener('touchstart', pointerDown);
    ref.removeEventListener('mousedown', pointerDown);
  };
  return {
    destroy,
    setFocus
  };
};


/***/ }),

/***/ 90539:
/*!**************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/framework-delegate-c3305a28.js ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C": () => (/* binding */ CoreDelegate),
/* harmony export */   "a": () => (/* binding */ attachComponent),
/* harmony export */   "d": () => (/* binding */ detachComponent)
/* harmony export */ });
/* harmony import */ var C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var _helpers_3b390e48_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./helpers-3b390e48.js */ 29259);

/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */


// TODO(FW-2832): types
const attachComponent = /*#__PURE__*/function () {
  var _ref = (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (delegate, container, component, cssClasses, componentProps, inline) {
    var _a;
    if (delegate) {
      return delegate.attachViewToDom(container, component, componentProps, cssClasses);
    }
    if (!inline && typeof component !== 'string' && !(component instanceof HTMLElement)) {
      throw new Error('framework delegate is missing');
    }
    const el = typeof component === 'string' ? (_a = container.ownerDocument) === null || _a === void 0 ? void 0 : _a.createElement(component) : component;
    if (cssClasses) {
      cssClasses.forEach(c => el.classList.add(c));
    }
    if (componentProps) {
      Object.assign(el, componentProps);
    }
    container.appendChild(el);
    yield new Promise(resolve => (0,_helpers_3b390e48_js__WEBPACK_IMPORTED_MODULE_1__.c)(el, resolve));
    return el;
  });
  return function attachComponent(_x, _x2, _x3, _x4, _x5, _x6) {
    return _ref.apply(this, arguments);
  };
}();
const detachComponent = (delegate, element) => {
  if (element) {
    if (delegate) {
      const container = element.parentElement;
      return delegate.removeViewFromDom(container, element);
    }
    element.remove();
  }
  return Promise.resolve();
};
const CoreDelegate = () => {
  let BaseComponent;
  let Reference;
  const attachViewToDom = /*#__PURE__*/function () {
    var _ref2 = (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (parentElement, userComponent, userComponentProps = {}, cssClasses = []) {
      var _a, _b;
      BaseComponent = parentElement;
      /**
       * If passing in a component via the `component` props
       * we need to append it inside of our overlay component.
       */
      if (userComponent) {
        /**
         * If passing in the tag name, create
         * the element otherwise just get a reference
         * to the component.
         */
        const el = typeof userComponent === 'string' ? (_a = BaseComponent.ownerDocument) === null || _a === void 0 ? void 0 : _a.createElement(userComponent) : userComponent;
        /**
         * Add any css classes passed in
         * via the cssClasses prop on the overlay.
         */
        cssClasses.forEach(c => el.classList.add(c));
        /**
         * Add any props passed in
         * via the componentProps prop on the overlay.
         */
        Object.assign(el, userComponentProps);
        /**
         * Finally, append the component
         * inside of the overlay component.
         */
        BaseComponent.appendChild(el);
        yield new Promise(resolve => (0,_helpers_3b390e48_js__WEBPACK_IMPORTED_MODULE_1__.c)(el, resolve));
      } else if (BaseComponent.children.length > 0) {
        const root = BaseComponent.children[0];
        if (!root.classList.contains('ion-delegate-host')) {
          /**
           * If the root element is not a delegate host, it means
           * that the overlay has not been presented yet and we need
           * to create the containing element with the specified classes.
           */
          const el = (_b = BaseComponent.ownerDocument) === null || _b === void 0 ? void 0 : _b.createElement('div');
          // Add a class to track if the root element was created by the delegate.
          el.classList.add('ion-delegate-host');
          cssClasses.forEach(c => el.classList.add(c));
          // Move each child from the original template to the new parent element.
          el.append(...BaseComponent.children);
          // Append the new parent element to the original parent element.
          BaseComponent.appendChild(el);
        }
      }
      /**
       * Get the root of the app and
       * add the overlay there.
       */
      const app = document.querySelector('ion-app') || document.body;
      /**
       * Create a placeholder comment so that
       * we can return this component to where
       * it was previously.
       */
      Reference = document.createComment('ionic teleport');
      BaseComponent.parentNode.insertBefore(Reference, BaseComponent);
      app.appendChild(BaseComponent);
      return BaseComponent;
    });
    return function attachViewToDom(_x7, _x8) {
      return _ref2.apply(this, arguments);
    };
  }();
  const removeViewFromDom = () => {
    /**
     * Return component to where it was previously in the DOM.
     */
    if (BaseComponent && Reference) {
      Reference.parentNode.insertBefore(BaseComponent, Reference);
      Reference.remove();
    }
    return Promise.resolve();
  };
  return {
    attachViewToDom,
    removeViewFromDom
  };
};


/***/ }),

/***/ 12815:
/*!**************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/haptic-029a46f6.js ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ hapticSelectionStart),
/* harmony export */   "b": () => (/* binding */ hapticSelectionChanged),
/* harmony export */   "c": () => (/* binding */ hapticSelection),
/* harmony export */   "d": () => (/* binding */ hapticImpact),
/* harmony export */   "h": () => (/* binding */ hapticSelectionEnd)
/* harmony export */ });
/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
const HapticEngine = {
  getEngine() {
    var _a;
    const win = window;
    return win.TapticEngine || ((_a = win.Capacitor) === null || _a === void 0 ? void 0 : _a.isPluginAvailable('Haptics')) && win.Capacitor.Plugins.Haptics;
  },
  available() {
    var _a;
    const win = window;
    const engine = this.getEngine();
    if (!engine) {
      return false;
    }
    /**
     * Developers can manually import the
     * Haptics plugin in their app which will cause
     * getEngine to return the Haptics engine. However,
     * the Haptics engine will throw an error if
     * used in a web browser that does not support
     * the Vibrate API. This check avoids that error
     * if the browser does not support the Vibrate API.
     */
    if (((_a = win.Capacitor) === null || _a === void 0 ? void 0 : _a.getPlatform()) === 'web') {
      return typeof navigator !== 'undefined' && navigator.vibrate !== undefined;
    }
    return true;
  },
  isCordova() {
    return !!window.TapticEngine;
  },
  isCapacitor() {
    const win = window;
    return !!win.Capacitor;
  },
  impact(options) {
    const engine = this.getEngine();
    if (!engine) {
      return;
    }
    const style = this.isCapacitor() ? options.style.toUpperCase() : options.style;
    engine.impact({
      style
    });
  },
  notification(options) {
    const engine = this.getEngine();
    if (!engine) {
      return;
    }
    const style = this.isCapacitor() ? options.style.toUpperCase() : options.style;
    engine.notification({
      style
    });
  },
  selection() {
    this.impact({
      style: 'light'
    });
  },
  selectionStart() {
    const engine = this.getEngine();
    if (!engine) {
      return;
    }
    if (this.isCapacitor()) {
      engine.selectionStart();
    } else {
      engine.gestureSelectionStart();
    }
  },
  selectionChanged() {
    const engine = this.getEngine();
    if (!engine) {
      return;
    }
    if (this.isCapacitor()) {
      engine.selectionChanged();
    } else {
      engine.gestureSelectionChanged();
    }
  },
  selectionEnd() {
    const engine = this.getEngine();
    if (!engine) {
      return;
    }
    if (this.isCapacitor()) {
      engine.selectionEnd();
    } else {
      engine.gestureSelectionEnd();
    }
  }
};
/**
 * Check to see if the Haptic Plugin is available
 * @return Returns `true` or false if the plugin is available
 */
const hapticAvailable = () => {
  return HapticEngine.available();
};
/**
 * Trigger a selection changed haptic event. Good for one-time events
 * (not for gestures)
 */
const hapticSelection = () => {
  hapticAvailable() && HapticEngine.selection();
};
/**
 * Tell the haptic engine that a gesture for a selection change is starting.
 */
const hapticSelectionStart = () => {
  hapticAvailable() && HapticEngine.selectionStart();
};
/**
 * Tell the haptic engine that a selection changed during a gesture.
 */
const hapticSelectionChanged = () => {
  hapticAvailable() && HapticEngine.selectionChanged();
};
/**
 * Tell the haptic engine we are done with a gesture. This needs to be
 * called lest resources are not properly recycled.
 */
const hapticSelectionEnd = () => {
  hapticAvailable() && HapticEngine.selectionEnd();
};
/**
 * Use this to indicate success/failure/warning to the user.
 * options should be of the type `{ style: 'light' }` (or `medium`/`heavy`)
 */
const hapticImpact = options => {
  hapticAvailable() && HapticEngine.impact(options);
};


/***/ }),

/***/ 72880:
/*!*************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/index-175a9345.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ arrowBackSharp),
/* harmony export */   "b": () => (/* binding */ closeCircle),
/* harmony export */   "c": () => (/* binding */ chevronBack),
/* harmony export */   "d": () => (/* binding */ closeSharp),
/* harmony export */   "e": () => (/* binding */ searchSharp),
/* harmony export */   "f": () => (/* binding */ checkmarkOutline),
/* harmony export */   "g": () => (/* binding */ ellipseOutline),
/* harmony export */   "h": () => (/* binding */ caretBackSharp),
/* harmony export */   "i": () => (/* binding */ arrowDown),
/* harmony export */   "j": () => (/* binding */ reorderThreeOutline),
/* harmony export */   "k": () => (/* binding */ reorderTwoSharp),
/* harmony export */   "l": () => (/* binding */ chevronDown),
/* harmony export */   "m": () => (/* binding */ chevronForwardOutline),
/* harmony export */   "n": () => (/* binding */ ellipsisHorizontal),
/* harmony export */   "o": () => (/* binding */ chevronForward),
/* harmony export */   "p": () => (/* binding */ caretUpSharp),
/* harmony export */   "q": () => (/* binding */ caretDownSharp),
/* harmony export */   "r": () => (/* binding */ removeOutline),
/* harmony export */   "s": () => (/* binding */ searchOutline),
/* harmony export */   "t": () => (/* binding */ close),
/* harmony export */   "u": () => (/* binding */ menuOutline),
/* harmony export */   "v": () => (/* binding */ menuSharp)
/* harmony export */ });
/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
/* Ionicons v6.1.1, ES Modules */
const arrowBackSharp = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path stroke-linecap='square' stroke-miterlimit='10' stroke-width='48' d='M244 400L100 256l144-144M120 256h292' class='ionicon-fill-none'/></svg>";
const arrowDown = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path stroke-linecap='round' stroke-linejoin='round' stroke-width='48' d='M112 268l144 144 144-144M256 392V100' class='ionicon-fill-none'/></svg>";
const caretBackSharp = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path d='M368 64L144 256l224 192V64z'/></svg>";
const caretDownSharp = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path d='M64 144l192 224 192-224H64z'/></svg>";
const caretUpSharp = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path d='M448 368L256 144 64 368h384z'/></svg>";
const checkmarkOutline = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path stroke-linecap='round' stroke-linejoin='round' d='M416 128L192 384l-96-96' class='ionicon-fill-none ionicon-stroke-width'/></svg>";
const chevronBack = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path stroke-linecap='round' stroke-linejoin='round' stroke-width='48' d='M328 112L184 256l144 144' class='ionicon-fill-none'/></svg>";
const chevronDown = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path stroke-linecap='round' stroke-linejoin='round' stroke-width='48' d='M112 184l144 144 144-144' class='ionicon-fill-none'/></svg>";
const chevronForward = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path stroke-linecap='round' stroke-linejoin='round' stroke-width='48' d='M184 112l144 144-144 144' class='ionicon-fill-none'/></svg>";
const chevronForwardOutline = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path stroke-linecap='round' stroke-linejoin='round' stroke-width='48' d='M184 112l144 144-144 144' class='ionicon-fill-none'/></svg>";
const close = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path d='M289.94 256l95-95A24 24 0 00351 127l-95 95-95-95a24 24 0 00-34 34l95 95-95 95a24 24 0 1034 34l95-95 95 95a24 24 0 0034-34z'/></svg>";
const closeCircle = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path d='M256 48C141.31 48 48 141.31 48 256s93.31 208 208 208 208-93.31 208-208S370.69 48 256 48zm75.31 260.69a16 16 0 11-22.62 22.62L256 278.63l-52.69 52.68a16 16 0 01-22.62-22.62L233.37 256l-52.68-52.69a16 16 0 0122.62-22.62L256 233.37l52.69-52.68a16 16 0 0122.62 22.62L278.63 256z'/></svg>";
const closeSharp = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path d='M400 145.49L366.51 112 256 222.51 145.49 112 112 145.49 222.51 256 112 366.51 145.49 400 256 289.49 366.51 400 400 366.51 289.49 256 400 145.49z'/></svg>";
const ellipseOutline = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><circle cx='256' cy='256' r='192' stroke-linecap='round' stroke-linejoin='round' class='ionicon-fill-none ionicon-stroke-width'/></svg>";
const ellipsisHorizontal = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><circle cx='256' cy='256' r='48'/><circle cx='416' cy='256' r='48'/><circle cx='96' cy='256' r='48'/></svg>";
const menuOutline = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path stroke-linecap='round' stroke-miterlimit='10' d='M80 160h352M80 256h352M80 352h352' class='ionicon-fill-none ionicon-stroke-width'/></svg>";
const menuSharp = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path d='M64 384h384v-42.67H64zm0-106.67h384v-42.66H64zM64 128v42.67h384V128z'/></svg>";
const removeOutline = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path stroke-linecap='round' stroke-linejoin='round' d='M400 256H112' class='ionicon-fill-none ionicon-stroke-width'/></svg>";
const reorderThreeOutline = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path stroke-linecap='round' stroke-linejoin='round' d='M96 256h320M96 176h320M96 336h320' class='ionicon-fill-none ionicon-stroke-width'/></svg>";
const reorderTwoSharp = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path stroke-linecap='square' stroke-linejoin='round' stroke-width='44' d='M118 304h276M118 208h276' class='ionicon-fill-none'/></svg>";
const searchOutline = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path d='M221.09 64a157.09 157.09 0 10157.09 157.09A157.1 157.1 0 00221.09 64z' stroke-miterlimit='10' class='ionicon-fill-none ionicon-stroke-width'/><path stroke-linecap='round' stroke-miterlimit='10' d='M338.29 338.29L448 448' class='ionicon-fill-none ionicon-stroke-width'/></svg>";
const searchSharp = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path d='M464 428L339.92 303.9a160.48 160.48 0 0030.72-94.58C370.64 120.37 298.27 48 209.32 48S48 120.37 48 209.32s72.37 161.32 161.32 161.32a160.48 160.48 0 0094.58-30.72L428 464zM209.32 319.69a110.38 110.38 0 11110.37-110.37 110.5 110.5 0 01-110.37 110.37z'/></svg>";


/***/ }),

/***/ 24311:
/*!*************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/index-e6d1a8be.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ ION_CONTENT_ELEMENT_SELECTOR),
/* harmony export */   "a": () => (/* binding */ findIonContent),
/* harmony export */   "b": () => (/* binding */ ION_CONTENT_CLASS_SELECTOR),
/* harmony export */   "c": () => (/* binding */ scrollByPoint),
/* harmony export */   "d": () => (/* binding */ disableContentScrollY),
/* harmony export */   "f": () => (/* binding */ findClosestIonContent),
/* harmony export */   "g": () => (/* binding */ getScrollElement),
/* harmony export */   "i": () => (/* binding */ isIonContent),
/* harmony export */   "p": () => (/* binding */ printIonContentErrorMsg),
/* harmony export */   "r": () => (/* binding */ resetContentScrollY),
/* harmony export */   "s": () => (/* binding */ scrollToTop)
/* harmony export */ });
/* harmony import */ var C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var _helpers_3b390e48_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./helpers-3b390e48.js */ 29259);
/* harmony import */ var _index_c4b11676_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./index-c4b11676.js */ 99273);

/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */


const ION_CONTENT_TAG_NAME = 'ION-CONTENT';
const ION_CONTENT_ELEMENT_SELECTOR = 'ion-content';
const ION_CONTENT_CLASS_SELECTOR = '.ion-content-scroll-host';
/**
 * Selector used for implementations reliant on `<ion-content>` for scroll event changes.
 *
 * Developers should use the `.ion-content-scroll-host` selector to target the element emitting
 * scroll events. With virtual scroll implementations this will be the host element for
 * the scroll viewport.
 */
const ION_CONTENT_SELECTOR = `${ION_CONTENT_ELEMENT_SELECTOR}, ${ION_CONTENT_CLASS_SELECTOR}`;
const isIonContent = el => el.tagName === ION_CONTENT_TAG_NAME;
/**
 * Waits for the element host fully initialize before
 * returning the inner scroll element.
 *
 * For `ion-content` the scroll target will be the result
 * of the `getScrollElement` function.
 *
 * For custom implementations it will be the element host
 * or a selector within the host, if supplied through `scrollTarget`.
 */
const getScrollElement = /*#__PURE__*/function () {
  var _ref = (0,C_Users_Nevil_Desktop_Simple_Design_Experience_Control_Viaticos_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (el) {
    if (isIonContent(el)) {
      yield new Promise(resolve => (0,_helpers_3b390e48_js__WEBPACK_IMPORTED_MODULE_1__.c)(el, resolve));
      return el.getScrollElement();
    }
    return el;
  });
  return function getScrollElement(_x) {
    return _ref.apply(this, arguments);
  };
}();
/**
 * Queries the element matching the selector for IonContent.
 * See ION_CONTENT_SELECTOR for the selector used.
 */
const findIonContent = el => {
  /**
   * First we try to query the custom scroll host selector in cases where
   * the implementation is using an outer `ion-content` with an inner custom
   * scroll container.
   */
  const customContentHost = el.querySelector(ION_CONTENT_CLASS_SELECTOR);
  if (customContentHost) {
    return customContentHost;
  }
  return el.querySelector(ION_CONTENT_SELECTOR);
};
/**
 * Queries the closest element matching the selector for IonContent.
 */
const findClosestIonContent = el => {
  return el.closest(ION_CONTENT_SELECTOR);
};
/**
 * Scrolls to the top of the element. If an `ion-content` is found, it will scroll
 * using the public API `scrollToTop` with a duration.
 */
// TODO(FW-2832): type
const scrollToTop = (el, durationMs) => {
  if (isIonContent(el)) {
    const content = el;
    return content.scrollToTop(durationMs);
  }
  return Promise.resolve(el.scrollTo({
    top: 0,
    left: 0,
    behavior: durationMs > 0 ? 'smooth' : 'auto'
  }));
};
/**
 * Scrolls by a specified X/Y distance in the component. If an `ion-content` is found, it will scroll
 * using the public API `scrollByPoint` with a duration.
 */
const scrollByPoint = (el, x, y, durationMs) => {
  if (isIonContent(el)) {
    const content = el;
    return content.scrollByPoint(x, y, durationMs);
  }
  return Promise.resolve(el.scrollBy({
    top: y,
    left: x,
    behavior: durationMs > 0 ? 'smooth' : 'auto'
  }));
};
/**
 * Prints an error informing developers that an implementation requires an element to be used
 * within either the `ion-content` selector or the `.ion-content-scroll-host` class.
 */
const printIonContentErrorMsg = el => {
  return (0,_index_c4b11676_js__WEBPACK_IMPORTED_MODULE_2__.a)(el, ION_CONTENT_ELEMENT_SELECTOR);
};
/**
 * Several components in Ionic need to prevent scrolling
 * during a gesture (card modal, range, item sliding, etc).
 * Use this utility to account for ion-content and custom content hosts.
 */
const disableContentScrollY = contentEl => {
  if (isIonContent(contentEl)) {
    const ionContent = contentEl;
    const initialScrollY = ionContent.scrollY;
    ionContent.scrollY = false;
    /**
     * This should be passed into resetContentScrollY
     * so that we can revert ion-content's scrollY to the
     * correct state. For example, if scrollY = false
     * initially, we do not want to enable scrolling
     * when we call resetContentScrollY.
     */
    return initialScrollY;
  } else {
    contentEl.style.setProperty('overflow', 'hidden');
    return true;
  }
};
const resetContentScrollY = (contentEl, initialScrollY) => {
  if (isIonContent(contentEl)) {
    contentEl.scrollY = initialScrollY;
  } else {
    contentEl.style.removeProperty('overflow');
  }
};


/***/ }),

/***/ 20512:
/*!****************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/keyboard-282b81b8.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "KEYBOARD_DID_CLOSE": () => (/* binding */ KEYBOARD_DID_CLOSE),
/* harmony export */   "KEYBOARD_DID_OPEN": () => (/* binding */ KEYBOARD_DID_OPEN),
/* harmony export */   "copyVisualViewport": () => (/* binding */ copyVisualViewport),
/* harmony export */   "keyboardDidClose": () => (/* binding */ keyboardDidClose),
/* harmony export */   "keyboardDidOpen": () => (/* binding */ keyboardDidOpen),
/* harmony export */   "keyboardDidResize": () => (/* binding */ keyboardDidResize),
/* harmony export */   "resetKeyboardAssist": () => (/* binding */ resetKeyboardAssist),
/* harmony export */   "setKeyboardClose": () => (/* binding */ setKeyboardClose),
/* harmony export */   "setKeyboardOpen": () => (/* binding */ setKeyboardOpen),
/* harmony export */   "startKeyboardAssist": () => (/* binding */ startKeyboardAssist),
/* harmony export */   "trackViewportChanges": () => (/* binding */ trackViewportChanges)
/* harmony export */ });
/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
const KEYBOARD_DID_OPEN = 'ionKeyboardDidShow';
const KEYBOARD_DID_CLOSE = 'ionKeyboardDidHide';
const KEYBOARD_THRESHOLD = 150;
// TODO(FW-2832): types
let previousVisualViewport = {};
let currentVisualViewport = {};
let keyboardOpen = false;
/**
 * This is only used for tests
 */
const resetKeyboardAssist = () => {
  previousVisualViewport = {};
  currentVisualViewport = {};
  keyboardOpen = false;
};
const startKeyboardAssist = win => {
  startNativeListeners(win);
  if (!win.visualViewport) {
    return;
  }
  currentVisualViewport = copyVisualViewport(win.visualViewport);
  win.visualViewport.onresize = () => {
    trackViewportChanges(win);
    if (keyboardDidOpen() || keyboardDidResize(win)) {
      setKeyboardOpen(win);
    } else if (keyboardDidClose(win)) {
      setKeyboardClose(win);
    }
  };
};
/**
 * Listen for events fired by native keyboard plugin
 * in Capacitor/Cordova so devs only need to listen
 * in one place.
 */
const startNativeListeners = win => {
  win.addEventListener('keyboardDidShow', ev => setKeyboardOpen(win, ev));
  win.addEventListener('keyboardDidHide', () => setKeyboardClose(win));
};
const setKeyboardOpen = (win, ev) => {
  fireKeyboardOpenEvent(win, ev);
  keyboardOpen = true;
};
const setKeyboardClose = win => {
  fireKeyboardCloseEvent(win);
  keyboardOpen = false;
};
/**
 * Returns `true` if the `keyboardOpen` flag is not
 * set, the previous visual viewport width equal the current
 * visual viewport width, and if the scaled difference
 * of the previous visual viewport height minus the current
 * visual viewport height is greater than KEYBOARD_THRESHOLD
 *
 * We need to be able to accommodate users who have zooming
 * enabled in their browser (or have zoomed in manually) which
 * is why we take into account the current visual viewport's
 * scale value.
 */
const keyboardDidOpen = () => {
  const scaledHeightDifference = (previousVisualViewport.height - currentVisualViewport.height) * currentVisualViewport.scale;
  return !keyboardOpen && previousVisualViewport.width === currentVisualViewport.width && scaledHeightDifference > KEYBOARD_THRESHOLD;
};
/**
 * Returns `true` if the keyboard is open,
 * but the keyboard did not close
 */
const keyboardDidResize = win => {
  return keyboardOpen && !keyboardDidClose(win);
};
/**
 * Determine if the keyboard was closed
 * Returns `true` if the `keyboardOpen` flag is set and
 * the current visual viewport height equals the
 * layout viewport height.
 */
const keyboardDidClose = win => {
  return keyboardOpen && currentVisualViewport.height === win.innerHeight;
};
/**
 * Dispatch a keyboard open event
 */
const fireKeyboardOpenEvent = (win, nativeEv) => {
  const keyboardHeight = nativeEv ? nativeEv.keyboardHeight : win.innerHeight - currentVisualViewport.height;
  const ev = new CustomEvent(KEYBOARD_DID_OPEN, {
    detail: {
      keyboardHeight
    }
  });
  win.dispatchEvent(ev);
};
/**
 * Dispatch a keyboard close event
 */
const fireKeyboardCloseEvent = win => {
  const ev = new CustomEvent(KEYBOARD_DID_CLOSE);
  win.dispatchEvent(ev);
};
/**
 * Given a window object, create a copy of
 * the current visual and layout viewport states
 * while also preserving the previous visual and
 * layout viewport states
 */
const trackViewportChanges = win => {
  previousVisualViewport = Object.assign({}, currentVisualViewport);
  currentVisualViewport = copyVisualViewport(win.visualViewport);
};
/**
 * Creates a deep copy of the visual viewport
 * at a given state
 */
const copyVisualViewport = visualViewport => {
  return {
    width: Math.round(visualViewport.width),
    height: Math.round(visualViewport.height),
    offsetTop: visualViewport.offsetTop,
    offsetLeft: visualViewport.offsetLeft,
    pageTop: visualViewport.pageTop,
    pageLeft: visualViewport.pageLeft,
    scale: visualViewport.scale
  };
};


/***/ }),

/***/ 23963:
/*!***************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/keyboard-controller-73af62b2.js ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "c": () => (/* binding */ createKeyboardController)
/* harmony export */ });
/* harmony import */ var _index_33ffec25_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-33ffec25.js */ 42286);
/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */


/**
 * Creates a controller that tracks and reacts to opening or closing the keyboard.
 *
 * @internal
 * @param keyboardChangeCallback A function to call when the keyboard opens or closes.
 */
const createKeyboardController = keyboardChangeCallback => {
  let keyboardWillShowHandler;
  let keyboardWillHideHandler;
  let keyboardVisible;
  const init = () => {
    keyboardWillShowHandler = () => {
      keyboardVisible = true;
      if (keyboardChangeCallback) keyboardChangeCallback(true);
    };
    keyboardWillHideHandler = () => {
      keyboardVisible = false;
      if (keyboardChangeCallback) keyboardChangeCallback(false);
    };
    _index_33ffec25_js__WEBPACK_IMPORTED_MODULE_0__.w === null || _index_33ffec25_js__WEBPACK_IMPORTED_MODULE_0__.w === void 0 ? void 0 : _index_33ffec25_js__WEBPACK_IMPORTED_MODULE_0__.w.addEventListener('keyboardWillShow', keyboardWillShowHandler);
    _index_33ffec25_js__WEBPACK_IMPORTED_MODULE_0__.w === null || _index_33ffec25_js__WEBPACK_IMPORTED_MODULE_0__.w === void 0 ? void 0 : _index_33ffec25_js__WEBPACK_IMPORTED_MODULE_0__.w.addEventListener('keyboardWillHide', keyboardWillHideHandler);
  };
  const destroy = () => {
    _index_33ffec25_js__WEBPACK_IMPORTED_MODULE_0__.w === null || _index_33ffec25_js__WEBPACK_IMPORTED_MODULE_0__.w === void 0 ? void 0 : _index_33ffec25_js__WEBPACK_IMPORTED_MODULE_0__.w.removeEventListener('keyboardWillShow', keyboardWillShowHandler);
    _index_33ffec25_js__WEBPACK_IMPORTED_MODULE_0__.w === null || _index_33ffec25_js__WEBPACK_IMPORTED_MODULE_0__.w === void 0 ? void 0 : _index_33ffec25_js__WEBPACK_IMPORTED_MODULE_0__.w.removeEventListener('keyboardWillHide', keyboardWillHideHandler);
    keyboardWillShowHandler = keyboardWillHideHandler = undefined;
  };
  const isKeyboardVisible = () => keyboardVisible;
  init();
  return {
    init,
    destroy,
    isKeyboardVisible
  };
};


/***/ }),

/***/ 43844:
/*!***********************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/spinner-configs-5d6b6fe7.js ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "S": () => (/* binding */ SPINNERS)
/* harmony export */ });
/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
const spinners = {
  bubbles: {
    dur: 1000,
    circles: 9,
    fn: (dur, index, total) => {
      const animationDelay = `${dur * index / total - dur}ms`;
      const angle = 2 * Math.PI * index / total;
      return {
        r: 5,
        style: {
          top: `${9 * Math.sin(angle)}px`,
          left: `${9 * Math.cos(angle)}px`,
          'animation-delay': animationDelay
        }
      };
    }
  },
  circles: {
    dur: 1000,
    circles: 8,
    fn: (dur, index, total) => {
      const step = index / total;
      const animationDelay = `${dur * step - dur}ms`;
      const angle = 2 * Math.PI * step;
      return {
        r: 5,
        style: {
          top: `${9 * Math.sin(angle)}px`,
          left: `${9 * Math.cos(angle)}px`,
          'animation-delay': animationDelay
        }
      };
    }
  },
  circular: {
    dur: 1400,
    elmDuration: true,
    circles: 1,
    fn: () => {
      return {
        r: 20,
        cx: 48,
        cy: 48,
        fill: 'none',
        viewBox: '24 24 48 48',
        transform: 'translate(0,0)',
        style: {}
      };
    }
  },
  crescent: {
    dur: 750,
    circles: 1,
    fn: () => {
      return {
        r: 26,
        style: {}
      };
    }
  },
  dots: {
    dur: 750,
    circles: 3,
    fn: (_, index) => {
      const animationDelay = -(110 * index) + 'ms';
      return {
        r: 6,
        style: {
          left: `${9 - 9 * index}px`,
          'animation-delay': animationDelay
        }
      };
    }
  },
  lines: {
    dur: 1000,
    lines: 8,
    fn: (dur, index, total) => {
      const transform = `rotate(${360 / total * index + (index < total / 2 ? 180 : -180)}deg)`;
      const animationDelay = `${dur * index / total - dur}ms`;
      return {
        y1: 14,
        y2: 26,
        style: {
          transform: transform,
          'animation-delay': animationDelay
        }
      };
    }
  },
  'lines-small': {
    dur: 1000,
    lines: 8,
    fn: (dur, index, total) => {
      const transform = `rotate(${360 / total * index + (index < total / 2 ? 180 : -180)}deg)`;
      const animationDelay = `${dur * index / total - dur}ms`;
      return {
        y1: 12,
        y2: 20,
        style: {
          transform: transform,
          'animation-delay': animationDelay
        }
      };
    }
  },
  'lines-sharp': {
    dur: 1000,
    lines: 12,
    fn: (dur, index, total) => {
      const transform = `rotate(${30 * index + (index < 6 ? 180 : -180)}deg)`;
      const animationDelay = `${dur * index / total - dur}ms`;
      return {
        y1: 17,
        y2: 29,
        style: {
          transform: transform,
          'animation-delay': animationDelay
        }
      };
    }
  },
  'lines-sharp-small': {
    dur: 1000,
    lines: 12,
    fn: (dur, index, total) => {
      const transform = `rotate(${30 * index + (index < 6 ? 180 : -180)}deg)`;
      const animationDelay = `${dur * index / total - dur}ms`;
      return {
        y1: 12,
        y2: 20,
        style: {
          transform: transform,
          'animation-delay': animationDelay
        }
      };
    }
  }
};
const SPINNERS = spinners;


/***/ }),

/***/ 91118:
/*!******************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/swipe-back-a896f0bc.js ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "createSwipeBackGesture": () => (/* binding */ createSwipeBackGesture)
/* harmony export */ });
/* harmony import */ var _helpers_3b390e48_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./helpers-3b390e48.js */ 29259);
/* harmony import */ var _dir_e8b767a8_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dir-e8b767a8.js */ 17481);
/* harmony import */ var _index_422b6e83_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./index-422b6e83.js */ 88759);
/* harmony import */ var _gesture_controller_17060b7c_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./gesture-controller-17060b7c.js */ 56379);
/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */




const createSwipeBackGesture = (el, canStartHandler, onStartHandler, onMoveHandler, onEndHandler) => {
  const win = el.ownerDocument.defaultView;
  const rtl = (0,_dir_e8b767a8_js__WEBPACK_IMPORTED_MODULE_1__.i)(el);
  /**
   * Determine if a gesture is near the edge
   * of the screen. If true, then the swipe
   * to go back gesture should proceed.
   */
  const isAtEdge = detail => {
    const threshold = 50;
    const {
      startX
    } = detail;
    if (rtl) {
      return startX >= win.innerWidth - threshold;
    }
    return startX <= threshold;
  };
  const getDeltaX = detail => {
    return rtl ? -detail.deltaX : detail.deltaX;
  };
  const getVelocityX = detail => {
    return rtl ? -detail.velocityX : detail.velocityX;
  };
  const canStart = detail => {
    return isAtEdge(detail) && canStartHandler();
  };
  const onMove = detail => {
    // set the transition animation's progress
    const delta = getDeltaX(detail);
    const stepValue = delta / win.innerWidth;
    onMoveHandler(stepValue);
  };
  const onEnd = detail => {
    // the swipe back gesture has ended
    const delta = getDeltaX(detail);
    const width = win.innerWidth;
    const stepValue = delta / width;
    const velocity = getVelocityX(detail);
    const z = width / 2.0;
    const shouldComplete = velocity >= 0 && (velocity > 0.2 || delta > z);
    const missing = shouldComplete ? 1 - stepValue : stepValue;
    const missingDistance = missing * width;
    let realDur = 0;
    if (missingDistance > 5) {
      const dur = missingDistance / Math.abs(velocity);
      realDur = Math.min(dur, 540);
    }
    onEndHandler(shouldComplete, stepValue <= 0 ? 0.01 : (0,_helpers_3b390e48_js__WEBPACK_IMPORTED_MODULE_0__.l)(0, stepValue, 0.9999), realDur);
  };
  return (0,_index_422b6e83_js__WEBPACK_IMPORTED_MODULE_2__.createGesture)({
    el,
    gestureName: 'goback-swipe',
    gesturePriority: 40,
    threshold: 10,
    canStart,
    onStart: onStartHandler,
    onMove,
    onEnd
  });
};


/***/ }),

/***/ 71489:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/crear-departamento/crear-departamento.page.scss?ngResource ***!
  \**********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 49579);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60931);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "ion-icon {\n  color: #000;\n}\n\nion-input {\n  border-radius: 10px;\n  border: solid 1px rgb(218, 218, 218);\n  height: 2.5rem;\n}\n\nion-label {\n  font-weight: 500;\n}\n\n.description {\n  height: 4rem;\n}\n\n.has-focus {\n  border: 2px solid #5b9bd1 !important;\n}\n\nion-footer ion-toolbar ion-button {\n  --padding-top:1rem;\n  --padding-bottom:1rem;\n  --padding-start:0.75rem;\n  --padding-end:0.75rem;\n  height: 2.5rem;\n  width: 60%;\n  display: block;\n  margin: 0 auto;\n  margin-bottom: 1rem;\n}", "",{"version":3,"sources":["webpack://./src/app/pages/crear-departamento/crear-departamento.page.scss","webpack://./../../Simple%20Design%20Experience/Control%20Viaticos/src/app/pages/crear-departamento/crear-departamento.page.scss"],"names":[],"mappings":"AAAA;EACI,WAAA;ACCJ;;ADCA;EACI,mBAAA;EACA,oCAAA;EACA,cAAA;ACEJ;;ADAA;EACI,gBAAA;ACGJ;;ADDA;EACI,YAAA;ACIJ;;ADFA;EACI,oCAAA;ACKJ;;ADHA;EACI,kBAAA;EACA,qBAAA;EACA,uBAAA;EACA,qBAAA;EACA,cAAA;EACA,UAAA;EACA,cAAA;EACA,cAAA;EACA,mBAAA;ACMJ","sourcesContent":["ion-icon{\r\n    color: #000;\r\n}\r\nion-input {\r\n    border-radius: 10px;\r\n    border: solid 1px rgba(218,218,218,1);\r\n    height: 2.5rem;\r\n}\r\nion-label{\r\n    font-weight: 500;\r\n}\r\n.description{\r\n    height: 4rem;\r\n}\r\n.has-focus{\r\n    border: 2px solid #5b9bd1 !important;\r\n}\r\nion-footer ion-toolbar ion-button{\r\n    --padding-top:1rem;\r\n    --padding-bottom:1rem;\r\n    --padding-start:0.75rem;\r\n    --padding-end:0.75rem;\r\n    height: 2.5rem;\r\n    width: 60%;\r\n    display: block;\r\n    margin: 0 auto;\r\n    margin-bottom: 1rem;\r\n}","ion-icon {\n  color: #000;\n}\n\nion-input {\n  border-radius: 10px;\n  border: solid 1px rgb(218, 218, 218);\n  height: 2.5rem;\n}\n\nion-label {\n  font-weight: 500;\n}\n\n.description {\n  height: 4rem;\n}\n\n.has-focus {\n  border: 2px solid #5b9bd1 !important;\n}\n\nion-footer ion-toolbar ion-button {\n  --padding-top:1rem;\n  --padding-bottom:1rem;\n  --padding-start:0.75rem;\n  --padding-end:0.75rem;\n  height: 2.5rem;\n  width: 60%;\n  display: block;\n  margin: 0 auto;\n  margin-bottom: 1rem;\n}"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 98228:
/*!************************************************************************************!*\
  !*** ./src/app/pages/editar-departamento/editar-departamento.page.scss?ngResource ***!
  \************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 49579);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60931);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "ion-icon {\n  color: #000;\n}\n\nion-input {\n  border-radius: 10px;\n  border: solid 1px rgb(218, 218, 218);\n  height: 2.5rem;\n}\n\nion-label {\n  font-weight: 500;\n}\n\n.description {\n  height: 4rem;\n}\n\n.has-focus {\n  border: 2px solid #5b9bd1 !important;\n}\n\nion-footer ion-toolbar ion-button {\n  --padding-top:1rem;\n  --padding-bottom:1rem;\n  --padding-start:0.75rem;\n  --padding-end:0.75rem;\n  height: 2.5rem;\n  width: 60%;\n  display: block;\n  margin: 0 auto;\n  margin-bottom: 1rem;\n}", "",{"version":3,"sources":["webpack://./src/app/pages/editar-departamento/editar-departamento.page.scss","webpack://./../../Simple%20Design%20Experience/Control%20Viaticos/src/app/pages/editar-departamento/editar-departamento.page.scss"],"names":[],"mappings":"AAAA;EACI,WAAA;ACCJ;;ADCA;EACI,mBAAA;EACA,oCAAA;EACA,cAAA;ACEJ;;ADAA;EACI,gBAAA;ACGJ;;ADDA;EACI,YAAA;ACIJ;;ADFA;EACI,oCAAA;ACKJ;;ADHA;EACI,kBAAA;EACA,qBAAA;EACA,uBAAA;EACA,qBAAA;EACA,cAAA;EACA,UAAA;EACA,cAAA;EACA,cAAA;EACA,mBAAA;ACMJ","sourcesContent":["ion-icon{\r\n    color: #000;\r\n}\r\nion-input {\r\n    border-radius: 10px;\r\n    border: solid 1px rgba(218,218,218,1);\r\n    height: 2.5rem;\r\n}\r\nion-label{\r\n    font-weight: 500;\r\n}\r\n.description{\r\n    height: 4rem;\r\n}\r\n.has-focus{\r\n    border: 2px solid #5b9bd1 !important;\r\n}\r\nion-footer ion-toolbar ion-button{\r\n    --padding-top:1rem;\r\n    --padding-bottom:1rem;\r\n    --padding-start:0.75rem;\r\n    --padding-end:0.75rem;\r\n    height: 2.5rem;\r\n    width: 60%;\r\n    display: block;\r\n    margin: 0 auto;\r\n    margin-bottom: 1rem;\r\n}","ion-icon {\n  color: #000;\n}\n\nion-input {\n  border-radius: 10px;\n  border: solid 1px rgb(218, 218, 218);\n  height: 2.5rem;\n}\n\nion-label {\n  font-weight: 500;\n}\n\n.description {\n  height: 4rem;\n}\n\n.has-focus {\n  border: 2px solid #5b9bd1 !important;\n}\n\nion-footer ion-toolbar ion-button {\n  --padding-top:1rem;\n  --padding-bottom:1rem;\n  --padding-start:0.75rem;\n  --padding-end:0.75rem;\n  height: 2.5rem;\n  width: 60%;\n  display: block;\n  margin: 0 auto;\n  margin-bottom: 1rem;\n}"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 63275:
/*!**************************************************************************!*\
  !*** ./src/app/pages/editar-usuario/editar-usuario.page.scss?ngResource ***!
  \**************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 49579);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60931);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "ion-icon {\n  color: #000;\n}\n\nion-input, ion-select {\n  border-radius: 10px;\n  border: solid 1px rgb(218, 218, 218);\n  height: 2.5rem;\n}\n\nion-label {\n  font-weight: 500;\n}\n\n.description {\n  height: 4rem;\n}\n\n.has-focus {\n  border: 2px solid #5b9bd1 !important;\n}\n\nion-footer ion-toolbar ion-button {\n  --padding-top:1rem;\n  --padding-bottom:1rem;\n  --padding-start:0.75rem;\n  --padding-end:0.75rem;\n  height: 2.5rem;\n  width: 60%;\n  display: block;\n  margin: 0 auto;\n  margin-bottom: 1rem;\n}", "",{"version":3,"sources":["webpack://./src/app/pages/editar-usuario/editar-usuario.page.scss","webpack://./../../Simple%20Design%20Experience/Control%20Viaticos/src/app/pages/editar-usuario/editar-usuario.page.scss"],"names":[],"mappings":"AAAA;EACI,WAAA;ACCJ;;ADCA;EACI,mBAAA;EACA,oCAAA;EACA,cAAA;ACEJ;;ADAA;EACI,gBAAA;ACGJ;;ADDA;EACI,YAAA;ACIJ;;ADFA;EACI,oCAAA;ACKJ;;ADHA;EACI,kBAAA;EACA,qBAAA;EACA,uBAAA;EACA,qBAAA;EACA,cAAA;EACA,UAAA;EACA,cAAA;EACA,cAAA;EACA,mBAAA;ACMJ","sourcesContent":["ion-icon{\r\n    color: #000;\r\n}\r\nion-input, ion-select {\r\n    border-radius: 10px;\r\n    border: solid 1px rgba(218,218,218,1);\r\n    height: 2.5rem;\r\n}\r\nion-label{\r\n    font-weight: 500;\r\n}\r\n.description{\r\n    height: 4rem;\r\n}\r\n.has-focus{\r\n    border: 2px solid #5b9bd1 !important;\r\n}\r\nion-footer ion-toolbar ion-button{\r\n    --padding-top:1rem;\r\n    --padding-bottom:1rem;\r\n    --padding-start:0.75rem;\r\n    --padding-end:0.75rem;\r\n    height: 2.5rem;\r\n    width: 60%;\r\n    display: block;\r\n    margin: 0 auto;\r\n    margin-bottom: 1rem;\r\n}","ion-icon {\n  color: #000;\n}\n\nion-input, ion-select {\n  border-radius: 10px;\n  border: solid 1px rgb(218, 218, 218);\n  height: 2.5rem;\n}\n\nion-label {\n  font-weight: 500;\n}\n\n.description {\n  height: 4rem;\n}\n\n.has-focus {\n  border: 2px solid #5b9bd1 !important;\n}\n\nion-footer ion-toolbar ion-button {\n  --padding-top:1rem;\n  --padding-bottom:1rem;\n  --padding-start:0.75rem;\n  --padding-end:0.75rem;\n  height: 2.5rem;\n  width: 60%;\n  display: block;\n  margin: 0 auto;\n  margin-bottom: 1rem;\n}"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 27255:
/*!**************************************************************************!*\
  !*** ./src/app/pages/lista-usuarios/lista-usuarios.page.scss?ngResource ***!
  \**************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 49579);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60931);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 3976:
/*!**********************************************************!*\
  !*** ./src/app/pages/perfil/perfil.page.scss?ngResource ***!
  \**********************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 49579);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60931);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".height {\n  height: 200px;\n  width: 200px;\n  margin: 0 auto;\n  margin-bottom: 3rem;\n}\n\nion-img {\n  width: 200px;\n  height: 200px;\n}\n\nimg {\n  width: 200px;\n  height: 200px;\n  margin: 0 auto;\n  border-radius: 50%;\n  object-fit: cover;\n}", "",{"version":3,"sources":["webpack://./src/app/pages/perfil/perfil.page.scss","webpack://./../../Simple%20Design%20Experience/Control%20Viaticos/src/app/pages/perfil/perfil.page.scss"],"names":[],"mappings":"AAAA;EAEI,aAAA;EACA,YAAA;EACA,cAAA;EACD,mBAAA;ACAH;;ADGA;EAEI,YAAA;EACF,aAAA;ACDF;;ADGE;EAEE,YAAA;EACF,aAAA;EACA,cAAA;EACA,kBAAA;EACA,iBAAA;ACDF","sourcesContent":[".height{\r\n\r\n    height: 200px;\r\n    width:200px;\r\n    margin: 0 auto;\r\n   margin-bottom: 3rem;\r\n}\r\n\r\nion-img {\r\n\r\n    width: 200px;\r\n  height: 200px;\r\n  }\r\n  img {\r\n\r\n    width: 200px;\r\n  height: 200px;\r\n  margin: 0 auto;\r\n  border-radius: 50%;\r\n  object-fit: cover;\r\n  }\r\n",".height {\n  height: 200px;\n  width: 200px;\n  margin: 0 auto;\n  margin-bottom: 3rem;\n}\n\nion-img {\n  width: 200px;\n  height: 200px;\n}\n\nimg {\n  width: 200px;\n  height: 200px;\n  margin: 0 auto;\n  border-radius: 50%;\n  object-fit: cover;\n}"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 32472:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/crear-departamento/crear-departamento.page.html?ngResource ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <ion-button (click)=\"cerrarModal()\"   fill=\"clear\"  slot=\"start\">\n     <ion-icon slot=\"icon-only\" name=\"arrow-back\"></ion-icon>\n    </ion-button>\n    <ion-title>Crear Departamento</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n<ion-grid >\n  <ion-row>\n\n    <ion-col size=\"12\">\n<ion-row>\n  <ion-col size=\"12\">\n    <ion-label class=\"ion-margin-bottom\">Nombre</ion-label>\n  </ion-col>\n  <ion-col size=\"12\">\n    <ion-input name=\"nombre\" [(ngModel)]=\"departamento.nombre\"  type=\"text\" placeholder=\"nombre\"></ion-input>\n  </ion-col>\n</ion-row>\n    </ion-col>\n    <ion-col size=\"12\">\n      <ion-row>\n        <ion-col size=\"12\">\n          <ion-label class=\"ion-margin-bottom\">Descrcipción</ion-label>\n        </ion-col>\n        <ion-col size=\"12\">\n          <ion-input  class=\"description\" name=\"descripcion\"  type=\"text\" placeholder=\"descripcion\" [(ngModel)]=\"departamento.descripcion\"></ion-input>\n        </ion-col>\n      </ion-row>\n          </ion-col>\n         \n        \n\n              \n  </ion-row>\n</ion-grid>\n\n</ion-content>\n\n \n<ion-footer class=\"ion-no-border\">\n  <ion-toolbar class=\"ion-padding\">\n    <ion-button (click)=\"post()\"      color=\"dark\" shape=\"round\">\n      Crear Departamento\n    </ion-button>\n  </ion-toolbar>\n</ion-footer>";

/***/ }),

/***/ 53796:
/*!************************************************************************************!*\
  !*** ./src/app/pages/editar-departamento/editar-departamento.page.html?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <ion-button (click)=\"cerrarModal()\"   fill=\"clear\"  slot=\"start\">\n     <ion-icon slot=\"icon-only\" name=\"arrow-back\"></ion-icon>\n    </ion-button>\n    <ion-title>Editar Departamento</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n<ion-grid >\n  <ion-row>\n\n    <ion-col size=\"12\">\n<ion-row>\n  <ion-col size=\"12\">\n    <ion-label class=\"ion-margin-bottom\">Nombre</ion-label>\n  </ion-col>\n  <ion-col size=\"12\">\n    <ion-input name=\"nombre\" [(ngModel)]=\"departamento.nombre\"  type=\"text\" placeholder=\"nombre\"></ion-input>\n  </ion-col>\n</ion-row>\n    </ion-col>\n    <ion-col size=\"12\">\n      <ion-row>\n        <ion-col size=\"12\">\n          <ion-label class=\"ion-margin-bottom\">Descrcipción</ion-label>\n        </ion-col>\n        <ion-col size=\"12\">\n          <ion-input  class=\"description\" name=\"descripcion\"  type=\"text\" placeholder=\"descripcion\" [(ngModel)]=\"departamento.descripcion\"></ion-input>\n        </ion-col>\n      </ion-row>\n          </ion-col>\n         \n        \n\n              \n  </ion-row>\n</ion-grid>\n\n</ion-content>\n\n \n<ion-footer class=\"ion-no-border\">\n  <ion-toolbar class=\"ion-padding\">\n    <ion-button (click)=\"post()\"      color=\"dark\" shape=\"round\">\n      Editar Departamento\n    </ion-button>\n  </ion-toolbar>\n</ion-footer>";

/***/ }),

/***/ 58853:
/*!**************************************************************************!*\
  !*** ./src/app/pages/editar-usuario/editar-usuario.page.html?ngResource ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <ion-button (click)=\"cerrarModal()\"   fill=\"clear\"  slot=\"start\">\n     <ion-icon slot=\"icon-only\" name=\"arrow-back\"></ion-icon>\n    </ion-button>\n    <ion-title>Editar Usuario</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n<ion-grid >\n  <ion-row>\n    <ion-col size=\"12\" style=\"display: flex;justify-content: space-between;align-items: center;\">\n      <ion-label>Asignación Roles</ion-label>\n     \n    </ion-col>\n    <ion-col size=\"12\">\n\n      <ion-select  multiple=\"true\"     name=\"matriz\"  [(ngModel)]=\"roles\"   placeholder=\"Seleccionar\">\n        <ion-select-option  *ngFor=\"let role of matriz\"  [value]=\"role.iD_MATRIZ_ACCESO\n        \">{{role.nombre}}</ion-select-option>\n      </ion-select>\n  \n    </ion-col>\n  </ion-row>\n  <ion-row>\n\n    <ion-col size=\"6\">\n<ion-row>\n  <ion-col size=\"12\">\n    <ion-label class=\"ion-margin-bottom\">Usuario</ion-label>\n  </ion-col>\n  <ion-col size=\"12\">\n    <ion-input name=\"usuario\" [(ngModel)]=\"usuario.usuario\"  type=\"text\" placeholder=\"usuario\"></ion-input>\n  </ion-col>\n</ion-row>\n    </ion-col>\n    <ion-col size=\"6\">\n      <ion-row>\n        <ion-col size=\"12\">\n          <ion-label class=\"ion-margin-bottom\">Nombre</ion-label>\n        </ion-col>\n        <ion-col size=\"12\">\n          <ion-input  name=\"nombre\"  type=\"text\" placeholder=\"nombre\" [(ngModel)]=\"usuario.nombre\"></ion-input>\n        </ion-col>\n      </ion-row>\n          </ion-col>\n          <ion-col size=\"6\">\n            <ion-row>\n              <ion-col size=\"12\">\n                <ion-label class=\"ion-margin-bottom\">Correo</ion-label>\n              </ion-col>\n              <ion-col size=\"12\">\n                <ion-input  name=\"correo\" [(ngModel)]=\"usuario.correo\"  type=\"text\" placeholder=\"correo\"></ion-input>\n              </ion-col>\n \n            </ion-row>\n                </ion-col>\n                <ion-col size=\"6\">\n                  <ion-row>\n                    <ion-col size=\"12\">\n                      <ion-label class=\"ion-margin-bottom\">Contraseña</ion-label>\n                    </ion-col>\n                    <ion-col size=\"12\">\n                      <ion-input  name=\"clave\" [(ngModel)]=\"usuario.clave\"  type=\"password\" placeholder=\"clave\"></ion-input>\n                    </ion-col>\n       \n                  </ion-row>\n                      </ion-col>\n\n              \n  </ion-row>\n</ion-grid>\n\n</ion-content>\n\n \n<ion-footer class=\"ion-no-border\">\n  <ion-toolbar class=\"ion-padding\">\n    <ion-button (click)=\"post()\"      color=\"dark\" shape=\"round\">\n      Editar Usuario\n    </ion-button>\n  </ion-toolbar>\n</ion-footer>";

/***/ }),

/***/ 64545:
/*!**************************************************************************!*\
  !*** ./src/app/pages/lista-usuarios/lista-usuarios.page.html?ngResource ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n <ion-grid >\n  <ion-row>\n    <ion-col size=\"2\" style=\"display: flex;justify-content: flex-start;align-items: center;\">\n      <ion-button (click)=\"cerrarModal()\"  fill=\"clear\">\n        <ion-icon color=\"dark\" size=\"large\" name=\"arrow-back-outline\"></ion-icon>\n      </ion-button>\n    </ion-col>\n    <ion-col size=\"10\" style=\"display: flex;justify-content: flex-start;align-items: center;\">\n      <ion-title ><strong>Colaboradores</strong></ion-title>\n    </ion-col>\n    <ion-col size=\"12\" >\n     \n      <ion-searchbar style=\"max-width: 80%;margin: 0 auto;display: block;\"  mode=\"ios\" placeholder=\"Buscar Colaborador\" type=\"text\"\n      [debounce]=\"250\"></ion-searchbar>\n    </ion-col>\n  </ion-row>\n </ion-grid>\n  </ion-toolbar>\n \n</ion-header>\n<ion-content>\n  <ion-col size=\"12\">\n     <ion-list >\n      <ion-item lines=\"none\" *ngIf=\"usuarios.length == 0\" >\n\n        <ion-grid>\n          <ion-row>\n            <ion-col size=\"12\" class=\"ion-text-center ion-margin-top\">\n              <img height=\"150\" src=\"assets/imgs/empty-box.svg\" alt=\"\">\n            </ion-col>\n            <ion-col size=\"12\" class=\"ion-text-center\">\n              <strong class=\"ion-text-capitalize\">No hay datos que mostrar</strong>\n            </ion-col>\n\n          </ion-row>\n        </ion-grid>\n\n      </ion-item>\n\n      <ion-item lines=\"none\" *ngFor=\"let usuario of usuarios| filtro: textoBuscar:'usuario'; let i = index;\"  >\n\n        <ion-avatar  slot=\"start\">\n          <img   src=\"../assets/imgs/user.svg\" />\n        </ion-avatar>\n\n        <ion-label  >{{usuario.usuario}}</ion-label>\n\n        <ion-checkbox   slot=\"end\" name=\"usuario\" [(ngModel)]=\"usuario.seleccionado\"  (ionChange)=\"agregarUsuario($event,i)\"  ></ion-checkbox>\n     \n\n     \n      </ion-item>\n     </ion-list>\n      \n    \n\n\n  </ion-col>\n</ion-content>\n<ion-footer class=\"ion-no-border\">\n  <ion-toolbar class=\"ion-padding\">\n<ion-button (click)=\"retornarUsuarios()\" expand=\"block\" fill=\"solid\" color=\"dark\">\n Agregar Colaboradores\n</ion-button>\n  </ion-toolbar>\n</ion-footer>\n";

/***/ }),

/***/ 15246:
/*!**********************************************************!*\
  !*** ./src/app/pages/perfil/perfil.page.html?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <ion-button (click)=\"cerrarModal()\"  fill=\"clear\" slot=\"start\">\n      <ion-icon color=\"dark\" size=\"large\" name=\"arrow-back-outline\"></ion-icon>\n    </ion-button>\n    <ion-title>Perfil Usuario</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n\n  <ion-list>\n\n<ion-list-header>\n  <ion-avatar  class=\"height\">\n    <img src=\"assets/imgs/user.svg\" />\n  </ion-avatar>\n \n</ion-list-header>\n<ion-item>\n  <ion-label>Nombre</ion-label>\n  <ion-label>{{usuariosService.usuario.nombre}} {{usuariosService.usuario.apellido}}</ion-label>\n</ion-item>\n \n<ion-item>\n  <ion-label>Usuario</ion-label>\n  <ion-label>{{usuariosService.usuario.usuario}}</ion-label>\n</ion-item>\n<ion-item>\n  <ion-label>Correo</ion-label>\n  <ion-label>{{usuariosService.usuario.correo}}</ion-label>\n</ion-item>\n<ion-item>\n  <ion-label>Estado</ion-label>\n  <ion-label><ion-badge color=\"warning\" mode=\"ios\">{{usuariosService.usuario.estatus ? 'Activo' : 'Inactivo'}}</ion-badge></ion-label>\n</ion-item>\n\n\n  </ion-list>\n</ion-content>\n ";

/***/ })

}]);
//# sourceMappingURL=common.js.map